CREATE TRIGGER EMP_TRG1
BEFORE INSERT
  ON EMP
FOR EACH ROW
  begin
                  if :new.empno is null then
                      select emp_seq.nextval into :new.empno from sys.dual;
                 end if;
              end;
/
