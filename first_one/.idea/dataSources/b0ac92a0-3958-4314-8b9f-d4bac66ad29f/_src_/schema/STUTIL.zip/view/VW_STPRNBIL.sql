CREATE VIEW VW_STPRNBIL AS SELECT distbrcde distributor_code,
          depslpno deposit_slip_no,
          tranid tracer_no,
          crdttk deposit_amount,
          TRUNC (timstamp) transaction_date,
             opbrancd
          || ' - '
          || (SELECT brnnam
                FROM bbankcode
               WHERE grpcde = '001' AND brancd = a.opbrancd)
             branch_name,
          remark naration,
          userid teller_id
     FROM stprnbil a
    WHERE paystat = 'P' AND tranflg = 'Y'
/
