CREATE PROCEDURE        dynamic_procedure (
   p_service_id   IN     VARCHAR2,
   p_bill         IN     VARCHAR2 DEFAULT NULL,
   -- p_amount       IN     VARCHAR2 DEFAULT NULL,
   p_json_value   IN     CLOB,
   p_TRANID       IN     VARCHAR2,
   p_name         IN     VARCHAR2 DEFAULT NULL,
   p_app_user     IN     VARCHAR2,
   o_var1            OUT VARCHAR2,
   o_var2            OUT VARCHAR2,
   o_num1            OUT NUMBER,
   o_num2            OUT NUMBER)
IS
BEGIN
   
   IF p_service_id = 'PRAGATI'
   THEN
      STUTIL.pragati_post_method (customer_code   => p_bill,
                                  p_json_get      => p_json_value,
                                  pol_name        => p_name,
                                  p_TRANID        => p_TRANID,
                                  app_user        => p_app_user,
                                  v_reqid         => o_num1,
                                  no_sub          => o_num2,
                                  receipt         => o_var1,
                                  status          => o_var2);
   --raise_application_error(-20002, 'req id : '||o_num1 || '  no_sub:  ' || o_num2 || '   receipt :  '||o_var1|| '   status: '||o_var2);



   END IF;
END;
/
