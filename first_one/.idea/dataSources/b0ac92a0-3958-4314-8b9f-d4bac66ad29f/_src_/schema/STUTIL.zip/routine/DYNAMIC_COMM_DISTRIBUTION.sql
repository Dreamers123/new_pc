CREATE PROCEDURE        Dynamic_Comm_distribution (
   p_dblink                  IN     VARCHAR2,
   p_oprbrancd               IN     VARCHAR2,
   p_oprtamp                 IN     VARCHAR2,
   p_no_of_records           IN     NUMBER,
   p_tot_charge_amt          IN     NUMBER,
   p_tot_crg_amt_branch      IN     NUMBER,
   p_tot_crg_amt_corporate   IN     NUMBER,
   p_branch_code             IN     VARCHAR2,                     ---AI_BRANCH
   p_app_user                IN     VARCHAR2,
   p_service_id              IN     VARCHAR2,
   p_AI_DOCDAT               IN     DATE,
   p_form_date               IN     DATE,
   p_to_date                 IN     DATE,
   pErrorFlag                   OUT VARCHAR2,
   pErrorMessage                OUT VARCHAR2)
IS
   v_row            NUMBER := 0;
   v_tnum           VARCHAR2 (50) := NULL;
   v_erritem        VARCHAR2 (50) := NULL;
   O_ERR_FLG        VARCHAR2 (5) := NULL;
   O_ERR_MSG        VARCHAR2 (4000) := NULL;
   v_crcode         VARCHAR2 (10) := NULL;
   v_drcode         VARCHAR2 (10) := NULL;
   V_ACTYPE         VARCHAR2 (20);
   V_ACTNUM         VARCHAR2 (30);
   V_ENCACTNUM      VARCHAR2 (100);
   V_DOCTYPE        VARCHAR2 (5);
   v_doctype2       VARCHAR2 (3) := NULL;
   V_oprcod         VARCHAR2 (50);
   v_errflg         VARCHAR2 (10) := NULL;
   vErrorFlag       VARCHAR2 (1) := NULL;
   vErrorMessage    VARCHAR2 (1024) := NULL;
   v_errmsg         VARCHAR2 (1024) := NULL;
   v_crgamt         NUMBER := 0;
   o_curcde         VARCHAR2 (50);
   vSLNODAY         NUMBER := 0;
   V_PARKINGGL      VARCHAR2 (30);
   V_CHRG_PAYABLE   VARCHAR2 (30);
   V_CHRG_INCOME    VARCHAR2 (30);
   v_channel        VARCHAR2 (200);
   V_VAT            VARCHAR2 (30);
   Mv_drcode        VARCHAR2 (50);
   v_GL             VARCHAR2 (2);
   V_branch         VARCHAR2 (3);
   
   V_BRANCD_CRG     VARCHAR2 (5);
   V_ACTYPE_CRG     VARCHAR2 (5);
   V_AC_CHRG        VARCHAR2 (10);
   
   vAGN_COM         NUMBER := 0;
   vCORPORATE_COM   NUMBER := 0;
   vERA_COM         NUMBER := 0;
   vCbsDocNo        VARCHAR2 (13);
   vDocNo           VARCHAR2 (20);
   vDocDate         DATE;
BEGIN
   /*  IF APEX_APPLICATION.G_f22.COUNT = 0
        THEN
           raise_application_error (
              -20001,
              'Approval failure occurred.Please select a checkbox first and try again...!');
           ROLLBACK;
           RETURN;
        END IF;
     */


   ----------------------MetLife A/C information-------------------------
 /*  BEGIN
      SELECT SUBTYPE,
             PARAVAL,
             SUBSTR (PARAVAL, 1, 3),
             stutil.GET_ENC_VAL (
                PARAVAL,
                stutil.HASH_ENCRYPT ('Metba123Metba123Metba123Metba123'))
                enc_account
        INTO V_ACTYPE,
             V_ACTNUM,
             V_branch,
             V_ENCACTNUM
        FROM STPARAMT
       WHERE TYPE = 'MET' AND RESPONSECODE = 100;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         raise_application_error (
            -20001,
            'Destination A/c Information Not Foundin STPARAMT(TYPE-MET)');
      WHEN OTHERS
      THEN
         raise_application_error (
            -20001,
            'ErrorGettingDestinationA/cInformation-ERROR:' || SQLERRM);
   END;  */
 
    
      BEGIN           -------------DYNAMIN A/C TYPE / A/C NUM--------------------
      SELECT SUBSTR(A.SERVICE_PRO_ACC_NO,1,3),A.SERVICE_PRO_ACC_NO, B.ACTYPE
        INTO   
                V_branch,
                V_ACTYPE,
                V_ACTNUM
        FROM STUTIL.SERVICE_PRO_INFO A, STLBAS.STFACMAS@STUTLTOCBS B
       WHERE     B.ACTNUM = A.SERVICE_PRO_ACC_NO
             AND B.BRANCD = SUBSTR (A.SERVICE_PRO_ACC_NO, 1, 3)
             AND B.ACSTAT NOT IN ('CLS', 'TRF')
             AND UPPER (A.SERVICE_ID) = UPPER (p_service_id);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         pErrorFlag := 'E';
         pErrorMessage := 'E1- Failed to get Destination A/c Information  ';
        -- GOTO ON_ERROR;
      WHEN OTHERS
      THEN
         pErrorFlag := 'E';
         pErrorMessage :=
            'E2- Failed to get Destination A/c Information. Ref :' || SQLERRM;
        -- GOTO ON_ERROR;
   END;
   

 
   BEGIN                                        ------------CHARGEGL----------
      SELECT ACTNUM,CHRINGL
        INTO V_CHRG_PAYABLE,V_CHRG_INCOME
        FROM STCHINFO
       WHERE  UPPER (SERVICENO) = UPPER (p_service_id);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         raise_application_error (
            -20001,
            'Destination A/cInformation Not Found in STCHINFO');
      WHEN OTHERS
      THEN
         raise_application_error (
            -20001,
            'Error Getting Destination A/c Information-ERROR:' || SQLERRM);
   END;  




   BEGIN
      ----------------------------------------DOC_TYPEASSIGN--------------------------------------
      BEGIN
         IF p_branch_code = SUBSTR (V_ACTNUM, 1, 3)
         THEN
            V_DOCTYPE := 'CS';
            V_oprcod := 'DEP';
            v_doctype2 := 'DC';
         ELSE
            V_DOCTYPE := 'IC';
            V_oprcod := 'IB1';
            v_doctype2 := 'IT';
         END IF;
      END;

      --------------------------------------TellerLimitCheck---------------------------------



      ----------------------------DOCUMENTGENERATIONPROCESS--------------------------
      BEGIN
         dpr_docnumber_generation (p_dblink     => p_dblink, ----------->PASSINGDBLINKFROMAPPLICATIONITEM
                                   p_compcd     => p_branch_code,
                                   p_modlcd     => 'ST',
                                   p_doctyp     => V_DOCTYPE,
                                   p_subtyp     => 1,
                                   p_docdat     => SYSDATE,
                                   p_loccde     => NULL,
                                   p_origmodl   => 'ST',
                                   p_docnum     => v_tnum,
                                   p_errflag    => v_errflg,
                                   p_errmsg     => v_errmsg);

         IF v_errmsg IS NULL
         THEN
            v_tnum := p_branch_code || v_tnum;
         ELSE
            raise_application_error (-20001, v_errflg || '-' || v_errmsg);
            ROLLBACK;
            RETURN;
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            raise_application_error (
               -20001,
                  'Error Generating Docnumber-'
               || v_tnum
               || '.Error:'
               || SQLERRM);
            ROLLBACK;
            RETURN;
      END;



      /*  IF (SUBSTR (v_actnum, 1, 3) <> p_oprbrancd) -----------------Getbranchglcode
        THEN
           BEGIN
              stutil.dpr_get_branch_glcode (p_dblink   => p_dblink,
                                            p_brancd   => p_oprbrancd,
                                            p_glcode   => v_crcode,
                                            p_errflg   => O_ERR_FLG,
                                            p_errmsg   => O_ERR_MSG);

              IF O_ERR_FLG IS NOT NULL
              THEN
                 raise_application_error (-20001,
                                          O_ERR_FLG || '-' || O_ERR_MSG);
                 ROLLBACK;
                 RETURN;
              END IF;
           END;
        ELSE
           v_crcode := 'DUMMY';
        END IF;
  */
    --  v_crgamt := p_tot_charge_amt - p_tot_crg_amt_era;

      BEGIN   -----------------------Charge Fee debit-------------------------
         dpr_insert_fetran (
            p_dblink     => p_dblink,
            p_brancd     => '100', -- SUBSTR (v_actnum, 1, 3),          --p_branch_code,
            p_doctyp     => v_doctype2,
            p_docnum     => v_tnum,
            p_sernum     => 1,
            p_docdat     => p_AI_DOCDAT,
            p_valdat     => p_AI_DOCDAT,
            p_oprcod     => 'WDL',
            p_actype     => 'Z99',
            p_actnum     => '10000000099',        --p_branch_code||'00000099',
            p_curcde     => 'BDT',
            p_exrate     => 1,
            p_debcre     => 'D',                                       -------
            p_dbamfc     => p_tot_crg_amt_corporate,
            --------0,
            p_dbamlc     => p_tot_crg_amt_corporate,
            --------0,
            p_cramfc     => 0, -------TO_NUMBER(APEX_APPLICATION.G_F09(v_row),'999G999G999G999G990D00'),
            p_cramlc     => 0, -------TO_NUMBER(APEX_APPLICATION.G_F09(v_row),'999G999G999G999G990D00'),
            p_curbal     => 0,
            p_balflg     => 'Y',
            p_chgflg     => 'N',
            p_chqser     => NULL,
            p_chqnum     => NULL,
            p_chqdat     => NULL,
            p_trbrancd   => p_oprbrancd,                                 --085
            p_tractype   => NULL,                               ---v_depactyp,
            p_tractnum   => NULL,                                ---v_depacno,
            p_trchqser   => NULL,
            p_trchqnum   => NULL,
            p_trchqdat   => NULL,
            p_clrzon     => NULL,
            p_clrday     => NULL,
            p_prtflg     => 'N',
            p_glcode     => NULL,
            p_opbrancd   => p_branch_code,                               --085
            p_remark     => 'MetLife Premium COLLECTION-CHARGE FEE',
            p_yrprfx     => NULL,
            p_chgcde     => 'N',
            p_modcde     => 'ST',
            p_supid2     => p_app_user,
            p_drcode     => V_CHRG_PAYABLE,                      --'10100-01',
            p_crcode     => V_CHRG_INCOME, --'14100-01', --v_crcode,                      --'15700-01',
            p_oprstamp   => p_oprtamp,
            p_timstamp   => SYSTIMESTAMP,
            p_glflag     => 'Y',
            p_refno5     => NULL,
            p_errflg     => O_ERR_FLG,
            p_errmsg     => O_ERR_MSG);

         IF O_ERR_FLG IS NOT NULL
         THEN
            raise_application_error (-20001,
                                     O_ERR_FLG || '-' || O_ERR_MSG || '--E1');
         END IF;
      END;



      BEGIN
         stutil.dpr_get_branch_glcode (p_dblink   => p_dblink,
                                       p_brancd   => p_oprbrancd,
                                       p_glcode   => Mv_drcode,
                                       p_errflg   => O_ERR_FLG,
                                       p_errmsg   => O_ERR_MSG);

         IF O_ERR_FLG IS NOT NULL
         THEN
            raise_application_error (-20001, O_ERR_FLG || '-' || O_ERR_MSG);
            ROLLBACK;
            RETURN;
         END IF;
      END;

      BEGIN ---------------------------ChargeFee credit Branch Head------------------------------------
         dpr_insert_fetran (
            p_dblink     => p_dblink,
            p_brancd     => '100',
            p_doctyp     => 'IT',                        ------------bujhbo na
            p_docnum     => v_tnum,
            p_sernum     => 2,
            p_docdat     => p_AI_DOCDAT,
            p_valdat     => p_AI_DOCDAT,
            p_oprcod     => 'WDL',
            p_actype     => 'Z99',
            p_actnum     => '10000000099',
            p_curcde     => 'BDT',
            p_exrate     => 1,
            p_debcre     => 'D',                                       -------
            p_dbamfc     => p_tot_crg_amt_branch,
            p_dbamlc     => p_tot_crg_amt_branch,
            p_cramfc     => 0,
            p_cramlc     => 0,
            p_curbal     => 0,
            p_balflg     => 'Y',
            p_chgflg     => 'N',
            p_chqser     => NULL,
            p_chqnum     => NULL,
            p_chqdat     => NULL,
            p_trbrancd   => p_oprbrancd,
            p_tractype   => NULL,                               ---v_depactyp,
            p_tractnum   => NULL,                                ---v_depacno,
            p_trchqser   => NULL,
            p_trchqnum   => NULL,
            p_trchqdat   => NULL,
            p_clrzon     => NULL,
            p_clrday     => NULL,
            p_prtflg     => 'N',
            p_glcode     => NULL,
            p_opbrancd   => p_branch_code,
            p_remark     => 'MetLife Premium COLLECTION-CHARGE FEE',
            p_yrprfx     => NULL,
            p_chgcde     => 'N',
            p_modcde     => 'ST',
            p_supid2     => p_app_user,
            p_drcode     => V_CHRG_PAYABLE,                      --'10100-01',
            p_crcode     => Mv_drcode,                           --'10100-01',
            p_oprstamp   => p_oprtamp,
            p_timstamp   => SYSTIMESTAMP,
            p_glflag     => 'Y',
            p_refno5     => NULL,
            p_errflg     => O_ERR_FLG,
            p_errmsg     => O_ERR_MSG);

         IF O_ERR_FLG IS NOT NULL
         THEN
            raise_application_error (-20001,
                                     O_ERR_FLG || '-' || O_ERR_MSG || 'E2');
         END IF;
      END;


      BEGIN ---------------------------ChargeFee credit income head------------------------------------
         dpr_insert_fetran (
            p_dblink     => p_dblink,
            p_brancd     => p_oprbrancd,
            p_doctyp     => 'IT',                        ------------bujhbo na
            p_docnum     => v_tnum,
            p_sernum     => 3,
            p_docdat     => p_AI_DOCDAT,
            p_valdat     => p_AI_DOCDAT,
            p_oprcod     => 'DEP',
            p_actype     => 'Z99',
            p_actnum     => p_oprbrancd || '00000099',
            p_curcde     => 'BDT',
            p_exrate     => 1,
            p_debcre     => 'C',                                       -------
            p_dbamfc     => 0,
            p_dbamlc     => 0,
            p_cramfc     => p_tot_crg_amt_branch,
            p_cramlc     => p_tot_crg_amt_branch,
            p_curbal     => 0,
            p_balflg     => 'Y',
            p_chgflg     => 'N',
            p_chqser     => NULL,
            p_chqnum     => NULL,
            p_chqdat     => NULL,
            p_trbrancd   => p_oprbrancd,
            p_tractype   => NULL,                               ---v_depactyp,
            p_tractnum   => NULL,                                ---v_depacno,
            p_trchqser   => NULL,
            p_trchqnum   => NULL,
            p_trchqdat   => NULL,
            p_clrzon     => NULL,
            p_clrday     => NULL,
            p_prtflg     => 'N',
            p_glcode     => NULL,
            p_opbrancd   => p_branch_code,
            p_remark     => 'MetLife Premium COLLECTION-CHARGE FEE',
            p_yrprfx     => NULL,
            p_chgcde     => 'N',
            p_modcde     => 'ST',
            p_supid2     => p_app_user,
            p_drcode     => '14100-01',                          --'10100-01',
            p_crcode     => V_CHRG_INCOME,                       --'10100-01',
            p_oprstamp   => p_oprtamp,
            p_timstamp   => SYSTIMESTAMP,
            p_glflag     => 'Y',
            p_refno5     => NULL,
            p_errflg     => O_ERR_FLG,
            p_errmsg     => O_ERR_MSG);

         IF O_ERR_FLG IS NOT NULL
         THEN
            raise_application_error (-20001,
                                     O_ERR_FLG || '-' || O_ERR_MSG || 'E3');
         END IF;
      END;
   END;



   IF O_ERR_MSG IS NULL
   THEN
      BEGIN                                 -------UpdateSTLMDBEXTable--------
         UPDATE STLMDBEX
            SET COMFLAG = 'Y',
                COMDOCNUM = v_tnum,
                COMDATE = SYSDATE,
                COMMMISIONBY = p_app_user
          WHERE     OPRSTAMP = p_oprtamp
                AND OPBRANCD = p_oprbrancd
                AND TRANFLG = 'Y'
                AND COMFLAG = 'N'
                AND CANCELBY IS NULL
                AND CANCELTIME IS NULL
                AND PAYSTAT = 'P'
                AND OPBRANCD <> '108';
      EXCEPTION
         WHEN OTHERS
         THEN
            raise_application_error (
               -20001,
                  p_oprtamp
               || p_oprbrancd
               || 'Can not Update STLMDBEX'
               || SQLERRM);
      END;
   ELSE
      raise_application_error (-20001, O_ERR_MSG);
      ROLLBACK;
      RETURN;
   END IF;
END;
/
