CREATE PROCEDURE        validation_from_metlife (
   pPolicyNo          IN     VARCHAR2,
   pPolicyType        IN     VARCHAR2,
   pAmount            IN     NUMBER,
   pCompany              OUT VARCHAR2,
   pPrmamt               OUT NUMBER,
   pPrmamtd              OUT NUMBER,
   pPONAME               OUT VARCHAR2,
   pReceiptHeading       OUT VARCHAR2,
   pReceiptHeading1      OUT VARCHAR2,
   pOnaccountof          OUT VARCHAR2,
   pPolsts               OUT VARCHAR2,
   pLoandt               OUT VARCHAR2,
   pLoanamt              OUT NUMBER,
   pAplamt               OUT NUMBER,
   pReinstamt            OUT NUMBER,
   pDuedt                OUT VARCHAR2,
   pDuedtnxt1            OUT VARCHAR2,
   pDuedtnxt2            OUT VARCHAR2,
   pDuedtnxt3            OUT VARCHAR2,
   pAgentcode            OUT VARCHAR2,
   pTkfcopid             OUT VARCHAR2,
   pTdrsts               OUT VARCHAR2,
   pErrorFlag            OUT VARCHAR2,
   pErrorMessage         OUT VARCHAR2)
IS
   vMyException   EXCEPTION;

   vCompany       VARCHAR2 (4);
   vPMODE         VARCHAR2 (2);
   vPONAME        VARCHAR2 (100);
   vCount         NUMBER;
   vPOLSTS        VARCHAR2 (2);
   vAmount        NUMBER;
   vPrmamtd       NUMBER;
   vPrmamt        NUMBER;
   vTkfcopid      VARCHAR2 (3);
   vLoandt        VARCHAR2 (8);
   vLoanamt       NUMBER;
   vAplamt        NUMBER;
   vReinstamt     NUMBER;
   vDuedt         VARCHAR2 (8);
   vDuedtnxt1     VARCHAR2 (8);


   vDuedtnxt2     VARCHAR2 (8);
   vDuedtnxt3     VARCHAR2 (8);
   vAgentcode     VARCHAR2 (100);
   vTdrsts        VARCHAR2 (3);
   va             VARCHAR2 (100);
BEGIN


   pErrorFlag := 'N';

   BEGIN
      SELECT stutil.GET_DEC_VAL (
                pPolicyNo,
                stutil.HASH_ENCRYPT ('Metba123Metba123Metba123Metba123'))
        INTO va
        FROM DUAL;
   END;


   BEGIN
      SELECT COUNT (1)
        INTO vCount
        FROM LLMDBEXPT@METLIFE_UTILITY
       WHERE POLICYNO = pPolicyNo;
   EXCEPTION
      WHEN OTHERS
      THEN
         pErrorMessage := 'Policy Finding Problem. - ' || SQLERRM;
         RAISE vMyException;
   END;

   IF vCount <> 0
   THEN
      BEGIN
         SELECT COMPANY,
                PMODE,
                PONAME,
                POLSTS,
                PRMAMT,
                PRMAMTD,
                LOANDT,
                LOANAMT,
                Aplamt,
                Reinstamt,
                Duedt,
                DUEDTNXT1,
                DUEDTNXT2,
                DUEDTNXT3,
                Agentcode,
                TKFCOPID,
                TDRSTS
           INTO vCompany,
                vPMODE,
                vPONAME,
                vPOLSTS,
                vPrmamt,
                vPrmamtd,
                vLoandt,
                vLoanamt,
                vAplamt,
                vReinstamt,
                vDuedt,
                vDuedtnxt1,
                vDuedtnxt2,
                vDuedtnxt3,
                vAgentcode,
                vTkfcopid,
                vTdrsts
           FROM LLMDBEXPT@METLIFE_UTILITY
          WHERE POLICYNO = pPolicyNo;
      END;

      IF pPolicyType = 1
      THEN
         IF vPOLSTS = '20'
         THEN
            IF vPrmamt = pAmount OR vPrmamtd = pAmount
            THEN
               IF vTkfcopid = '000' OR vTkfcopid = '0'
               THEN
                  pReceiptHeading := 'Premium Receipt';
               ELSIF vTkfcopid = 'TKF'
               THEN
                  pReceiptHeading := 'Contribution Receipt';
               ELSIF vTkfcopid = 'COP'
               THEN
                  pReceiptHeading := 'Premium Receipt';

                  pReceiptHeading1 :=
                        'Coverage Renewed upto '
                     || TO_CHAR (TO_TIMESTAMP (vDuedtnxt1, 'YYYYMMDD'),
                                 'dd-mm-yyyy')
                     || ' & Renewableeee as per Contract part VII, CL.3,4,22';
               END IF;

               pOnaccountof := 'Premium Payment';
            ELSE
               pErrorMessage :=
                     'Please Pay Premium BDT '
                  || TO_CHAR (vPrmamt, '999G999G999G999G990D00')
                  || ' or contact MetLife HO @ 09666 7 16344 / 16344; PRESS Option:  3 - Ext 435 or 662';
               RAISE vMyException;
            END IF;
         ELSIF vPOLSTS IS NULL
         THEN
            pErrorMessage :=
               'Policy is Not in Force .Check policy Number or contact MetLife HO @ 09666 7 16344 / 16344; PRESS Option:  3 - Ext 435 or 662';
            RAISE vMyException;
         ELSE
            pErrorMessage :=
               'Policy is Not in Force .Check policy Number or contact MetLife HO @ 09666 7 16344 / 16344; PRESS Option:  3 - Ext 435 or 662';
            RAISE vMyException;
         END IF;
      END IF;

      IF pPolicyType = 2
      THEN
         IF vTdrsts = '00' OR vTdrsts = '0'
         THEN
            pReceiptHeading := 'Temporary Deposit Receipt';
            pOnaccountof := 'Application No - ' || va;
            pPrmamt := pAmount;
         ELSE
            pErrorMessage :=
               'Application Payment already made, Select correct Pay Type or contact MetLife HO @ 09666 7 16344 / 16344; PRESS Option:  3 - Ext 435 or 662 ';
            RAISE vMyException;
         END IF;
      END IF;

      IF pPolicyType = 3
      THEN
         IF vPOLSTS = '20'
         THEN
            IF vLoanamt > 0
            THEN
               IF pAmount <= vLoanamt
               THEN
                  pReceiptHeading := 'Money Receipt';
                  pOnaccountof := 'Repayment of Loan';
               ELSE
                  pErrorMessage :=
                        'Maximum Loan is BDT '
                     || TO_CHAR (vLoanamt, '999G999G999G999G990D00')
                     || ' or contact MetLife HO @ 09666 7 16344 / 16344; PRESS Option:  3 - Ext 435 or 662';
                  RAISE vMyException;
               END IF;
            ELSE
               pErrorMessage := ' No Outstanding Loan Against the Policy .';
               RAISE vMyException;
            END IF;
         ELSE
            pErrorMessage :=
               'Policy is Not in Force .Check policy policy Number or contact MetLife HO @ 09666 7 16344 / 16344; PRESS Option:  3 - Ext 435 or 662';
            RAISE vMyException;
         END IF;
      END IF;

      IF pPolicyType = 4
      THEN
         IF vPOLSTS = '20'
         THEN
            IF vAplamt > 0
            THEN
               IF pAmount <= vAplamt
               THEN
                  pReceiptHeading := 'Money Receipt';
                  pOnaccountof := 'Repayment of APL';
               ELSE
                  pErrorMessage :=
                        'Maximum APL Repayment is BDT '
                     || TO_CHAR (vAplamt, '999G999G999G999G990D00')
                     || ' ;contact MetLife HO @ 09666 7 16344 / 16344; PRESS Option:  3 - Ext 435 or 662';
                  RAISE vMyException;
               END IF;
            ELSE
               pErrorMessage := 'No Outstanding dues against the Policy.';
               RAISE vMyException;
            END IF;
         ELSE
            pErrorMessage :=
               'Policy is Not in Force .Check policy policy Number or contact MetLife HO @ 09666 7 16344 / 16344; PRESS Option:  3 - Ext 435 or 662';
            RAISE vMyException;
         END IF;
      END IF;

      IF pPolicyType = 5
      THEN
         IF vPOLSTS = '45'
         THEN
            IF vReinstamt > 0
            THEN
               IF pAmount <= vReinstamt
               THEN
                  pReceiptHeading := 'Money Receipt';
                  pOnaccountof := 'Auto Surrender';
               ELSE
                  pErrorMessage :=
                        'Maximum Reinstatement Amount is BDT '
                     || TO_CHAR (vReinstamt, '999G999G999G999G990D00')
                     || ' ;contact MetLife HO @ 09666 7 16344 / 16344; PRESS Option:  3 - Ext 435 or 662';
                  RAISE vMyException;
               END IF;
            ELSE
               pErrorMessage := 'No Reinstatement against the policy ';
               RAISE vMyException;
            END IF;
         ELSE
            pErrorMessage :=
               'Policy is Not in Force .Check policy policy Number or contact MetLife HO @ 09666 7 16344 / 16344; PRESS Option:  3 - Ext 435 or 662';
            RAISE vMyException;
         END IF;
      END IF;

      IF pPolicyType = 6
      THEN
         IF vPOLSTS = '42'
         THEN
            IF vReinstamt > 0
            THEN
               IF pAmount <= vReinstamt
               THEN
                  pReceiptHeading := 'Money Receipt';
                  pOnaccountof := 'Payment Against Lapse';
               ELSE
                  pErrorMessage :=
                        'Maximum Reinstatement Amoubt is BDT '
                     || TO_CHAR (vReinstamt, '999G999G999G999G990D00')
                     || ' ;contact MetLife HO @ 09666 7 16344 / 16344; PRESS Option:  3 - Ext 435 or 662';
                  RAISE vMyException;
               END IF;
            ELSE
               pErrorMessage := 'No Reinstatement against the policy ';
               RAISE vMyException;
            END IF;
         ELSE
            pErrorMessage :=
               'Policy is Not in Force .Check policy policy Number or contact MetLife HO @ 09666 7 16344 / 16344; PRESS Option:  3 - Ext 435 or 662';
            RAISE vMyException;
         END IF;
      END IF;

      IF pPolicyType = 7
      THEN
         IF vPOLSTS = '10' OR vPOLSTS = '20'
         THEN
            pReceiptHeading := 'Money Receipt';
            pOnaccountof := 'Balance Premium';
         ELSE
            pErrorMessage :=
               'Pay type Mismatch, Select correct Pay type or contact Metlife @ 09666 7 16344 / 16344; PRESS Option:  3 - Ext 435 or 662';
            RAISE vMyException;
         END IF;
      END IF;

      pCompany := vCompany;
      pPONAME := vPONAME;
      pPolsts := vPOLSTS;
      pPrmamt := vPrmamt;
      pPrmamtd := vPrmamtd;

      pLoandt := vLoandt;
      pLoanamt := vLoanamt;
      pAplamt := vAplamt;
      pReinstamt := vReinstamt;

      pDuedt := vDuedt;
      pDuedtnxt1 := vDuedtnxt1;
      pDuedtnxt2 := vDuedtnxt2;
      pDuedtnxt3 := vDuedtnxt3;
      pAgentcode := vAgentcode;
      pTkfcopid := vTkfcopid;
      pTdrsts := vTdrsts;
   ELSE
      pErrorMessage :=
         'Policy Number does not exists;Please contact MetLife HO @ 09666 7 16344 / 16344; PRESS Option:  3 – Ext 435 or 662';
      RAISE vMyException;
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN
      pErrorFlag := 'Y';

      ROLLBACK;
END;
/
