CREATE PROCEDURE        bundle_generation (
   p_opbrancd   IN     VARCHAR2,
   p_oprstamp   IN     VARCHAR2,
   p_paymod     IN     VARCHAR2 DEFAULT 'CASH',
   o_bundleno      OUT VARCHAR2,
   o_errflg        OUT VARCHAR2,
   o_errmsg        OUT VARCHAR2)
IS                                                           --v_seq   NUMBER;
   v_seq   VARCHAR2 (20) := NULL;

   CURSOR c1
   IS
      (SELECT COUNT (DISTINCT invoice_no) invoice_no,
              SUM (DECODE (dr_cr_code, 'C', amount, -amount)) amount
         FROM stbmmbil
        WHERE     bundle_stat = 'N'
              AND bundle_no IS NULL
              AND oprstamp = p_oprstamp
              AND paystat = 'P'
              AND paymod = p_paymod
              AND opbrancd = p_opbrancd
              AND to_number(to_char(TIMSTAMP,'HH24MISS')) <= CASE WHEN v('AI_DOCDAT') = DOCDATE THEN 160000
                                                             ELSE to_number(to_char(TIMSTAMP,'HH24MISS'))
                                                             END
       );
BEGIN
   FOR i IN c1
   LOOP
      IF i.invoice_no <> 0
      THEN
         IF i.amount > 0
         THEN
            BEGIN
               SELECT    TO_CHAR (SYSDATE, 'RR')
                      || TO_CHAR (SYSDATE, 'MM')
                      || TO_CHAR (SYSDATE, 'DD')
                      || p_opbrancd
                      || LPAD (
                              NVL (
                                 MAX (
                                    SUBSTR (bundle_no,
                                            10,
                                            LENGTH (bundle_no))),
                                 0)
                            + 1,
                            4,
                            0)
                 INTO v_seq
                 FROM STBUNDGN
                WHERE     OPBRANCD = p_opbrancd
                      AND BUNDLE_NO LIKE
                             (   TO_CHAR (SYSDATE, 'RR')
                              || TO_CHAR (SYSDATE, 'MM')
                              || TO_CHAR (SYSDATE, 'DD')
                              || p_opbrancd
                              || '%');
            END;

            BEGIN
               INSERT INTO stbundgn (bundle_no,
                                     opbrancd,
                                     oprstamp,
                                     timstamp,
                                     tot_invoiceno,
                                     tot_amount,
                                     bundle_stat,
                                     brancd,
                                     actype,
                                     actnum,
                                     appby,
                                     appdate,
                                     tran_createdat)
                    VALUES (v_seq,
                            p_opbrancd,
                            p_oprstamp,
                            SYSDATE,
                            i.invoice_no,
                            i.amount,
                            'Y',
                            NULL,
                            NULL,
                            NULL,
                            NULL,
                            NULL,
                            SYSDATE);
            EXCEPTION
               WHEN OTHERS
               THEN
                  o_errflg := 'E1';
                  o_errmsg := 'An Error has occurred....! ' || SQLERRM;
                  ROLLBACK;
                  RETURN;
            END;

            BEGIN
               UPDATE stbmmbil
                  SET bundle_stat = 'Y', bundle_no = v_seq
                WHERE     bundle_stat = 'N'
                      AND bundle_no IS NULL
                      AND oprstamp = p_oprstamp
                      AND paystat = 'P'
                      AND paymod = p_paymod
                      AND opbrancd = p_opbrancd
                      AND to_number(to_char(TIMSTAMP,'HH24MISS')) <= CASE WHEN v('AI_DOCDAT') = DOCDATE THEN 160000
                                                                     ELSE to_number(to_char(TIMSTAMP,'HH24MISS'))
                                                                     END;

               IF SQL%NOTFOUND
               THEN
                  o_errflg := 'E2';
                  o_errmsg :=
                     'Unable to update bundle status in "stbmmbil"...!';
                  ROLLBACK;
                  RETURN;
               END IF;
            END;
         ELSE
            o_errflg := 'E3';
            o_errmsg :=
               'Bundle Generation is not possible for debit balance....!';
            ROLLBACK;
            RETURN;
         END IF;
      END IF;
   END LOOP;

   IF v_seq IS NULL
   THEN
      o_errflg := 'E4';
      o_errmsg := 'No Records found....!';
      ROLLBACK;
      RETURN;
   ELSE
      o_bundleno := v_seq;
   END IF;
END;
/
