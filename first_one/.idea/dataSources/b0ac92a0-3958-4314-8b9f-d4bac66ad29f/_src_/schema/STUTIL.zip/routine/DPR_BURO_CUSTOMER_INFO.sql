CREATE PROCEDURE        dpr_buro_Customer_Info (
   p_customerCode        IN     VARCHAR2,                -- := 88100000200911,
   o_customerName           OUT VARCHAR2
   )
  /* p_routingNo           IN     VARCHAR2,
   o_id                     OUT NUMBER,
   o_customerCode           OUT VARCHAR2,
   o_customerName           OUT VARCHAR2,
   o_aplianceSummery        OUT VARCHAR2,
   o_connectionAddress      OUT VARCHAR2,
   o_mobile                 OUT VARCHAR2,
   o_errflg                 OUT VARCHAR2,
   o_errmsg                 OUT VARCHAR2) */
IS
   l_param_list            VARCHAR2 (512);
   v_url                   VARCHAR2 (500);
   l_param_list_with_url   VARCHAR2 (512);
   l_http_request          UTL_HTTP.req;
   l_http_response         UTL_HTTP.resp;
   l_response_text         VARCHAR2 (32767);
   v_reqid                 NUMBER;
   v_status                VARCHAR2 (200);
   v_message               VARCHAR2 (500);
   v_invoiceNo             VARCHAR2 (100);
   access_token            VARCHAR2 (500);
   access_token1           VARCHAR2 (500);
   access_token2           VARCHAR2 (500);
   v_err_message           VARCHAR2 (500);

   PRAGMA AUTONOMOUS_TRANSACTION;
--  PRAGMA AUTONOMOUS_TRANSACTION;


BEGIN
  /* BEGIN
      SELECT PARAVAL
        INTO access_token1
        FROM stparamt
       WHERE TYPE = 'TGL' AND subtype = 'API';
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         v_err_message := 'E100 Token not found. Please generate token first.';
         GOTO exception_block;
   END;

   BEGIN
      SELECT PARAVAL
        INTO access_token2
        FROM stparamt
       WHERE TYPE = 'TGL' AND subtype = 'SEC';
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         v_err_message := 'E101 Token not found. Please generate token first.';
         GOTO exception_block;
   END; 

   UTL_HTTP.set_wallet ('file:/u01/app/oracle/product/12.1.0/db_1/wallets',
                        'master123'); --UTL_HTTP.set_wallet ('file:D:\wallets', 'master123');
                        
                        */

   v_url := 'https://burobd.net/imfasBankAsiaSvc/FinanceService.svc/BankAsiaRequestforTransaction?userid=14900&password=14900&billerId=12345&accountNo=11214910101&transcode=1&amount=0&BankAsiatransId=11122559699';

   IF p_customerCode IS NULL
   THEN
      v_err_message := 'E102 Customer Code can not be null. Please check.';
      GOTO exception_block;
   END IF;

  /* IF p_routingNo IS NULL
   THEN
      v_err_message := 'E103 Routing no can not be null. Please check.';
      GOTO exception_block;
   END IF;
 */

   IF p_customerCode IS NOT NULL
   THEN
      l_param_list_with_url := l_param_list_with_url || p_customerCode;
   END IF;

   SELECT NVL (MAX (REQUESTID), 0) + 1 INTO v_reqid FROM IN_OUT_JSON;

   BEGIN
      INSERT INTO IN_OUT_JSON (REQUESTID,
                               REQUEST_name,
                               request,
                               in_time)
           VALUES (v_reqid,
                   'BURO customer information',
                   v_url || l_param_list_with_url,
                   SYSDATE);
   EXCEPTION
      WHEN OTHERS
      THEN
         v_err_message :=
            'E104 Unable to inster data into log table. ' || SQLERRM;
         GOTO exception_block;
   END;



   l_param_list := NULL;

   -- preparing Request...
   l_http_request :=
      UTL_HTTP.begin_request (v_url ,--|| l_param_list_with_url,
                              'GET',
                              'HTTP/1.1');

  -- UTL_HTTP.set_header (l_http_request, 'X-API-KEY', access_token1);

  -- UTL_HTTP.set_header (l_http_request, 'X-AUTH-SECRET', access_token2);

  -- UTL_HTTP.set_header (l_http_request, 'X-ROUTE', 210262533 );--'210262533'); p_routingNo

   --utl_http.set_header(l_http_request, 'Content-Length', length(content.getStringVal())); --Getting Length of Xml being passed


   UTL_HTTP.set_header (l_http_request,
                        'Content-Type',
                        'application/x-www-form-urlencoded');



   -- ...set input parameters
   UTL_HTTP.write_text (l_http_request, l_param_list);

   -- get Response and obtain received value
   l_http_response := UTL_HTTP.get_response (l_http_request);


   UTL_HTTP.read_text (l_http_response, l_response_text);

   ---------------------------statr insert and parse json------------

   DBMS_OUTPUT.put_line ('1. l_response_text ' || l_response_text);

   BEGIN
      UPDATE IN_OUT_JSON
         SET JSON_RESPONSE = l_response_text
       WHERE REQUESTID = v_reqid;
   EXCEPTION
      WHEN OTHERS
      THEN
         v_err_message :=
            'E105 Unable to update response into log table. ' || SQLERRM;
         GOTO exception_block;
   END;



   --- start Parsing -------------
   BEGIN
      SELECT js.JSON_RESPONSE.status, js.JSON_RESPONSE.message
        INTO v_status, v_message
        FROM IN_OUT_JSON js
       WHERE js.REQUESTID = v_reqid;
   EXCEPTION
      WHEN OTHERS
      THEN
         v_err_message := 'E106 Unable to parse JSON data . ' || SQLERRM;
         GOTO exception_block;
   END;

   IF v_status = 'success'
   THEN
      UPDATE IN_OUT_JSON
         SET in_req_status = 'Success', OUT_TIME = SYSDATE
       WHERE REQUESTID = v_reqid;

      BEGIN
         SELECT js.JSON_RESPONSE.status,
                js.JSON_RESPONSE.message,
               -- js.JSON_RESPONSE.data.id,
               -- js.JSON_RESPONSE.data.customerCode,
                js.JSON_RESPONSE.data.customerName
              --  js.JSON_RESPONSE.data.aplianceSummery,
              --  js.JSON_RESPONSE.data.connectionAddress,
               -- js.JSON_RESPONSE.data.mobile
           INTO v_status,
                v_message,
               -- o_id,
               -- o_customerCode,
                o_customerName
              --  o_aplianceSummery,
              --  o_connectionAddress,
               -- o_mobile
           FROM IN_OUT_JSON js
          WHERE js.REQUESTID = v_reqid;
      EXCEPTION
         WHEN OTHERS
         THEN
            v_err_message := 'E107 Unable to parse JSON data . ' || SQLERRM;
            GOTO exception_block;
      END;
   ELSE
      v_err_message :=
            v_status
         || ' '
         || v_message
         || ' . E200 From Titas Gas Server. Please contact with ICT dept.';
      GOTO exception_block;
   END IF;



   GOTO successfull_block;

  ------------------end parsing------------------------------

  <<exception_block>>
  -- DBMS_OUTPUT.put_line ('1.4 l_response_text ' || l_response_text);
   UPDATE IN_OUT_JSON
      SET in_req_status = v_status || ' ' || v_message, OUT_TIME = SYSDATE
    WHERE REQUESTID = v_reqid;


   UTL_HTTP.end_response (l_http_response);
 --  o_errflg := 'E';
 --  o_errmsg := v_err_message;

  -- COMMIT;

  -- finalizing
  <<successfull_block>>                                 --|| l_response_text);
   UTL_HTTP.end_response (l_http_response);
   COMMIT;
EXCEPTION
   WHEN UTL_HTTP.end_of_body
   THEN
    --  o_errflg := 'E';
   --   o_errmsg := 'E300 ' || SQLERRM;
      UTL_HTTP.end_response (l_http_response);
--    COMMIT;
END;
/
