CREATE PROCEDURE        pragati_data (
   l_json_text    IN     VARCHAR2,
   nam            IN     VARCHAR2 DEFAULT NULL,
   polnum            OUT VARCHAR2,
   holder_name1      OUT VARCHAR2,
   holder_name2      OUT VARCHAR2, --if json have only one customer info then no out put in holder_naem2
   dat               OUT DATE,
   installment       OUT NUMBER,
   due               OUT NUMBER,
   total_inst        OUT NUMBER,
   late_fee          OUT NUMBER,
   suspense          OUT NUMBER,
   total_due         OUT NUMBER,
   status            OUT VARCHAR2,
   orderid           OUT VARCHAR2,
   no_sub            OUT NUMBER) -- If json have only on customer info then return all data of the customer.
AS
   l_count      PLS_INTEGER;
   sJsonIndex   APEX_JSON.t_values;
   holder       VARCHAR2 (100);
BEGIN
   APEX_JSON.PARSE (sJsonIndex, l_json_text);
   l_count := APEX_JSON.get_count (p_path => '.', p_values => sJsonIndex);

   --l_json_text:=LTRIM(RTRIM(l_json_text,']'),'[');
   ------------check if json data has multiple account or not---------------
   
   IF l_count > 1
   THEN
      holder_name1 :=
         APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                 p_path     => '[%d].NAME_OF_POLICYHOLDER',
                                 p0         => 1);
      holder_name2 :=
         APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                 p_path     => '[%d].NAME_OF_POLICYHOLDER',
                                 p0         => 2);

      FOR i IN 1 .. l_count
      LOOP
         holder :=
            APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                    p_path     => '[%d].NAME_OF_POLICYHOLDER',
                                    p0         => i);
                                    
        ------------fetch the desired account info according to the name of account holder ------------------------

         IF holder = nam
         THEN
            polnum :=
               apex_json.get_varchar2 (p_values   => sJsonIndex,
                                       p_path     => '[%d].POLICY_NUMBER',
                                       p0         => i);



            dat :=
               APEX_JSON.get_date (p_values   => sJsonIndex,
                                   p_path     => '[%d].DUE_DATE',
                                   p0         => i,
                                   p_format   => 'DD-MON-YY');
            installment :=
               TO_NUMBER (
                  APEX_JSON.get_varchar2 (
                     p_values   => sJsonIndex,
                     p_path     => '[%d].PRM_INSTALLMENT',
                     p0         => i));
            due :=
               TO_NUMBER (
                  APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                          p_path     => '[%d].N_DUE',
                                          p0         => i));
            total_inst :=
               TO_NUMBER (
                  APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                          p_path     => '[%d].TOT_INST',
                                          p0         => i));
            late_fee :=
               TO_NUMBER (
                  APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                          p_path     => '[%d].LATE_FEE',
                                          p0         => i));
            suspense :=
               TO_NUMBER (
                  APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                          p_path     => '[%d].SUSPENSE',
                                          p0         => i));
            total_due :=
               TO_NUMBER (
                  APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                          p_path     => '[%d].TOTAL_DUES',
                                          p0         => i));
            status :=
               APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                       p_path     => '[%d].STATUS',
                                       p0         => i);
            orderid :=
               APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                       p_path     => '[%d].ORDERID',
                                       p0         => i);
            no_sub :=
               TO_NUMBER (
                  APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                          p_path     => '[%d].NO_OF_SUB',
                                          p0         => i));
            DBMS_OUTPUT.put_line (
               'policy : ' || due || late_fee || holder || nam);
         END IF;
      END LOOP;
      -----------------------------end fetching desired account holder info-------------------------------
      
      -------------------start fetching data of a single account user------------------------
   ELSIF l_count = 1
   THEN
      FOR i IN 1 .. l_count
      LOOP
         polnum :=
            apex_json.get_varchar2 (p_values   => sJsonIndex,
                                    p_path     => '[%d].POLICY_NUMBER',
                                    p0         => i);


         holder_name1 :=
            APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                    p_path     => '[%d].NAME_OF_POLICYHOLDER',
                                    p0         => i);
         holder_name2 := NULL;
         dat :=
            APEX_JSON.get_date (p_values   => sJsonIndex,
                                p_path     => '[%d].DUE_DATE',
                                p0         => i,
                                p_format   => 'DD-MON-YY');
         installment :=
            TO_NUMBER (
               APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                       p_path     => '[%d].PRM_INSTALLMENT',
                                       p0         => i));
         due :=
            TO_NUMBER (
               APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                       p_path     => '[%d].N_DUE',
                                       p0         => i));
         total_inst :=
            TO_NUMBER (
               APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                       p_path     => '[%d].TOT_INST',
                                       p0         => i));
         late_fee :=
            TO_NUMBER (
               APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                       p_path     => '[%d].LATE_FEE',
                                       p0         => i));
         suspense :=
            TO_NUMBER (
               APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                       p_path     => '[%d].SUSPENSE',
                                       p0         => i));
         total_due :=
            TO_NUMBER (
               APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                       p_path     => '[%d].TOTAL_DUES',
                                       p0         => i));
         status :=
            APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                    p_path     => '[%d].STATUS',
                                    p0         => i);
         orderid :=
            APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                    p_path     => '[%d].ORDERID',
                                    p0         => i);
         no_sub :=
            TO_NUMBER (
               APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                       p_path     => '[%d].NO_OF_SUB',
                                       p0         => i));
         DBMS_OUTPUT.put_line (
            'policy : ' || due || late_fee || holder || nam);

         IF polnum IS NULL
         THEN
            raise_application_error (
               -20001,
               'Could not find policy number of given JSON');
         END IF;
         
         --------------------end fetching single account data info------------------------

         DBMS_OUTPUT.put_line (
               'policy : '
            || polnum
            || holder_name1
            || dat
            || installment
            || due
            || total_inst
            || late_fee
            || suspense
            || total_due
            || status
            || orderid
            || no_sub);
      END LOOP;
   END IF;
END;
/
