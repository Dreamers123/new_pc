CREATE PROCEDURE        dpr_Metered_add_payment (
   p_invoiceNo             VARCHAR2,                       
   p_customerCode          VARCHAR2,                   
   p_paidAmount            NUMBER DEFAULT 0,                   
   p_sourceTaxAmount       NUMBER DEFAULT 0,                      
   p_revenueStamp          NUMBER DEFAULT 0,                        
   p_transactionDate       VARCHAR2,                        
   p_branchCode            VARCHAR2,                               
   p_branchRoutingNo      varchar,                          
   p_operator              VARCHAR2,                        
   p_refNo                 VARCHAR2,                     
   p_chalanNo              VARCHAR2,                           
   p_chalanDate            VARCHAR2,                         
   p_chalanBank            VARCHAR2,                               
   p_chalanBranch          VARCHAR2,
   p_oprstamp              VARCHAR2, 
   o_paymentid         OUT NUMBER,                                
   o_errflg            OUT VARCHAR2,                                     
   o_err_message       OUT VARCHAR2)
IS
   l_param_list            VARCHAR2 (512);
   l_param_list_with_url   VARCHAR2 (4000);
   v_url                   VARCHAR2 (500);
   l_http_request          UTL_HTTP.req;
   l_http_response         UTL_HTTP.resp;
   l_response_text         VARCHAR2 (32767);
   v_reqid                 NUMBER;
   v_status                NUMBER;
   v_status_message        VARCHAR2 (500);
   v_message               VARCHAR2 (500);
   v_invoiceNo             VARCHAR2 (100);
   access_token            VARCHAR2 (500);
   v_err_message           VARCHAR2 (500);

   PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   -- service's input parameters


   UTL_HTTP.set_wallet('file:/oraclehome/certificate', 'master123');

   v_url := 'http://payments.titasgas.org.bd/metered/payment/add?';

   --UTL_HTTP.set_wallet ('file:D:\wallets', 'master123');

   IF p_invoiceNo IS NULL
   THEN
      v_err_message := 'E090 Invoice Number is required. Please check.';
      GOTO exception_block;
   END IF;

   IF p_customerCode IS NULL
   THEN
      v_err_message := 'E090 Customer Code is required. Please check.';
      GOTO exception_block;
   END IF;


   IF p_paidAmount < 1
   THEN
      v_err_message :=
         'E090 Paid amount can not be less then 1. Please check.';
      GOTO exception_block;
   END IF;

   IF p_transactionDate IS NULL
   THEN
      v_err_message := 'E090 Transaction Date is required. Please check.';
      GOTO exception_block;
   END IF;

   IF p_branchRoutingNo IS NULL
   THEN
      v_err_message := 'E090 Branch Routing No is required. Please check.';
      GOTO exception_block;
   END IF;

   IF p_operator IS NULL
   THEN
      v_err_message := 'E090 Operator value is required. Please check.';
      GOTO exception_block;
   END IF;

   IF p_refNo IS NULL
   THEN
      v_err_message := 'E090 Reference No is required. Please check.';
      GOTO exception_block;
   END IF;

   IF p_sourceTaxAmount > 0
   THEN
      IF p_chalanNo IS NULL
      THEN
         v_err_message := 'E091 Chalan No is required. Please check.';
         GOTO exception_block;
      END IF;

      IF p_chalanDate IS NULL
      THEN
         v_err_message := 'E092 Chalan date is required. Please check.';
         GOTO exception_block;
      END IF;
   END IF;

   BEGIN
      SELECT PARAVAL
        INTO access_token
        FROM stparamt
       WHERE TYPE = 'TGL' AND subtype = 'TKN' AND RESPONSECODE = 2;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         v_err_message := 'Token not found. Please generate token first.';
         GOTO exception_block;
   END;

   IF p_invoiceNo IS NOT NULL
   THEN
      l_param_list_with_url :=
         l_param_list_with_url || 'invoiceNo=' || p_invoiceNo;
   END IF;

   IF p_customerCode IS NOT NULL
   THEN
      l_param_list_with_url :=
         l_param_list_with_url || '&customerCode=' || p_customerCode;
   END IF;

   IF p_paidAmount IS NOT NULL
   THEN
      l_param_list_with_url :=
         l_param_list_with_url || '&paidAmount=' || p_paidAmount;
   END IF;

   IF p_sourceTaxAmount IS NOT NULL
   THEN
      l_param_list_with_url :=
         l_param_list_with_url || '&sourceTaxAmount=' || p_sourceTaxAmount;
   END IF;

   IF p_revenueStamp IS NOT NULL
   THEN
      l_param_list_with_url :=
         l_param_list_with_url || '&revenueStamp=' || p_revenueStamp;
   END IF;

   IF p_transactionDate IS NOT NULL
   THEN
      l_param_list_with_url :=
         l_param_list_with_url || '&transactionDate=' || p_transactionDate;
   END IF;

   IF p_branchCode IS NOT NULL
   THEN
      l_param_list_with_url :=
         l_param_list_with_url || '&branchCode=' || p_branchCode;
   END IF;

   IF p_branchRoutingNo IS NOT NULL
   THEN
      l_param_list_with_url :=
         l_param_list_with_url || '&branchRoutingNo=' || p_branchRoutingNo;
   END IF;

   IF p_operator IS NOT NULL
   THEN
      l_param_list_with_url :=
         l_param_list_with_url || '&operator=' || p_operator;
   END IF;

   IF p_refNo IS NOT NULL
   THEN
      l_param_list_with_url := l_param_list_with_url || '&refNo=' || p_refNo;
   END IF;

   IF p_chalanNo IS NOT NULL
   THEN
      l_param_list_with_url :=
         l_param_list_with_url || '&chalanNo=' || p_chalanNo;
   END IF;

   IF p_chalanDate IS NOT NULL
   THEN
      l_param_list_with_url :=
         l_param_list_with_url || '&chalanDate=' || p_chalanDate;
   END IF;

   IF p_chalanBank IS NOT NULL
   THEN
      l_param_list_with_url :=
         l_param_list_with_url || '&chalanBank=' || p_chalanBank;
   END IF;

   IF p_chalanBranch IS NOT NULL
   THEN
      l_param_list_with_url :=
         l_param_list_with_url || '&chalanBranch=' || p_chalanBranch;
   END IF;

   ---------------------------statr insert and parse json------------


   SELECT NVL (MAX (REQUESTID), 0) + 1 INTO v_reqid FROM IN_OUT_JSON;

   BEGIN
      INSERT INTO IN_OUT_JSON (REQUESTID,
                               REQUEST_name,
                               request,
                               JSON_RESPONSE,
                               in_time,
                               PAYMENT_ID,
                               OPRSTAMP)
           VALUES (v_reqid,
                   'Add Metered Payment',
                   v_url || l_param_list_with_url,
                   l_response_text,
                   SYSDATE,
                   p_customerCode,
                   p_oprstamp);

   EXCEPTION
      WHEN OTHERS
      THEN
         v_err_message :=
            'E101 Unable to insert data into log table. ' || SQLERRM;
         GOTO exception_block;
   END;

   l_param_list := NULL;

   DBMS_OUTPUT.put_line (v_url || l_param_list_with_url);
   l_http_request :=
      UTL_HTTP.begin_request (v_url || l_param_list_with_url,
                              'POST',
                              'HTTP/1.1');

   --'https://payments.titasgas.org.bd/metered/payment/add?'

   UTL_HTTP.set_header (l_http_request,
                        'Authorization',
                        'Bearer ' || access_token);

   -- ...set input parameters
   UTL_HTTP.write_text (l_http_request, l_param_list);

   -- get Response and obtain received value
   l_http_response := UTL_HTTP.get_response (l_http_request);


   UTL_HTTP.read_text (l_http_response, l_response_text);

   UPDATE IN_OUT_JSON
      SET JSON_RESPONSE = l_response_text,
          REQUEST_name = 'Add Metered Payment Done'
    WHERE REQUESTID = v_reqid
    AND OPRSTAMP = p_oprstamp;

   --- start Parsing -------------
   BEGIN
      SELECT js.JSON_RESPONSE.status, js.JSON_RESPONSE.message
        INTO v_status, v_err_message
        FROM IN_OUT_JSON js
       WHERE js.REQUESTID = v_reqid
       AND OPRSTAMP = p_oprstamp;
   EXCEPTION
      WHEN OTHERS
      THEN
         v_err_message := 'E102 Unable to parse JSON data . ' || SQLERRM;
         GOTO exception_block;
   END;



   --DBMS_OUTPUT.put_line ('3. '||v_status||' ' || v_err_message);


   IF v_status = 200
   THEN
      BEGIN
         SELECT js.JSON_RESPONSE.data.paymentId
           INTO o_paymentid
           FROM IN_OUT_JSON js
          WHERE js.REQUESTID = v_reqid
          AND OPRSTAMP = p_oprstamp;
      EXCEPTION
         WHEN OTHERS
         THEN
            v_err_message := 'E103 Unable to parse JSON data . ' || SQLERRM;
            GOTO exception_block;
      END;

      UPDATE IN_OUT_JSON
         SET in_req_status = 'Success'
       WHERE REQUESTID = v_reqid
       AND OPRSTAMP = p_oprstamp;
   ELSE
      UPDATE IN_OUT_JSON
         SET in_req_status = v_status || l_response_text
       WHERE REQUESTID = v_reqid
       AND OPRSTAMP = p_oprstamp;

      v_err_message :=
         v_status || ' ' || v_err_message || ' from Titas Server.';
      GOTO exception_block;
   END IF;

   UPDATE IN_OUT_JSON
      SET in_req_status = v_err_message
    WHERE REQUESTID = v_reqid
    AND OPRSTAMP = p_oprstamp;

   --commit;

   ------------------end parsing------------------------------

   --o_message := v_status_message;


   DBMS_OUTPUT.put_line (l_response_text);

   GOTO successfull_block;

  ------------------end parsing------------------------------

  <<exception_block>>
   UTL_HTTP.end_response (l_http_response);
   o_errflg := 'E';
   o_err_message := v_err_message;

  --COMMIT;



  -- finalizing
  <<successfull_block>>
   UTL_HTTP.end_response (l_http_response);
   COMMIT;
EXCEPTION
   WHEN UTL_HTTP.end_of_body
   THEN
      UTL_HTTP.end_response (l_http_response);
      v_err_message := 'end_of_body exception. ' || SQLERRM;

      UPDATE IN_OUT_JSON
         SET in_req_status = v_err_message
       WHERE REQUESTID = v_reqid;

      COMMIT;
   WHEN OTHERS
   THEN
      UTL_HTTP.end_response (l_http_response);
      v_err_message := 'Other exception. ' || SQLERRM;

      UPDATE IN_OUT_JSON
         SET in_req_status = v_err_message
       WHERE REQUESTID = v_reqid;

      COMMIT;
END;
/
