CREATE PROCEDURE WRAPPED stutil.PROC_CREATE_PASSWORD_LC (
   USERID    IN     VARCHAR2,
   PASSWD    IN     VARCHAR2,
   ENCPASS      OUT VARCHAR2)
IS
   VAR1      NUMBER;
   VAR2      NUMBER;
   VAR3      NUMBER;
   VAR4      NUMBER;
   VAR5      NUMBER;
   VAR55     NUMBER;
   VAR6      NUMBER;
   VAR7      NUMBER;
   VAR8      NUMBER;
   VAR9      NUMBER;
   VAR10     NUMBER;
   VAR66     NUMBER;
   MUL1      NUMBER;
   MUL2      NUMBER;
   MUL3      NUMBER;
   MUL4      NUMBER;
   MUL5      NUMBER;
   MUL6      NUMBER;
   MULFIN    VARCHAR2 (30);
   MULLEN    NUMBER;
   LOOPFOR   NUMBER;
   STORE     VARCHAR2 (30);
   CTR       NUMBER;
   I         NUMBER;
   SUBS      NUMBER;
BEGIN
   IF NVL (LENGTH (USERID), 0) < 6
   THEN
      RAISE_APPLICATION_ERROR (
         -20004,
         'Length of Userid should be 6 Characters long ');
   ELSIF NVL (LENGTH (PASSWD), 0) < 6
   THEN
      RAISE_APPLICATION_ERROR (
         -20004,
         'Length of Password should be at least 6 Characters long ');
   END IF;

   VAR1 := ASCII (SUBSTR (USERID, 1, 1));
   VAR2 := ASCII (SUBSTR (USERID, 2, 1));
   VAR3 := ASCII (SUBSTR (USERID, 3, 1));
   VAR4 := ASCII (SUBSTR (USERID, 4, 1));
   VAR5 := ASCII (SUBSTR (USERID, 5, 1));
   VAR55 := ASCII (SUBSTR (USERID, 6, 1));



   VAR2 := VAR2 * 2;
   VAR3 := VAR3 * 3;
   VAR4 := VAR4 * 4;
   VAR5 := VAR5 * 5;
   VAR55 := VAR55 * 1;

   VAR6 := ASCII (SUBSTR (PASSWD, 1, 1));
   VAR7 := ASCII (SUBSTR (PASSWD, 2, 1));
   VAR8 := ASCII (SUBSTR (PASSWD, 3, 1));
   VAR9 := ASCII (SUBSTR (PASSWD, 4, 1));
   VAR10 := ASCII (SUBSTR (PASSWD, 5, 1));
   VAR66 := ASCII (SUBSTR (PASSWD, 6, 1));



   VAR7 := VAR7 * 2;
   VAR8 := VAR8 * 3;
   VAR9 := VAR9 * 4;
   VAR10 := VAR10 * 5;
   VAR66 := VAR66 * 1;



   MUL1 := VAR1 * VAR10;
   MUL2 := VAR2 * VAR9;
   MUL3 := VAR3 * VAR8;
   MUL4 := VAR4 * VAR7;
   MUL5 := VAR5 * VAR6;
   MUL6 := VAR55 * VAR66;

   MULFIN :=
         TO_CHAR (MUL1)
      || TO_CHAR (MUL2)
      || TO_CHAR (MUL3)
      || TO_CHAR (MUL4)
      || TO_CHAR (MUL5)
      || TO_CHAR (MUL6);

   MULLEN := NVL (LENGTH (MULFIN), 0);

   IF MOD (MULLEN, 3) != 0
   THEN
      LOOPFOR := (FLOOR (MULLEN / 3)) + 1;
   ELSE
      LOOPFOR := (MULLEN / 2);
   END IF;

   CTR := 1;
   I := 1;

   LOOP
      SUBS := SUBSTR (MULFIN, I, 2);

      IF SUBS NOT BETWEEN 48 AND 57
      THEN
         IF SUBS > 90
         THEN
            LOOP
               SUBS := SUBS - 26;
               EXIT WHEN SUBS < 91;
            END LOOP;
         END IF;

         IF SUBS < 65
         THEN
            LOOP
               SUBS := SUBS + 26;
               EXIT WHEN SUBS > 64;
            END LOOP;
         END IF;
      END IF;

      STORE := STORE || CHR (SUBS);
      EXIT WHEN CTR = LOOPFOR;
      CTR := CTR + 1;
      I := I + 3;
   END LOOP;

   ENCPASS := STORE;
END;
/
