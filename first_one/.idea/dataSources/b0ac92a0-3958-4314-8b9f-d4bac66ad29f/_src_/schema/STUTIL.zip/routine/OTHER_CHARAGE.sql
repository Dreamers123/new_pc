CREATE PROCEDURE        other_charage (p_service_id  in  VARCHAR2,
                                p_amount      in  NUMBER,
                                p_charge_id   in  VARCHAR2,
                                o_vat    out     number,
                                o_charge out     number,
                                o_stemp  out     number)
IS
v_charge number;
v_vat number;
v_min_charge number; 
BEGIN
   
   BEGIN
   SELECT C.CHARGE ,C.VATPER,C.MINAM into v_charge,v_vat,v_min_charge
   FROM STUTIL.STCHINFO C
   WHERE C.SERVICENO = p_service_id AND ID = '1' ;
   EXCEPTION
   WHEN NO_DATA_FOUND THEN
   NULL ;
   END ;
   
   o_charge := case when (p_amount * v_charge)/100 > v_min_charge then (p_amount * v_charge)/100 
               else v_min_charge end ;
   o_vat:= (o_charge * v_vat)/100 ;
   o_stemp:= case when p_amount> 399 then 10 
              else 0 end ;
              
dbms_output.put_line (o_charge||'---'||o_vat||'----'||o_stemp);              
END;
/
