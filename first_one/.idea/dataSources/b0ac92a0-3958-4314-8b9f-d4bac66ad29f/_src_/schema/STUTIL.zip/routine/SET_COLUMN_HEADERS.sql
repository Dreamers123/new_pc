CREATE procedure set_column_headers
  (p_service varchar2)
is
  cursor c_columns
  is
    SELECT COLUMNNM l_columns
     FROM STUTIL.STUTLPAR_DC
    WHERE SERVICE_ID = p_service
    order by SRLNUMBR;
  
  type column_rec is record ( column_name varchar2(30) );
  type columns_table is table of column_rec;
  t_columns columns_table;
begin 
  open  c_columns;
  fetch c_columns bulk collect into t_columns;
  close c_columns;
  
  for i in 1 .. t_columns.count
  loop
    apex_util.set_session_state( p_name  => 'PXX_C0'||lpad(i,2,0),
                                 p_value => t_columns(i)
                               );
  end loop;
  
  exception when others
  then
    if c_columns%isopen
    then
      close c_columns;
    end if;
end;
/
