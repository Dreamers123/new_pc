CREATE PROCEDURE        dpr_getacglcode (
   p_dblink   IN     VARCHAR2,
   p_brancd   IN     VARCHAR2,
   p_actype   IN     VARCHAR2,
   p_docdate  IN     VARCHAR2,
   p_glcode        OUT VARCHAR2,
   p_errflg        OUT VARCHAR2,
   p_errmsg        OUT VARCHAR2)
IS
    v_sql   VARCHAR2 (4000) := NULL;
BEGIN
    v_sql := 'SELECT glcode
              FROM stlbas.faccur@'
      || p_dblink||'
             WHERE     brancd = :brancd
                   AND actype = :actype
                   AND typcde = ''GEN''
                   AND curcde = ''BDT''
                   AND effdat =
                          (SELECT MAX (effdat)
                             FROM stlbas.faccur@'|| p_dblink||' 
                            WHERE     brancd = :brancd
                                  AND actype = :actype
                                  AND typcde = ''GEN''
                                  AND curcde = ''BDT''
                                  AND effdat <= :docdate)';
   EXECUTE IMMEDIATE v_sql INTO p_glcode USING p_brancd, p_actype,p_brancd,p_actype, p_docdate;
EXCEPTION
   WHEN OTHERS
   THEN
      p_errflg := 'E';
      p_errmsg := 'Exception Error : ' || SQLERRM;
END;
/
