CREATE FUNCTION        "GET_DEC_VAL"(p_enc_value   IN   RAW, p_key   IN   RAW)
   RETURN VARCHAR2
/*Here "p_in" is the password of a user which is stored in sec_user_info
  And  "p_key" is the key which is used to decrypt the password.
  Note: "p_key" is created by using following method,p_key:=fun_hash_encrypt("user_nm") */
IS
   l_ret                         VARCHAR2(2000);
   l_dec_val                     RAW(8000);
   l_mod                         NUMBER
      :=   dbms_crypto.encrypt_aes256
         + dbms_crypto.CHAIN_ecb
         + dbms_crypto.pad_pkcs5;
BEGIN
   l_dec_val                  := dbms_crypto.decrypt( p_enc_value
                                                    , l_mod
                                                    , p_key
                                                    );
   l_ret                      := utl_i18n.raw_to_char( l_dec_val, 'AL32UTF8' );
   RETURN l_ret;
END;
/
