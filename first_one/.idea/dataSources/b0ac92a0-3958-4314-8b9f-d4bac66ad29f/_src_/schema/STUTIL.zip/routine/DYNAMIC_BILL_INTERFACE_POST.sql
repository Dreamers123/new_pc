CREATE PROCEDURE        dynamic_bill_interface_post (
   P_SERVICE_ID            IN     VARCHAR2,
   P_TRANID                IN     VARCHAR2,
   P_AI_BRANCH_CODE        IN     VARCHAR2,
   P_APP_USER              IN     VARCHAR2,
   P_APEX_APPLICATION_1    IN     VARCHAR2,
   P_APEX_APPLICATION_2    IN     VARCHAR2,
   P_APEX_APPLICATION_3    IN     VARCHAR2,
   P_APEX_APPLICATION_4    IN     VARCHAR2,
   P_APEX_APPLICATION_5    IN     VARCHAR2,
   P_APEX_APPLICATION_6    IN     VARCHAR2,
   P_APEX_APPLICATION_7    IN     VARCHAR2,
   P_APEX_APPLICATION_8    IN     VARCHAR2,
   P_APEX_APPLICATION_9    IN     VARCHAR2,
   P_APEX_APPLICATION_10   IN     VARCHAR2,
   P_APEX_APPLICATION_11   IN     VARCHAR2,
   P_APEX_APPLICATION_12   IN     VARCHAR2,
   P_APEX_APPLICATION_13   IN     VARCHAR2,
   P_OUT_PUT_1                OUT VARCHAR2,
   P_OUT_PUT_2                OUT VARCHAR2,
   P_OUT_PUT_3                OUT VARCHAR2,
   P_ERROR_MEG                OUT VARCHAR2,
   P_ERROR_FLG                OUT VARCHAR2)
IS
   v_p_id                  NUMBER;
   v_p_amount              NUMBER;
   v_p_surcharge           NUMBER;
   v_p_particulars         VARCHAR2 (200);
   --  v_p_bankTransactionId   VARCHAR2 (200);
   v_p_cellPhone           VARCHAR2 (200);
   --  v_p_routingNo           VARCHAR2 (200);
   --  v_o_id                  VARCHAR2 (200);
   --  v_o_bank                VARCHAR2 (200);
   --  v_o_batchNo             VARCHAR2 (200);
   --  v_o_amount              NUMBER;
   v_o_surcharge           NUMBER;
   v_o_total               NUMBER;
   --  v_o_voucherDate         VARCHAR2 (200);
   v_o_particulars         VARCHAR2 (200);
   --  v_o_bankTransactionId   VARCHAR2 (200);
   --  v_o_errflg              VARCHAR2 (200);
   --  v_o_errmsg              VARCHAR2 (200);

   -- Demand Note Payment
   v_p_invoiceNo           VARCHAR2 (100);
   v_p_customerId          VARCHAR2 (100);
   v_p_bankTransactionId   VARCHAR2 (100);
   v_p_routingNo           VARCHAR2 (100);
   v_o_id                  VARCHAR2 (100);
   v_o_bank                VARCHAR2 (100);
   v_o_amount              NUMBER;
   v_o_voucherDate         VARCHAR2 (100);
   v_o_bankTransactionId   VARCHAR2 (100);
   v_o_batchNo             VARCHAR2 (100);
   v_o_errflg              VARCHAR2 (100) NULL;
   v_o_errmsg              VARCHAR2 (200) NULL;
   v_row                   NUMBER;
   V_COUNT                 NUMBER;
   V_COUNTNM               NUMBER := 0;
   V_TIMES                 VARCHAR2 (100);
BEGIN
   IF P_SERVICE_ID = 'TITAS_NON_M'
   THEN
      --raise_application_error(-20001,'ATESTDSFDS');

      BEGIN
         v_p_id := P_APEX_APPLICATION_1;
         v_p_amount := P_APEX_APPLICATION_12;
         v_p_surcharge := P_APEX_APPLICATION_8;
         v_p_particulars := P_APEX_APPLICATION_9;
         v_p_bankTransactionId := P_TRANID;
         v_p_cellPhone := P_APEX_APPLICATION_10;
         v_p_routingNo := P_APEX_APPLICATION_11;

       /*   raise_application_error (
              -20005,
                 'v_p_id'
              || v_p_id
              || 'v_p_amount'
              || v_p_amount
              || 'v_p_surcharge'
              || v_p_surcharge
              || 'v_p_particulars'
              || v_p_particulars
              || 'v_p_bankTransactionId'
              || v_p_bankTransactionId
              || 'v_p_cellPhone'
              || v_p_cellPhone
              || 'v_p_routingNo'
              || v_p_routingNo);   */
         
                  STUTIL.dpr_nonmetered_payment_entry (
                     p_id                  => v_p_id,
                     p_amount              => v_p_amount,
                     p_surcharge           => v_p_surcharge,
                     p_particulars         => v_p_particulars,
                     p_bankTransactionId   => v_p_bankTransactionId,
                     p_cellPhone           => v_p_cellPhone,
                     p_oprstamp            => P_APP_USER,
                     p_routingNo           => v_p_routingNo,
                     o_id                  => v_o_id,
                     o_bank                => v_o_bank,
                     o_batchNo             => v_o_batchNo,
                     o_amount              => v_o_amount,
                     o_surcharge           => v_o_surcharge,
                     o_total               => v_o_total,
                     o_voucherDate         => v_o_voucherDate,
                     o_particulars         => v_o_particulars,
                     o_bankTransactionId   => v_o_bankTransactionId,
                     o_errflg              => v_o_errflg,
                     o_errmsg              => v_o_errmsg); 

             IF v_o_errmsg IS NULL and v_o_id is not null  THEN
             UPDATE STUTIL.STUTLINF
             SET OUT_ID=v_o_id,
               OUT_ROUTING=v_p_routingNo
             WHERE TRNID = P_TRANID ;
             COMMIT ;
             else
             raise_application_error(-20003,'v_o_errmsg-'||v_o_errmsg);
             END IF ;   
         P_OUT_PUT_1:= v_o_id ;
         P_ERROR_MEG:= v_o_errmsg ;
         P_ERROR_FLG:= v_o_errflg ;
      /*   IF v_o_errmsg IS NULL AND v_o_errflg IS NULL
         THEN
            APEX_APPLICATION.g_print_success_message :=
                  '<spanstyle="color:white">Successfully Approved.Customer ID.'
               || v_o_id
               || '</span>';
         END IF; */
      END;
   ELSIF P_SERVICE_ID = 'TITAS_NON_M_DEMAND_NOTE'
   THEN
      BEGIN
         v_p_invoiceNo := P_APEX_APPLICATION_1;
         v_p_customerId := P_APEX_APPLICATION_5;
         v_p_bankTransactionId := P_TRANID;
         v_p_routingNo := P_APEX_APPLICATION_9;

         --  RAISE_APPLICATION_ERROR(-20003,'v_p_invoiceNo-'||v_p_invoiceNo||'v_p_customerId-'||v_p_customerId||'v_p_bankTransactionId-'||v_p_bankTransactionId||'v_p_routingNo-'||v_p_routingNo);
              dpr_nonmetered_demand_paymnet (
                  p_invoiceNo           => v_p_invoiceNo,
                  p_customerId          => v_p_customerId,
                  p_bankTransactionId   => v_p_bankTransactionId,
                  p_routingNo           => v_p_routingNo,
                  p_oprstamp            => P_APP_USER,
                  o_id                  => v_o_id,
                  o_bank                => v_o_bank,
                  o_amount              => v_o_amount,
                  o_voucherDate         => v_o_voucherDate,
                  o_bankTransactionId   => v_o_bankTransactionId,
                  o_batchNo             => v_o_batchNo,
                  o_errflg              => v_o_errflg,
                  o_errmsg              => v_o_errmsg); 
         IF v_o_id IS NOT NULL
         THEN
         P_OUT_PUT_1:=v_o_id ;
         P_ERROR_MEG:= v_o_errmsg ;
         P_ERROR_FLG:= v_o_errflg ;
         
            UPDATE STUTIL.STUTLINF
               SET OUT_ID = v_o_id, OUT_ROUTING = v_p_routingNo
             WHERE TRNID = P_TRANID;

            COMMIT;
         ELSE
            raise_application_error (
               -20003,
               'Collection is Not Complete!!!' || v_o_errmsg);
         END IF;
             
       /*  IF v_o_errmsg IS NULL AND v_o_errflg IS NULL
         THEN
            APEX_APPLICATION.g_print_success_message :=
                  '<spanstyle="color:white">Successfully Approved.Customer ID.'
               || v_o_id
               || '</span>';
         END IF; */
      END;
   ELSIF P_SERVICE_ID = 'TITAS_METERED'
   THEN
      DECLARE
         v_p_invoiceNo         VARCHAR2 (100) := P_APEX_APPLICATION_1;
         v_p_customerCode      VARCHAR2 (100) := P_APEX_APPLICATION_2;
         v_p_paidAmount        NUMBER := P_APEX_APPLICATION_6 - 10;
         v_p_sourceTaxAmount   NUMBER := P_APEX_APPLICATION_5;
         v_p_revenueStamp      NUMBER := P_APEX_APPLICATION_13;
         v_p_transactionDate   VARCHAR2 (100)
            := TO_NUMBER (TO_CHAR (SYSDATE, 'yyyymmdd')); --APEX_APPLICATION.G_f01 (11);
         v_p_branchCode        VARCHAR2 (100) := P_AI_BRANCH_CODE;
         v_p_branchRoutingNo   VARCHAR2 (100);                --:='070480197';
         v_p_operator          VARCHAR2 (100) := P_APP_USER;
         v_p_refNo             VARCHAR2 (100)
                                  := P_APP_USER || P_AI_BRANCH_CODE;
         v_p_chalanNo          VARCHAR2 (100) := P_APEX_APPLICATION_8;
         v_p_chalanDate        VARCHAR2 (100) := P_APEX_APPLICATION_9;
         v_p_chalanBank        VARCHAR2 (100) := P_APEX_APPLICATION_10;
         v_p_chalanBranch      VARCHAR2 (100) := P_APEX_APPLICATION_11;
         v_o_paymentid         NUMBER;
         v_o_errflg            VARCHAR2 (100);
         v_o_errmsg            VARCHAR2 (100);
      BEGIN
         /*   raise_application_error(-20003,'v_p_invoiceNo'||v_p_invoiceNo||'v_p_customerCode '||v_p_customerCode||'v_p_paidAmount'||v_p_paidAmount||'v_p_sourceTaxAmount'||
                                   v_p_sourceTaxAmount||'v_p_revenueStamp'||v_p_revenueStamp||'v_p_transactionDate'||v_p_transactionDate||'v_p_branchRoutingNo'||v_p_branchRoutingNo||
                                   'v_p_operator'||v_p_operator||'v_p_refNo'||v_p_refNo); */
         SELECT ROUTNO
           INTO v_p_branchRoutingNo
           FROM stlbas.stbaninf@STUTLTOCBS
          WHERE GRPCDE = '001' AND BRANCD = P_AI_BRANCH_CODE;

            STUTIL.dpr_Metered_add_payment (
               p_invoiceNo         => v_p_invoiceNo,
               p_customerCode      => v_p_customerCode,
               p_paidAmount        => v_p_paidAmount,
               p_sourceTaxAmount   => v_p_sourceTaxAmount,
               p_revenueStamp      => v_p_revenueStamp,
               p_transactionDate   => v_p_transactionDate,
               p_branchCode        => v_p_branchCode,
               p_branchRoutingNo   => v_p_branchRoutingNo,
               p_operator          => v_p_operator,
               p_refNo             => v_p_refNo,
               p_chalanNo          => v_p_chalanNo,
               p_chalanDate        => v_p_chalanDate,
               p_chalanBank        => replace(v_p_chalanBank,' ','_'),
               p_chalanBranch      => replace(v_p_chalanBranch,' ','_'),
               p_oprstamp          => P_APP_USER,
               o_paymentid         => v_o_paymentid,
               o_errflg            => v_o_errflg,
               o_err_message       => v_o_errmsg); 

         IF v_o_errmsg IS NULL AND v_o_paymentid IS NOT NULL
         THEN
            
         P_OUT_PUT_1:=v_o_paymentid ;
         P_ERROR_MEG:= v_o_errmsg ;
         P_ERROR_FLG:= v_o_errflg ;
             
            UPDATE STUTIL.STUTLINF
               SET OUT_ID = v_o_paymentid
             WHERE TRNID = P_TRANID;

            COMMIT;
         ELSE
            ROLLBACK;
            raise_application_error (
               -20001,
               v_o_errmsg || 'Paymnet is not Complete !!!');
         END IF;


         IF v_o_errmsg IS NULL AND v_o_errflg IS NULL
         THEN
            /*  BEGIN
                 UPDATE STUTLINF
                    SET APPFLG = 'Y',
                        OPRSTAMP_APP = :APP_USER,
                        TIMSTAMP_APP = SYSDATE
                  WHERE     UPPER (SERVICE_ID) = UPPER ( :P165_SERVICE_ID)
                        AND TRNID = :P165_TRANID
                        AND APPFLG = 'N';

                 -- AND OPRSTAMP <> :APP_USER ;

                 IF SQL%NOTFOUND
                 THEN
                    ROLLBACK;
                    raise_application_error (-20001,
                                             'You are not allowed to Collection !');
                    ROLLBACK;
                    RETURN;
                 END IF;
              EXCEPTION
                 WHEN OTHERS
                 THEN
                    ROLLBACK;
                    raise_application_error (
                       -20001,
                       'STUTLINF Update Failed! ERROR: ' || SQLERRM);
                    ROLLBACK;
                    RETURN;
              END; */

           /*     P_OUT_PUT_1:=v_o_paymentid ;

            APEX_APPLICATION.g_print_success_message :=
                  '<spanstyle="color:white">Successfully Collected.Customer ID.'
               || v_o_paymentid
               || '</span>'; */
               null;
         ELSE
            ROLLBACK;
            APEX_APPLICATION.g_print_success_message :=
               '<spanstyle="color:white">Error-' || v_o_errmsg || '</span>';
            RAISE_APPLICATION_ERROR (-20001, 'Error:-' || v_o_errmsg);
         END IF;
      END;
   END IF;
END;
/
