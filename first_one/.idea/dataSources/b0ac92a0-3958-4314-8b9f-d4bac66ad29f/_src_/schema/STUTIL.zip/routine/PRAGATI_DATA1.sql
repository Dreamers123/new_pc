CREATE procedure pragati_data1(l_json_text IN varchar2,
                                                    nam IN varchar2,
                                                    polnum OUT VARCHAR2,
                                                    holder OUT VARCHAR2,
                                                    dat OUT DATE,
                                                    installment OUT VARCHAR2,
                                                    due OUT VARCHAR2,
                                                    total_inst OUT VARCHAR2,
                                                    late_fee OUT VARCHAR2,
                                                    suspense OUT VARCHAR2,
                                                    total_due OUT VARCHAR2,
                                                    status OUT VARCHAR2,
                                                    orderid OUT VARCHAR2,
                                                    no_sub OUT VARCHAR2)
as 
l_count     PLS_INTEGER;
sJsonIndex         APEX_JSON.t_values;

begin
    APEX_JSON.PARSE(sJsonIndex,l_json_text);               
    l_count := APEX_JSON.get_count(p_path=>'.', p_values=> sJsonIndex);
    --l_json_text:=LTRIM(RTRIM(l_json_text,']'),'[');  
    if l_count > 1 then            
    for i in 1..l_count
    loop
        holder := APEX_JSON.get_varchar2(p_values=> sJsonIndex,p_path => '[%d].NAME_OF_POLICYHOLDER', p0 => i);
        if holder = nam then
        
        polnum := apex_json.get_varchar2 (p_values   => sJsonIndex,
                                 p_path     => '[%d].POLICY_NUMBER',
                                 p0         => i) ;
                                 
             
        
        dat := APEX_JSON.get_date(p_values   => sJsonIndex,p_path => '[%d].DUE_DATE', p0 => i,p_format => 'DD-MON-YY');
        installment := APEX_JSON.get_varchar2(p_values   => sJsonIndex,p_path => '[%d].PRM_INSTALLMENT', p0 => i);
        due := APEX_JSON.get_varchar2(p_values   => sJsonIndex,p_path => '[%d].N_DUE', p0 => i);
        total_inst := APEX_JSON.get_varchar2(p_values   => sJsonIndex,p_path => '[%d].TOT_INST', p0 => i);
        late_fee := APEX_JSON.get_varchar2(p_values   => sJsonIndex,p_path => '[%d].LATE_FEE', p0 => i);
        suspense := APEX_JSON.get_varchar2(p_values   => sJsonIndex,p_path => '[%d].SUSPENSE', p0 => i);
        total_due := APEX_JSON.get_varchar2(p_values   => sJsonIndex,p_path => '[%d].TOTAL_DUES', p0 => i);
        status := APEX_JSON.get_varchar2(p_values   => sJsonIndex,p_path => '[%d].STATUS', p0 => i);
        orderid := APEX_JSON.get_varchar2(p_values   => sJsonIndex,p_path => '[%d].ORDERID', p0 => i);
        no_sub := APEX_JSON.get_varchar2(p_values   => sJsonIndex,p_path => '[%d].NO_OF_SUB', p0 => i);
        
        
        dbms_output.put_line('policy : '||polnum ||holder||dat||installment||due||total_inst||late_fee||suspense||total_due||status||orderid||no_sub);
        end if;  
    end loop;
    end if;
    
end;
/
