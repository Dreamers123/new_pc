CREATE PROCEDURE        dpr_access_token (errflg   OUT VARCHAR2,
                                                      errmsg   OUT VARCHAR2)
IS
   l_param_list      VARCHAR2 (512);

   l_http_request    UTL_HTTP.req;
   l_http_response   UTL_HTTP.resp;
   l_response_text   VARCHAR2 (32767);
   v_status          VARCHAR2 (200);
   v_message         VARCHAR2 (500);
   v_reqid           NUMBER;
   o_access_token    VARCHAR2 (500);
   v_url             VARCHAR2 (500);
BEGIN
   UTL_HTTP.set_wallet ('file:/u01/app/oracle/product/12.1.0/db_1/wallets',
                        'master123');

   ----
   --UTL_HTTP.set_wallet('file:/u01/wallets', 'master123');

   l_param_list := NULL;
   v_url := 'https://payments.titasgas.org.bd/access_token';

   -- preparing Request...
   l_http_request := UTL_HTTP.begin_request (v_url, 'GET', 'HTTP/1.1');
   --'https://payments.titasgas.org.bd/access_token', --'https://sandbox.titasgas.org.bd/access_token',

   UTL_HTTP.set_authentication (l_http_request,
                                'OT5KEOz0FOtRV2af4mRzBZgOAE4cK0uk', --'LNbc2uitJ5SzE42nPtF7XQsXdq5I',
                                'NJs3gbCPemFUTS2h2BGUHvWzLHywtwGbbhwVAsqz'); --'254F39XQekY64oVi78587BZ9vu2q');

   -- ...set header's attributes

   UTL_HTTP.set_header (l_http_request,
                        'Authorization',
                        'Basic QWxhZGRpbjpPcGVuU2VzYW1l');

   -- ...set input parameters
   UTL_HTTP.write_text (l_http_request, l_param_list);


   -- get Response and obtain received value
   l_http_response := UTL_HTTP.get_response (l_http_request);

   UTL_HTTP.read_text (l_http_response, l_response_text);

   DBMS_OUTPUT.put_line ('1. ' || l_response_text);

   SELECT NVL (MAX (REQUESTID), 0) + 1 INTO v_reqid FROM IN_OUT_JSON;

   INSERT INTO IN_OUT_JSON (REQUESTID,
                            REQUEST_name,
                            request,
                            JSON_RESPONSE,
                            in_time)
        VALUES (v_reqid,
                'access_token',
                 v_url,
                l_response_text,
                SYSDATE);

   SELECT js.JSON_RESPONSE.status
     INTO v_status
     FROM IN_OUT_JSON js
    WHERE js.REQUESTID = v_reqid;

   IF v_status = 200
   THEN
      UPDATE IN_OUT_JSON
         SET in_req_status = 'Success'
       WHERE REQUESTID = v_reqid;

      SELECT js.JSON_RESPONSE.status a,
             js.JSON_RESPONSE.MESSAGE b,
             js.JSON_RESPONSE.data.access_token c
        INTO v_status, v_message, o_access_token
        FROM IN_OUT_JSON js
       WHERE js.REQUESTID = v_reqid;


      UPDATE STUTIL.stparamt
         SET PARAVAL = o_access_token, LAST_UPDATETIME = SYSDATE
       WHERE TYPE = 'TGL' AND SUBTYPE = 'TKN';
   ELSE
      UPDATE IN_OUT_JSON
         SET in_req_status = v_status || l_response_text
       WHERE REQUESTID = v_reqid;
   END IF;

   DBMS_OUTPUT.put_line ('2. ' || l_response_text);

   -- finalizing
   UTL_HTTP.end_response (l_http_response);
EXCEPTION
   WHEN UTL_HTTP.end_of_body
   THEN
      errflg := 'E';
      errmsg := 'Error 100 ' || SQLERRM;

      UTL_HTTP.end_response (l_http_response);
END;
/
