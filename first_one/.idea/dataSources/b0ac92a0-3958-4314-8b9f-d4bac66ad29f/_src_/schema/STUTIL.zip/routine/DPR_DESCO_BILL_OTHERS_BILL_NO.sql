CREATE PROCEDURE        DPR_DESCO_BILL_OTHERS_BILL_NO (
   P_BILL_NO VARCHAR2,
   P_OPRSTAMP VARCHAR2,
   P_BRANCD   VARCHAR2)
AS
BEGIN
  
  
   DELETE FROM BILL_CALCULATION
         WHERE BILL_NO = P_BILL_NO;

   COMMIT;

   INSERT INTO BILL_CALCULATION (BILL_NO,
                                       MONTH,
                                       YEAR,
                                       ACCOUNT_NO,
                                       METER_NO,
                                       TOTAL_AMOUNT,
                                       VAT_TOTAL,
                                       ISSUE_DATE,
                                       TARIFF,
                                       DUE_DATE,
                                       DEPT_ID,
                                       LPC,
                                       OPRSTAMP ,
                                       BRANCD   )
      SELECT BILL_NO,
             NVL (MONTH, '05'),
             NVL (YEAR, '2015'),
             NVL (ACCOUNT_NO, ROWNUM + 2) ACCOUNT_NO,
             NVL (METER_NO, ROWNUM + 3),
             TOTAL_AMOUNT,
             NVL (VAT, 0),
             ISSUE_DATE,
             TARIFF,
             DUE_DATE,
             DEPT_ID,
             LPC,
             P_OPRSTAMP ,
             P_BRANCD   
        FROM FEES_CALCULATION_D t--DESCO.FEES_CALCULATION@DBLNK_DESCO t
       WHERE t.BILL_NO = P_BILL_NO;

   COMMIT;
   
   NULL;
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
END;
/
