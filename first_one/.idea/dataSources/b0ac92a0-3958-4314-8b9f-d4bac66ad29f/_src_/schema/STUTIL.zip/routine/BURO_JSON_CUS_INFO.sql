CREATE PROCEDURE        BURO_JSON_CUS_INFO(CUSTOMER_ID IN  VARCHAR2,
                                                       CUSNAME OUT VARCHAR2,
                                                       ERRCOD OUT VARCHAR2,
                                                       IMFASTRNID OUT VARCHAR2,
                                                       MSG OUT VARCHAR2,
                                                       REQSTS OUT VARCHAR2,
                                                       TRANAMT OUT VARCHAR2)
IS
l_json_text VARCHAR2(32767);
BEGIN
 l_json_text := '{"CustomerName":"Johura",
                    "ErrorCode":0,
                    "ImfasTransId":null,
                    "Msg":"Last Month GS Balance: 100.00",
                    "RequestStatus":true,
                    "transAmount":"5000.25"
                    }';
 APEX_JSON.parse(l_json_text);
 CUSNAME :=  APEX_JSON.get_varchar2(p_path => 'CustomerName');
 ERRCOD := APEX_JSON.get_number(p_path => 'ErrorCode');
 IMFASTRNID :=  APEX_JSON.get_varchar2(p_path => 'ImfasTransId');
 MSG := APEX_JSON.get_varchar2(p_path => 'Msg');
 REQSTS := APEX_JSON.get_varchar2(p_path => 'RequestStatus');
 TRANAMT := APEX_JSON.get_varchar2(p_path => 'transAmount');
 
 IF l_json_text IS NULL THEN
    RAISE_APPLICATION_ERROR(-20001,'API could not get JSON data');
 END IF;
END BURO_JSON_CUS_INFO;
/
