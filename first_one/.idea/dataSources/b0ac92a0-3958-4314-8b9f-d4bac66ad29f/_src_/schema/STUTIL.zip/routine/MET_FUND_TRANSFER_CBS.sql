CREATE PROCEDURE        MET_fund_transfer_CBS (
   p_dblink              IN     VARCHAR2,
   p_oprbrancd           IN     VARCHAR2,
   p_oprtamp             IN     VARCHAR2,
   p_no_of_records       IN     NUMBER,
   p_tot_amount          IN     NUMBER,
   p_tot_stamp_amount    IN     NUMBER,
   p_tot_charge_amount   IN     NUMBER,
   p_tot_vat_amount      IN     NUMBER,
   p_branch_code         IN     VARCHAR2,                         ---AI_BRANCH
   p_timestamp           IN     VARCHAR2,
   p_app_user            IN     VARCHAR2,
   p_AI_DOCDAT           IN     DATE,
   p_USER_TYPE           IN     VARCHAR2,
   p_GROUPCODE           IN     VARCHAR2,
   pErrorFlag               OUT VARCHAR2,
   pErrorMessage            OUT VARCHAR2)
IS
   v_row         NUMBER := 0;
   v_tnum        VARCHAR2 (50) := NULL;
   v_erritem     VARCHAR2 (50) := NULL;
   O_ERR_FLG     VARCHAR2 (5) := NULL;
   vCount        NUMBER := 0;
   O_ERR_MSG     VARCHAR2 (4000) := NULL;
   v_crcode      VARCHAR2 (10) := NULL;
   v_drcode      VARCHAR2 (10) := NULL;
   V_ACTYPE      VARCHAR2 (20);
   V_ACTNUM      VARCHAR2 (30);
   V_ENCACTNUM   VARCHAR2 (100);
   V_DOCTYPE     VARCHAR2 (5);
   v_doctype2    VARCHAR2 (3) := NULL;
   V_oprcod      VARCHAR2 (50);
   v_errflg      VARCHAR2 (10) := NULL;
   v_errmsg      VARCHAR2 (5000) := NULL;
   v_lmtamt      NUMBER := 0;
   o_curcde      VARCHAR2 (50);
   V_STAMP       VARCHAR2 (30);
   V_CHRG        VARCHAR2 (30);
   v_channel     VARCHAR2 (200);
   V_VAT         VARCHAR2 (30);
   Mv_drcode     VARCHAR2 (50);
   v_tot_no      NUMBER := 0;
   v_PAIDAMT     NUMBER := 0;
   v_STAMPAMT    NUMBER := 0;
   v_CHARGAMT    NUMBER := 0;
   v_VATCHARG    NUMBER := 0;

   CURSOR c1 (
      --cParameter1VARCHAR2,
      cParameter2    VARCHAR2)
   IS
      (SELECT stutil.GET_ENC_VAL (
                 TRANID,
                 stutil.HASH_ENCRYPT ('Metba123Metba123Metba123Metba123'))
                 TRANID,
              TRANTIME,
              OPBRANCD,
              OPRBRANAME,
              PAIDAMT,
              POLICYNO,
              RECEIPTHEADING,
              PONAME,
              AGENTCODE,
              PMODE,
              (SELECT PARAVAL
                 FROM STPARAMT
                WHERE TYPE = 'MET' AND RESPONSECODE = a.PMODE)
                 mod_detail,
              SLNODAY,
              TIMSTAMP
         FROM STLMDBEX a
        WHERE                                              --PMODE=cParameter1
             OPRSTAMP = cParameter2
              AND TRANFLG = 'Y'
              AND OPBRANCD = p_branch_code
              AND flag = 'N'
              AND PAYSTAT = 'P');
BEGIN
   /*raise_application_error(-20001,'System currently under maintenance. Please try again after 3.00 PM');
   ROLLBACK;
   RETURN;*/

   -- raise_application_error ( -20001,p_tot_amount);

   BEGIN
      SELECT SUBTYPE,
             PARAVAL,
             stutil.GET_ENC_VAL (
                PARAVAL,
                stutil.HASH_ENCRYPT ('Metba123Metba123Metba123Metba123'))
                enc_account
        INTO V_ACTYPE, V_ACTNUM, V_ENCACTNUM
        FROM STPARAMT
       WHERE TYPE = 'MET' AND RESPONSECODE = 100;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         raise_application_error (
            -20001,
            'Destination A/c Information Not Found in STPARAMT(TYPE-MET)');
      WHEN TOO_MANY_ROWS
      THEN
         raise_application_error (
            -20001,
            'Too Many Destination A/c Information Not Found in STPARAMT(TYPE-MET)');
      WHEN OTHERS
      THEN
         raise_application_error (
            -20001,
            'Error Getting Destination A/c Information-ERROR:' || SQLERRM);
   END;

   BEGIN                                        ------------STAMPGL-----------
      SELECT PARAVAL
        INTO V_STAMP
        FROM STPARAMT
       WHERE TYPE = 'MET' AND SUBTYPE = 'STM';
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         raise_application_error (-20001,
                                  'Stamp GL Not Found in STPARAMT(TYPE-MET)');
      WHEN TOO_MANY_ROWS
      THEN
         raise_application_error (
            -20001,
            'Too Many Stamp GL Not Found in STPARAMT(TYPE-MET)');
      WHEN OTHERS
      THEN
         raise_application_error (
            -20001,
            'Error Getting Stamp GL in STPARAMT(TYPE-MET)-ERROR:' || SQLERRM);
   END;

   BEGIN                                        ------------CHARGEGL----------
      SELECT PARAVAL
        INTO V_CHRG
        FROM STPARAMT
       WHERE TYPE = 'MET' AND SUBTYPE = 'CRG';
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         raise_application_error (
            -20001,
            'Charge GL Not Found in STPARAMT(TYPE-MET)');
      WHEN TOO_MANY_ROWS
      THEN
         raise_application_error (
            -20001,
            'Too Many Charge GL Not Found in STPARAMT(TYPE-MET)');
      WHEN OTHERS
      THEN
         raise_application_error (
            -20001,
            'Error Getting Charge GL in STPARAMT(TYPE-MET)-ERROR:' || SQLERRM);
   END;

   BEGIN                     ---------------------VATGL-----------------------
      SELECT PARAVAL
        INTO V_VAT
        FROM STPARAMT
       WHERE TYPE = 'MET' AND SUBTYPE = 'VAT' AND CURCDE = 'Y';
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         raise_application_error (
            -20001,
            'Vat GL Not Found in STPARAMT(TYPE-MET,SUBTYPE=VAT)');
      WHEN TOO_MANY_ROWS
      THEN
         raise_application_error (
            -20001,
            'Too Many Vat GL Not Found in STPARAMT(TYPE-MET)');
      WHEN OTHERS
      THEN
         raise_application_error (
            -20001,
            'Error Getting Vat GL in STPARAMT(TYPE-MET)-ERROR:' || SQLERRM);
   END;

   ----------------------------------------DOC_TYPEASSIGN--------------------------------------
   BEGIN
      IF p_branch_code = SUBSTR (V_ACTNUM, 1, 3)
      THEN
         V_DOCTYPE := 'CS';
         V_oprcod := 'DEP';
         v_doctype2 := 'DC';
      ELSE
         V_DOCTYPE := 'IC';
         V_oprcod := 'IB1';
         v_doctype2 := 'IT';
      END IF;
   END;

   --------------------------------------TellerLimitCheck---------------------------------
   BEGIN
      dpr_teller_limit_check (p_dblink       => p_dblink, ----------->PASSINGDBLINKFROMAPPLICATIONITEM
                              p_brancd       => p_branch_code,
                              p_appusr       => p_app_user,
                              p_doctyp       => V_DOCTYPE,
                              p_oprcod       => V_oprcod,
                              p_actype       => V_ACTYPE,
                              p_curcde       => 'BDT',
                              p_debcre       => 'C',
                              p_typcde       => 'TLR',
                              p_lmtamt       => v_lmtamt,
                              p_tlr_curcde   => o_curcde,
                              p_errflg       => v_errflg,
                              p_errmsg       => v_errmsg);

      IF v_errmsg IS NOT NULL
      THEN
         raise_application_error (-20001, v_errflg || '-' || v_errmsg);
      ELSIF p_tot_amount > v_lmtamt
      THEN
         v_errmsg :=
               'Limit Amount for this transaction has exceeded....!REF: TLR/'
            || p_app_user
            || '/'
            || V_DOCTYPE
            || '/'
            || V_oprcod
            || '/'
            || V_ACTYPE
            || '/BDT';
         raise_application_error (-20001, v_errmsg);
      ELSE
         v_errmsg := NULL;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         raise_application_error (-20001, v_errmsg);
   END;
--raise_application_error(-20001,sysdate);
   IF v_errmsg IS NULL
   THEN
      ----------------------------DOCUMENTGENERATIONPROCESS--------------------------
      BEGIN
         dpr_docnumber_generation (p_dblink     => p_dblink, ----------->PASSINGDBLINKFROMAPPLICATIONITEM
                                   p_compcd     => p_branch_code,
                                   p_modlcd     => 'ST',
                                   p_doctyp     => V_DOCTYPE,
                                   p_subtyp     => 1,
                                   p_docdat     => SYSDATE,
                                   p_loccde     => NULL,
                                   p_origmodl   => 'ST',
                                   p_docnum     => v_tnum,
                                   p_errflag    => v_errflg,
                                   p_errmsg     => v_errmsg);

         IF v_errmsg IS NULL
         THEN
            v_tnum := p_branch_code || v_tnum;
         ELSE
            raise_application_error (-20001, v_errflg || '-' || v_errmsg);
            ROLLBACK;
            RETURN;
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            raise_application_error (
               -20001,
                  'Error Generating Docnumber-'
               || v_tnum
               || '.Error:'
               || SQLERRM);
            ROLLBACK;
            RETURN;
      END;

      BEGIN
           SELECT COUNT (1),
                  SUM (PAIDAMT),
                  SUM (NVL (STAMPAMT, 0)),
                  SUM (NVL (CHARGAMT, 0)),
                  SUM (NVL (VATCHARG, 0))
             INTO v_tot_no,
                  v_PAIDAMT,
                  v_STAMPAMT,
                  v_CHARGAMT,
                  v_VATCHARG
             FROM STLMDBEX a
            WHERE     PAYSTAT = 'P'
                  AND TRANFLG = 'N'
                  AND (   OPRSTAMP <> p_app_user
                       OR (p_USER_TYPE = 'A' AND p_GROUPCODE = '010'))
                  AND OPBRANCD =
                         DECODE (p_oprbrancd, 100, OPBRANCD, p_oprbrancd)
                  AND OPRSTAMP = p_oprtamp
                  AND OPBRANCD <> 108
                  AND CANCELBY IS NULL
                  AND CANCELTIME IS NULL
                  AND TO_CHAR (TIMSTAMP, 'RRMMDDHH24MISS') IN ------- Added by prithy on 10-12-2018
                         (WITH TIMES AS (SELECT p_timestamp str FROM DUAL)
                              SELECT TRIM (REGEXP_SUBSTR (str,
                                                          '[^,]+',
                                                          1,
                                                          LEVEL))
                                        str
                                FROM TIMES
                          CONNECT BY INSTR (str,
                                            ',',
                                            1,
                                            LEVEL - 1) > 0)
         GROUP BY OPRSTAMP, OPBRANCD, OPRBRANAME;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            raise_application_error (-20001, 'No Data Found in STLMDBEX');
         WHEN TOO_MANY_ROWS
         THEN
            raise_application_error (
               -20001,
               'More Than One Record Found in STLMDBEX');
         WHEN OTHERS
         THEN
            raise_application_error (-20001,
                                     'Error for Finding Data From STLMDBEX');
      END;
 
      ---------------------CompleteTransactionProcess---------------------------
      BEGIN
         dpr_complete_transaction (
            p_dblink        => p_dblink, ----------->PASSINGDBLINKFROMAPPLICATIONITEM
            p_brancd        => p_branch_code,
            p_tran_type     => 'REG',
            p_acbrancd      => SUBSTR (v_actnum, 1, 3),
            p_oprcod        => v_oprcod,
            p_modday        => p_AI_DOCDAT,
            p_valdat        => p_AI_DOCDAT,
            p_actype        => v_actype,
            p_actnum        => v_actnum,
            p_chqsrl        => NULL,
            p_chqnum        => NULL,
            p_chqdat        => NULL,
            p_loccur        => 'BDT',
            p_doctyp        => v_doctype,
            p_modcde        => 'ST',
            p_trbrancd      => p_branch_code,
            p_tractype      => NULL,
            p_tractnum      => NULL,
            p_trchqser      => NULL,
            p_trchqnum      => NULL,
            p_trchqdat      => NULL,
            p_appusr        => p_oprtamp,                          -->MAKERID,
            p_action        => 'STALLTRN',
            p_appflg        => 'Y',
            p_supid2        => p_app_user,
            p_amount        => NVL (v_PAIDAMT, p_tot_amount),  -------->AMOUNT
            p_tinnum        => NULL,
            p_appque        => 'N',
            p_serlno        => 1,
            p_docnum        => v_tnum,
            p_acvalid_req   => 'Y',
            p_clrzon        => NULL,
            p_clrday        => NULL,
            p_glcode        => NULL,
            p_yrprfx        => NULL,
            p_chgcde        => 'N',
            p_typcde        => 'TLR',
            p_glflag        => 'Y',
            p_remarks       => 'MetLife Premium Collection',
            --p_chqval=>'Y',
            p_erritem       => v_erritem,
            p_errflg        => o_err_flg,
            p_errmsg        => o_err_msg);

         IF o_err_flg IS NOT NULL
         THEN
            raise_application_error (-20001,
                                     o_err_flg || '-' || o_err_msg || 'E');
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            raise_application_error (-20001, 'Error' || o_err_msg);
      END;

      IF O_ERR_MSG IS NULL
      THEN
         -----------------Getaccountglcode
         BEGIN
            stutil.dpr_getacglcode (p_dblink    => p_dblink,
                                    p_brancd    => SUBSTR (v_actnum, 1, 3),
                                    p_actype    => v_actype,
                                    p_docdate   => p_AI_DOCDAT,
                                    p_glcode    => v_drcode,
                                    p_errflg    => O_ERR_FLG,
                                    p_errmsg    => O_ERR_MSG);

            IF O_ERR_FLG IS NOT NULL
            THEN
               raise_application_error (-20001,
                                        O_ERR_FLG || '-' || O_ERR_MSG);
               ROLLBACK;
               RETURN;
            END IF;
         END;

         IF (SUBSTR (v_actnum, 1, 3) <> p_oprbrancd) -----------------Getbranchglcode
         THEN
            BEGIN
               stutil.dpr_get_branch_glcode (p_dblink   => p_dblink,
                                             p_brancd   => p_oprbrancd,
                                             p_glcode   => v_crcode,
                                             p_errflg   => O_ERR_FLG,
                                             p_errmsg   => O_ERR_MSG);

               IF O_ERR_FLG IS NOT NULL
               THEN
                  raise_application_error (-20001,
                                           O_ERR_FLG || '-' || O_ERR_MSG);
                  ROLLBACK;
                  RETURN;
               END IF;
            END;
         ELSE
            v_crcode := 'DUMMY';
         END IF;

         IF p_tot_stamp_amount > 0
         THEN
            BEGIN    -----------------------STAMP Fee-------------------------
               dpr_insert_fetran (
                  p_dblink     => p_dblink,
                  p_brancd     => SUBSTR (v_actnum, 1, 3),    --p_branch_code,
                  p_doctyp     => v_doctype2,
                  p_docnum     => v_tnum,
                  p_sernum     => 3,
                  p_docdat     => p_AI_DOCDAT,
                  p_valdat     => p_AI_DOCDAT,
                  p_oprcod     => 'WDL',
                  p_actype     => v_actype,
                  p_actnum     => V_ACTNUM,       --p_branch_code||'00000099',
                  p_curcde     => 'BDT',
                  p_exrate     => 1,
                  p_debcre     => 'D',                                 -------
                  p_dbamfc     => NVL (v_STAMPAMT, p_tot_stamp_amount), --------0,
                  p_dbamlc     => NVL (v_STAMPAMT, p_tot_stamp_amount), --------0,
                  p_cramfc     => 0, -------TO_NUMBER(APEX_APPLICATION.G_F09(v_row),'999G999G999G999G990D00'),
                  p_cramlc     => 0, -------TO_NUMBER(APEX_APPLICATION.G_F09(v_row),'999G999G999G999G990D00'),
                  p_curbal     => 0,
                  p_balflg     => 'Y',
                  p_chgflg     => 'N',
                  p_chqser     => NULL,
                  p_chqnum     => NULL,
                  p_chqdat     => NULL,
                  p_trbrancd   => p_oprbrancd,                           --085
                  p_tractype   => NULL,                         ---v_depactyp,
                  p_tractnum   => NULL,                          ---v_depacno,
                  p_trchqser   => NULL,
                  p_trchqnum   => NULL,
                  p_trchqdat   => NULL,
                  p_clrzon     => NULL,
                  p_clrday     => NULL,
                  p_prtflg     => 'N',
                  p_glcode     => NULL,
                  p_opbrancd   => p_branch_code,                         --085
                  p_remark     => 'MetLife Premium COLLECTION-STAMP FEE',
                  p_yrprfx     => NULL,
                  p_chgcde     => 'N',
                  p_modcde     => 'ST',
                  p_supid2     => p_app_user,
                  p_drcode     => v_drcode,                      --'10100-01',
                  p_crcode     => v_crcode,                      --'15700-01',
                  p_oprstamp   => p_oprtamp,
                  p_timstamp   => SYSTIMESTAMP,
                  p_glflag     => 'Y',
                  p_refno5     => NULL,
                  p_errflg     => O_ERR_FLG,
                  p_errmsg     => O_ERR_MSG);

               IF O_ERR_FLG IS NOT NULL
               THEN
                  raise_application_error (
                     -20001,
                     O_ERR_FLG || '-' || O_ERR_MSG || 'E1');
               END IF;
            END;
         END IF;

         BEGIN ---------------------------chargefeee-------------------------------
            dpr_insert_fetran (
               p_dblink     => p_dblink,
               p_brancd     => SUBSTR (v_actnum, 1, 3),       --p_branch_code,
               p_doctyp     => 'IT',
               p_docnum     => v_tnum,
               p_sernum     => 5,
               p_docdat     => p_AI_DOCDAT,
               p_valdat     => p_AI_DOCDAT,
               p_oprcod     => 'WDL',
               p_actype     => v_actype,
               p_actnum     => V_ACTNUM,          --p_branch_code||'00000099',
               p_curcde     => 'BDT',
               p_exrate     => 1,
               p_debcre     => 'D',                                    -------
               p_dbamfc     => NVL (v_CHARGAMT, p_tot_charge_amount), --------0,
               p_dbamlc     => NVL (v_CHARGAMT, p_tot_charge_amount), --------0,
               p_cramfc     => 0, -------TO_NUMBER(APEX_APPLICATION.G_F09(v_row),'999G999G999G999G990D00'),
               p_cramlc     => 0, -------TO_NUMBER(APEX_APPLICATION.G_F09(v_row),'999G999G999G999G990D00'),
               p_curbal     => 0,
               p_balflg     => 'Y',
               p_chgflg     => 'N',
               p_chqser     => NULL,
               p_chqnum     => NULL,
               p_chqdat     => NULL,
               p_trbrancd   => p_oprbrancd,                              --085
               p_tractype   => NULL,                            ---v_depactyp,
               p_tractnum   => NULL,                             ---v_depacno,
               p_trchqser   => NULL,
               p_trchqnum   => NULL,
               p_trchqdat   => NULL,
               p_clrzon     => NULL,
               p_clrday     => NULL,
               p_prtflg     => 'N',
               p_glcode     => NULL,
               p_opbrancd   => p_branch_code,                            --085
               p_remark     => 'MetLife Premium COLLECTION-CHARGE FEE',
               p_yrprfx     => NULL,
               p_chgcde     => 'N',
               p_modcde     => 'ST',
               p_supid2     => p_app_user,
               p_drcode     => v_drcode,                         --'10100-01',
               p_crcode     => '14100-01',                       --'15700-01',
               p_oprstamp   => p_oprtamp,
               p_timstamp   => SYSTIMESTAMP,
               p_glflag     => 'Y',
               p_refno5     => NULL,
               p_errflg     => O_ERR_FLG,
               p_errmsg     => O_ERR_MSG);

            IF O_ERR_FLG IS NOT NULL
            THEN
               raise_application_error (
                  -20001,
                  O_ERR_FLG || '-' || O_ERR_MSG || 'E2');
            END IF;
         END;

         BEGIN          -----------------------VATFee-------------------------
            dpr_insert_fetran (
               p_dblink     => p_dblink,
               p_brancd     => SUBSTR (v_actnum, 1, 3),       --p_branch_code,
               p_doctyp     => 'IT',
               p_docnum     => v_tnum,
               p_sernum     => 7,
               p_docdat     => p_AI_DOCDAT,
               p_valdat     => p_AI_DOCDAT,
               p_oprcod     => 'WDL',
               p_actype     => v_actype,
               p_actnum     => V_ACTNUM,          --p_branch_code||'00000099',
               p_curcde     => 'BDT',
               p_exrate     => 1,
               p_debcre     => 'D',                                    -------
               p_dbamfc     => NVL (v_VATCHARG, p_tot_vat_amount),
               p_dbamlc     => NVL (v_VATCHARG, p_tot_vat_amount),
               p_cramfc     => 0,
               p_cramlc     => 0,
               p_curbal     => 0,
               p_balflg     => 'Y',
               p_chgflg     => 'N',
               p_chqser     => NULL,
               p_chqnum     => NULL,
               p_chqdat     => NULL,
               p_trbrancd   => p_oprbrancd,                              --085
               p_tractype   => NULL,                            ---v_depactyp,
               p_tractnum   => NULL,                             ---v_depacno,
               p_trchqser   => NULL,
               p_trchqnum   => NULL,
               p_trchqdat   => NULL,
               p_clrzon     => NULL,
               p_clrday     => NULL,
               p_prtflg     => 'N',
               p_glcode     => NULL,
               p_opbrancd   => p_branch_code,                            --085
               p_remark     => 'MetLife Premium COLLECTION-VAT FEE',
               p_yrprfx     => NULL,
               p_chgcde     => 'N',
               p_modcde     => 'ST',
               p_supid2     => p_app_user,
               p_drcode     => v_drcode,                         --'10100-01',
               p_crcode     => '14100-01',                       --'15700-01',
               p_oprstamp   => p_oprtamp,
               p_timstamp   => SYSTIMESTAMP,
               p_glflag     => 'Y',
               p_refno5     => NULL,
               p_errflg     => O_ERR_FLG,
               p_errmsg     => O_ERR_MSG);

            IF O_ERR_FLG IS NOT NULL
            THEN
               raise_application_error (
                  -20001,
                  O_ERR_FLG || '-' || O_ERR_MSG || 'E3');
            END IF;
         END;

         IF (SUBSTR (v_actnum, 1, 3) <> p_oprbrancd)
         THEN
            BEGIN
               stutil.dpr_get_branch_glcode (
                  p_dblink   => p_dblink,
                  p_brancd   => SUBSTR (v_actnum, 1, 3),
                  p_glcode   => v_crcode,
                  p_errflg   => O_ERR_FLG,
                  p_errmsg   => O_ERR_MSG);

               IF O_ERR_FLG IS NOT NULL
               THEN
                  raise_application_error (-20001,
                                           O_ERR_FLG || '-' || O_ERR_MSG);
                  ROLLBACK;
                  RETURN;
               END IF;
            END;
         ELSE
            v_crcode := 'DUMMY';
         END IF;

         IF p_tot_stamp_amount > 0
         THEN
            BEGIN         ---------------------------stampFee-----------------
               dpr_insert_fetran (
                  p_dblink     => p_dblink,
                  p_brancd     => p_branch_code,
                  p_doctyp     => v_doctype2,
                  p_docnum     => v_tnum,
                  p_sernum     => 4,
                  p_docdat     => p_AI_DOCDAT,
                  p_valdat     => p_AI_DOCDAT,
                  p_oprcod     => 'DEP',
                  p_actype     => 'Z99',
                  p_actnum     => p_branch_code || '00000099',
                  p_curcde     => 'BDT',
                  p_exrate     => 1,
                  p_debcre     => 'C',                                 -------
                  p_dbamfc     => 0,
                  p_dbamlc     => 0,
                  p_cramfc     => NVL (v_STAMPAMT, p_tot_stamp_amount),
                  p_cramlc     => NVL (v_STAMPAMT, p_tot_stamp_amount),
                  p_curbal     => 0,
                  p_balflg     => 'Y',
                  p_chgflg     => 'N',
                  p_chqser     => NULL,
                  p_chqnum     => NULL,
                  p_chqdat     => NULL,
                  p_trbrancd   => p_oprbrancd,
                  p_tractype   => NULL,                         ---v_depactyp,
                  p_tractnum   => NULL,                          ---v_depacno,
                  p_trchqser   => NULL,
                  p_trchqnum   => NULL,
                  p_trchqdat   => NULL,
                  p_clrzon     => NULL,
                  p_clrday     => NULL,
                  p_prtflg     => 'N',
                  p_glcode     => NULL,
                  p_opbrancd   => p_branch_code,
                  p_remark     => 'MetLife Premium COLLECTION-STAMP FEE',
                  p_yrprfx     => NULL,
                  p_chgcde     => 'N',
                  p_modcde     => 'ST',
                  p_supid2     => p_app_user,
                  p_drcode     => v_crcode,                      --'10100-01',
                  p_crcode     => V_STAMP,                       --'15700-01',
                  p_oprstamp   => p_oprtamp,
                  p_timstamp   => SYSTIMESTAMP,
                  p_glflag     => 'Y',
                  p_refno5     => NULL,
                  p_errflg     => O_ERR_FLG,
                  p_errmsg     => O_ERR_MSG);

               IF O_ERR_FLG IS NOT NULL
               THEN
                  raise_application_error (
                     -20001,
                     O_ERR_FLG || '-' || O_ERR_MSG || 'E4');
               END IF;
            END;
         END IF;

         BEGIN
            stutil.dpr_get_branch_glcode (
               p_dblink   => p_dblink,
               p_brancd   => SUBSTR (v_actnum, 1, 3),
               p_glcode   => Mv_drcode,
               p_errflg   => O_ERR_FLG,
               p_errmsg   => O_ERR_MSG);

            IF O_ERR_FLG IS NOT NULL
            THEN
               raise_application_error (-20001,
                                        O_ERR_FLG || '-' || O_ERR_MSG);
               ROLLBACK;
               RETURN;
            END IF;
         END;

         BEGIN ---------------------------ChargeFee------------------------------------
            dpr_insert_fetran (
               p_dblink     => p_dblink,
               p_brancd     => '100',
               p_doctyp     => 'IT',                     ------------bujhbo na
               p_docnum     => v_tnum,
               p_sernum     => 6,
               p_docdat     => p_AI_DOCDAT,
               p_valdat     => p_AI_DOCDAT,
               p_oprcod     => 'DEP',
               p_actype     => 'Z99',
               p_actnum     => '10000000099',
               p_curcde     => 'BDT',
               p_exrate     => 1,
               p_debcre     => 'C',                                    -------
               p_dbamfc     => 0,
               p_dbamlc     => 0,
               p_cramfc     => NVL (v_CHARGAMT, p_tot_charge_amount),
               p_cramlc     => NVL (v_CHARGAMT, p_tot_charge_amount),
               p_curbal     => 0,
               p_balflg     => 'Y',
               p_chgflg     => 'N',
               p_chqser     => NULL,
               p_chqnum     => NULL,
               p_chqdat     => NULL,
               p_trbrancd   => p_oprbrancd,
               p_tractype   => NULL,                            ---v_depactyp,
               p_tractnum   => NULL,                             ---v_depacno,
               p_trchqser   => NULL,
               p_trchqnum   => NULL,
               p_trchqdat   => NULL,
               p_clrzon     => NULL,
               p_clrday     => NULL,
               p_prtflg     => 'N',
               p_glcode     => NULL,
               p_opbrancd   => p_branch_code,
               p_remark     => 'MetLife Premium COLLECTION-CHARGE FEE',
               p_yrprfx     => NULL,
               p_chgcde     => 'N',
               p_modcde     => 'ST',
               p_supid2     => p_app_user,
               p_drcode     => Mv_drcode,                        --'10100-01',
               p_crcode     => V_CHRG,                           --'10100-01',
               p_oprstamp   => p_oprtamp,
               p_timstamp   => SYSTIMESTAMP,
               p_glflag     => 'Y',
               p_refno5     => NULL,
               p_errflg     => O_ERR_FLG,
               p_errmsg     => O_ERR_MSG);

            IF O_ERR_FLG IS NOT NULL
            THEN
               raise_application_error (
                  -20001,
                  O_ERR_FLG || '-' || O_ERR_MSG || 'E5');
            END IF;
         END;

         BEGIN                                      -------------vatfeee------
            dpr_insert_fetran (
               p_dblink     => p_dblink,
               p_brancd     => '100',
               p_doctyp     => 'IT',                         -----bujhono na 2
               p_docnum     => v_tnum,
               p_sernum     => 8,
               p_docdat     => p_AI_DOCDAT,
               p_valdat     => p_AI_DOCDAT,
               p_oprcod     => 'DEP',
               p_actype     => 'Z99',
               p_actnum     => '10000000099',
               p_curcde     => 'BDT',
               p_exrate     => 1,
               p_debcre     => 'C',                                    -------
               p_dbamfc     => 0,
               p_dbamlc     => 0,
               p_cramfc     => NVL (v_VATCHARG, p_tot_vat_amount),
               p_cramlc     => NVL (v_VATCHARG, p_tot_vat_amount),
               p_curbal     => 0,
               p_balflg     => 'Y',
               p_chgflg     => 'N',
               p_chqser     => NULL,
               p_chqnum     => NULL,
               p_chqdat     => NULL,
               p_trbrancd   => p_oprbrancd,
               p_tractype   => NULL,                            ---v_depactyp,
               p_tractnum   => NULL,                             ---v_depacno,
               p_trchqser   => NULL,
               p_trchqnum   => NULL,
               p_trchqdat   => NULL,
               p_clrzon     => NULL,
               p_clrday     => NULL,
               p_prtflg     => 'N',
               p_glcode     => NULL,
               p_opbrancd   => p_branch_code,
               p_remark     => 'MetLife Premium COLLECTION-VAT FEE',
               p_yrprfx     => NULL,
               p_chgcde     => 'N',
               p_modcde     => 'ST',
               p_supid2     => p_app_user,
               p_drcode     => Mv_drcode,                        --'10100-01',
               p_crcode     => V_VAT,                            --'15700-01',
               p_oprstamp   => p_oprtamp,
               p_timstamp   => SYSTIMESTAMP,
               p_glflag     => 'Y',
               p_refno5     => NULL,
               p_errflg     => O_ERR_FLG,
               p_errmsg     => O_ERR_MSG);

            IF O_ERR_FLG IS NOT NULL
            THEN
               raise_application_error (
                  -20001,
                  O_ERR_FLG || '-' || O_ERR_MSG || 'E6');
            END IF;
         END;
      END IF;

      IF O_ERR_MSG IS NULL
      THEN
         BEGIN                              -------UpdateSTLMDBEXTable--------
            UPDATE STLMDBEX
               SET DOCTYP = V_DOCTYPE,
                   DOCDAT = p_AI_DOCDAT,
                   DOCNUM = v_tnum,
                   PROCSTAT = NULL,
                   TRANFLG = 'Y',
                   SERNUM = 1,
                   TRANSBY = p_app_user,
                   TRANTIME = SYSDATE
             WHERE                       --PMODE=APEX_APPLICATION.G_f03(v_row)
                  PAYSTAT = 'P'
                   AND TRANFLG = 'N'
                   AND (   OPRSTAMP <> p_app_user
                        OR (p_USER_TYPE = 'A' AND p_GROUPCODE = '010'))
                   AND OPBRANCD =
                          DECODE (p_oprbrancd, 100, OPBRANCD, p_oprbrancd)
                   AND OPRSTAMP = p_oprtamp
                   AND OPBRANCD <> 108
                   AND CANCELBY IS NULL
                   AND CANCELTIME IS NULL
                   AND TO_CHAR (TIMSTAMP, 'RRMMDDHH24MISS') IN ------- Added by prithy on 10-12-2018
                          (WITH TIMES AS (SELECT p_timestamp str FROM DUAL)
                               SELECT TRIM (REGEXP_SUBSTR (str,
                                                           '[^,]+',
                                                           1,
                                                           LEVEL))
                                         str
                                 FROM TIMES
                           CONNECT BY INSTR (str,
                                             ',',
                                             1,
                                             LEVEL - 1) > 0);

            IF SQL%NOTFOUND
            THEN
               raise_application_error (-20001,
                                        'Can not Update Value in STLMDBEX ');
            END IF;
         EXCEPTION
            WHEN OTHERS
            THEN
               raise_application_error (
                  -20001,
                  'Error in Update STLMDBEX' || '' || v_tnum);
         END;
      ELSE
         raise_application_error (-20001, O_ERR_MSG || 'E7');
         ROLLBACK;
         RETURN;
      END IF;
   END IF;

   IF p_oprbrancd = '108'
   THEN
      v_channel := 'ABS';
   ELSE
      v_channel := 'CBS';
   END IF;

   FOR i IN c1 (                              --APEX_APPLICATION.G_f03(v_row),
                p_oprtamp)
   LOOP
      BEGIN
         INSERT INTO LLMDBIMPT@METLIFE_UTILITY (SLNODAY,
                                                ACCTNO,
                                                TRANSACTIONNO,
                                                TRANDATE,
                                                BRANCHCODE,
                                                BRANCHNAME,
                                                COLLECTIONCHANNEL,
                                                PAIDFOR,
                                                PAIDFORDETAIL,
                                                POLICYNO,
                                                RECEIPTHEADING,
                                                OBLPAIDAMT,
                                                PONAME,
                                                AGENTCODE)
              VALUES (i.SLNODAY,
                      V_ENCACTNUM,
                      i.TRANID,
                      i.TIMSTAMP,
                      i.OPBRANCD,
                      i.OPRBRANAME,
                      v_channel,
                      i.PMODE,
                      i.mod_detail,
                      i.POLICYNO,
                      i.RECEIPTHEADING,
                      i.PAIDAMT,
                      i.PONAME,
                      i.AGENTCODE);
      EXCEPTION
         WHEN OTHERS
         THEN
            raise_application_error (-20001,
                                     'Unable to Insert into LLMDBIMPT');
      END;
   END LOOP;

   BEGIN
      UPDATE STLMDBEX
         SET flag = 'Y'
       WHERE                             --PMODE=APEX_APPLICATION.G_f03(v_row)
            OPRSTAMP = p_oprtamp
             AND OPBRANCD = p_oprbrancd
             AND TRANFLG = 'Y';
   END;
END;
/
