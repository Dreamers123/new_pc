CREATE PROCEDURE        get_user_info (
   p_oprstamp     IN     VARCHAR2,
   p_branchcode      OUT VARCHAR2,
   p_branchname      OUT VARCHAR2,
   p_docdate         OUT VARCHAR2,
   p_modulename      OUT VARCHAR2,
   p_modulecode      OUT VARCHAR2,
   p_dblink          OUT VARCHAR2,
   p_errflag         OUT VARCHAR2,
   p_errmsg          OUT VARCHAR2)
IS
   v_branchcd     VARCHAR2 (5) := NULL;
   v_barnchname   VARCHAR2 (500) := NULL;
   v_docdate      DATE;
   v_modulename   VARCHAR2 (50) := NULL;
   v_modulecode   VARCHAR2 (20) := NULL;
   v_dblink       VARCHAR2 (20) := NULL;
   v_sql          VARCHAR2 (4000);
   v_errflag      VARCHAR2 (5) := NULL;
   v_errmsg       VARCHAR2 (400) := NULL;
BEGIN
   BEGIN
      SELECT UPPER (authtype), divncode
        INTO v_modulename, v_branchcd
        FROM syusrmas
       WHERE UPPER (usercode) = UPPER (p_oprstamp);
       /* AND valdflag = 'A';*/  -----> Status is checked in dpg_user.user_logon
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         v_errflag := 'E1';
         v_errmsg :=
            'User Information Not Found for user- (' || p_oprstamp || ').';
      WHEN OTHERS
      THEN
         v_errflag := 'E2';
         v_errmsg :=
               'Error Getting User Information for user- ('
            || p_oprstamp
            || ').'
            || SQLERRM;
   END;

   BEGIN
      SELECT module_code, dblink
        INTO v_modulecode, v_dblink
        FROM authtype
       WHERE UPPER (module_name) = v_modulename;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         v_modulename := 'LOCAL';
      WHEN OTHERS
      THEN
         v_modulename := 'LOCAL';
   END;

   ----- Getting Branch Name from User Module via DBLINK

   IF v_modulecode <> 'LOCAL'   ---- was modulename 16032017 FAHIM
   THEN
      IF v_dblink IS NOT NULL
      THEN
         -----------------------------------------------
         BEGIN
            v_sql :=
                  'SELECT cacmpnam FROM syparmas@'
               || v_dblink
               || '  WHERE cagrpcde = ''001'' AND cacmpcde = :2';


            EXECUTE IMMEDIATE v_sql INTO v_barnchname USING v_branchcd;

            v_sql := NULL;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               v_errflag := 'E3';
               v_errmsg :=
                     'Error Getting Branch Information for Branch- '
                  || v_branchcd
                  || '. User- '
                  || p_oprstamp
                  || '. Module Name- '
                  || v_modulename
                  || '. DBLINK - '
                  || v_dblink;
            WHEN OTHERS
            THEN
               v_errflag := 'E4';
               v_errmsg :=
                  'Error Getting Branch Information for Branch- ' || SQLERRM;
         END;

         ------------------------------------------------
         BEGIN
            v_sql :=
                  'SELECT modday 
              FROM stmodnam@'
               || v_dblink
               || '
              WHERE modopn = ''O'' AND brancd = :1';

            EXECUTE IMMEDIATE v_sql INTO v_docdate USING v_branchcd;

            v_sql := NULL;
            
            APEX_UTIL.set_session_state ('AI_CHCK_DAYOPN', 'OPEN');
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
                v_docdate := SYSDATE;
                
                APEX_UTIL.set_session_state ('AI_CHCK_DAYOPN', 'CLOSED');
                
            /*  ---> Allow users to logon before DayOpen to start collection
               v_errflag := 'E5';
               v_errmsg :=
                  'Day Not Opened for branch ( ' || v_branchcd || ' )';
             */
            WHEN OTHERS
            THEN
               v_errflag := 'E6';
               v_errmsg :=
                     'Error Getting Modday ( '
                  || v_branchcd
                  || ' ). '
                  || SQLERRM;
         END;
      ELSE
         v_errflag := 'E7';
         v_errmsg := 'DB Link not found for module - ' || v_modulename;
      END IF;
   --------------------------------
   ELSE
      --------------------------------
      v_docdate := SYSDATE;
   END IF;

   IF v_errflag IS NULL
   THEN
      p_branchcode := v_branchcd;
      p_branchname := v_barnchname;
      p_docdate := v_docdate;
      p_modulename := v_modulename;
      p_modulecode := v_modulecode;
      p_dblink := v_dblink;
   ELSE
      p_errflag := v_errflag;
      p_errmsg := v_errmsg;
   END IF;
END;
/
