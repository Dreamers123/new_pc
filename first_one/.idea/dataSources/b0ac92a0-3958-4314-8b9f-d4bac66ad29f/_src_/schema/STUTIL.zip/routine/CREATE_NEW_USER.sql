CREATE PROCEDURE        create_new_user (
   p_dblink     IN     VARCHAR2, 
   p_userid     IN     VARCHAR2,
   p_usertype     IN     VARCHAR2,
   p_idvalidflag    IN     VARCHAR2,
   p_oprstamp     IN     VARCHAR2,
   p_authtype     IN     VARCHAR2,
   p_errflag       OUT VARCHAR2,
   p_errmsg        OUT VARCHAR2)
IS
   v_sql   VARCHAR2 (4000) := NULL;
BEGIN
   v_sql :=
  'DECLARE
   v_user     stlbas.dpg_beftn_clearing.typ_user_info@:1;
   v_userid   VARCHAR2 (20) := UPPER (:2);
   v_err      VARCHAR2 (200) := NULL;
BEGIN
   IF v_userid IS NOT NULL AND :3 = ''Y''
   THEN
      stlbas.dpg_beftn_clearing.get_istelar_user_info@:1 (v_userid,
                                                              v_user,
                                                              v_err);
      IF v_err IS NOT NULL
      THEN
         :7 := ''E'';
         :8 := v_err;
      ELSE
         INSERT INTO syusrmas (usercode,
                               username,
                               userpawd,
                               paswdate,
                               valdflag,
                               statdate,
                               divncode,
                               emplcode,
                               emplydob,
                               usertype,
                               grupcode,
                               lastlogn,
                               logincnt,
                               invldcnt,
                               startime,
                               stoptime,
                               telnumbr,
                               address,
                               emailid1,
                               emailid2,
                               strtsusp,
                               stopsusp,
                               livelogn,
                               maxmlogn,
                               oprstamp,
                               timstamp,
                               appflg,
                               chpass_nl,
                               authtype)
              VALUES (v_user.usercode,
                      v_user.username,
                      ''123'',
                      SYSDATE,
                      v_user.valdflag,
                      v_user.statdate,
                      v_user.divncode,
                      v_user.emplcode,
                      v_user.emplydob,
                      :4,
                      v_user.grupcode,
                      v_user.lastlogn,
                      0,
                      0,
                      v_user.startime,
                      v_user.stoptime,
                      v_user.telnumbr,
                      v_user.address1,
                      v_user.emailid1,
                      v_user.emailid2,
                      v_user.strtsusp,
                      v_user.stopsusp,
                      v_user.livelogn,
                      v_user.maxmlogn,
                      :5,
                      SYSDATE,
                      v_user.appflg,
                      ''N'',
                      :6);';
                      
  EXECUTE IMMEDIATE v_sql
      USING IN p_dblink,
            IN p_usertype,
            IN p_userid,
            IN p_idvalidflag,
            IN p_oprstamp,
            IN p_authtype,
            OUT p_errflag,
            OUT p_errmsg;     

EXCEPTION
   WHEN OTHERS
   THEN
      p_errflag := 'E';
      p_errmsg := SQLERRM;
END;
/
