CREATE PROCEDURE        dpr_get_branch_glcode_old (
   p_dblink   IN     VARCHAR2,
   p_brancd   IN     VARCHAR2,
   p_glcode      OUT VARCHAR2,
   p_errflg        OUT VARCHAR2,
   p_errmsg        OUT VARCHAR2)
IS
   v_sql   VARCHAR2 (4000) := NULL;
BEGIN
   v_sql := 'BEGIN dpk_common.dpr_get_branch_glcode@'
      || p_dblink
      || '( 
               i_brancd        => :v_brancd,    
               o_glcode        => :v_glcode, 
               errflg          => :v_errflg,  
               errmsg          => :v_errmsg );   
         END;';

   EXECUTE IMMEDIATE v_sql
      USING IN  p_brancd,
            OUT p_glcode,
            OUT p_errflg,
            OUT p_errmsg;
EXCEPTION
   WHEN OTHERS
   THEN
      p_errflg := 'E';
      p_errmsg := 'Exception Error : ' || SQLERRM;
END;
/
