CREATE PROCEDURE        DPR_DESCO_BILL_INFO (
   p_BILL_NO              IN     VARCHAR2,
   P_OPRSTAMP             IN     VARCHAR2,
   P_BRANCD               IN     VARCHAR2,
   ACCOUNT_NO                OUT VARCHAR2,
   METER_NO                  OUT VARCHAR2,
   YEAR                      OUT NUMBER,
   MONTH                     OUT NUMBER,
   BILL_NO                   OUT VARCHAR2,
   BILL_AMOUNT               OUT NUMBER,
   VAT_TOTAL                 OUT NUMBER,
   ISSUE_DATE                OUT DATE,
   DEPT_ID                   OUT VARCHAR2,
   DUE_DATE                  OUT DATE,
   PAID                      OUT VARCHAR2,
   LPC                       OUT NUMBER,
   NAME                      OUT VARCHAR2,
   STREET_ADDRESS            OUT VARCHAR2,
   TARIFF                    OUT VARCHAR2,
   TOTAL_AMOUNT              OUT NUMBER,
   TOTAL_PAYABLE_AMOUNT      OUT NUMBER,
   NET_AMOUNT                OUT NUMBER,
   TRAN_TYPE                 OUT VARCHAR2)
AS
   m_Count    NUMBER;
   m_Count1   NUMBER;
BEGIN
   SELECT COUNT (*)
     INTO m_Count
     FROM BILL_CALCULATION a
    WHERE A.BILL_NO = p_BILL_NO;

   IF m_Count = 0
   THEN
      BEGIN
         DPR_DESCO_BILL_PROCESS_BILL_NO (p_BILL_NO,P_OPRSTAMP,P_BRANCD);
      EXCEPTION
         WHEN OTHERS
         THEN
            NULL;
      END;
   END IF;

   SELECT COUNT (*)
     INTO m_Count1
     FROM BILL_CALCULATION a
    WHERE A.BILL_NO = p_BILL_NO;

   IF m_Count1 = 0
   THEN
      BEGIN
         DPR_DESCO_BILL_OTHERS_BILL_NO (p_BILL_NO, P_OPRSTAMP ,P_BRANCD );
      EXCEPTION
         WHEN OTHERS
         THEN
            NULL;
      END;
   END IF;


   SELECT a.ACCOUNT_NO,
          METER_NO,
          YEAR,
          MONTH,
          BILL_NO,
          NVL (
             CASE
                WHEN TRUNC (due_Date) < TRUNC (SYSDATE)
                THEN
                     (total_amount - NVL (VAT_TOTAL, 0))
                   + (CASE
                         WHEN NVL (a.organization_code, 0) IN (5, 6) THEN 0
                         ELSE a.LPC
                      END)
                ELSE
                   (total_amount - NVL (VAT_TOTAL, 0))
             END,
             0)
             BILL_AMOUNT,
          NVL (VAT_TOTAL, 0) VAT_TOTAL,
          TO_CHAR (ISSUE_DATE) ISSUE_DATE,
          a.DEPT_ID,
          --TO_CHAR (DUE_DATE) DUE_DATE,
          NVL (TO_CHAR (DUE_DATE), TRUNC (SYSDATE)) DUE_DATE,
          NVL (PAID, 0) PAID,
          NVL (
             CASE
                WHEN TRUNC (TO_DATE (due_Date)) < TRUNC (SYSDATE)
                THEN
                   (CASE
                       WHEN NVL (a.organization_code, 0) IN (5, 6) THEN 0
                       ELSE a.LPC
                    END)
                ELSE
                   0
             END,
             0)
             LPC,
          NVL (b.NAME, 'N/A') NAME,
          NVL (
                b.PLOT_NO
             || b.HOUSE_FLAT_NO
             || b.BLOCK_NO
             || b.STREET_ADDRESS
             || b.THANA
             || b.AREA,
             'N/A')
             STREET_ADDRESS,
          A.TARIFF TARIFF,
          CASE
             WHEN TRUNC (due_Date) < TRUNC (SYSDATE)
             THEN
                  A.TOTAL_AMOUNT
                + NVL (
                     (CASE
                         WHEN NVL (a.organization_code, 0) IN (5, 6) THEN 0
                         ELSE a.LPC
                      END),
                     0)
             ELSE
                A.TOTAL_AMOUNT
          END
             TOTAL_AMOUNT,
          a.NET_AMOUNT,
          A.TOTAL_AMOUNT TOTAL_PAYABLE_AMOUNT
     INTO ACCOUNT_NO,
          METER_NO,
          YEAR,
          MONTH,
          BILL_NO,
          BILL_AMOUNT,
          VAT_TOTAL,
          ISSUE_DATE,
          DEPT_ID,
          DUE_DATE,
          PAID,
          LPC,
          NAME,
          STREET_ADDRESS,
          TARIFF,
          TOTAL_AMOUNT,
          NET_AMOUNT,
          TOTAL_PAYABLE_AMOUNT
     FROM BILL_CALCULATION a, NEW_CONSUMER_INFORMATION b
    WHERE a.BILL_NO = p_BILL_NO AND A.ACCOUNT_NO = B.ACCOUNT_NO(+);
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      RAISE_APPLICATION_ERROR(-20005,'Invalid Bill No');
   WHEN OTHERS
   THEN
      NULL;
END;
/
