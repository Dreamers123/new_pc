CREATE FUNCTION Apex_CustomAuth_mod (p_username   IN VARCHAR2,
                                               p_password   IN VARCHAR2)
   RETURN BOOLEAN
IS
   vEncryptVal   VARCHAR2 (500);
   v_status      VARCHAR2 (1);
   v_AUTHTYPE    syusrmas.AUTHTYPE%TYPE;
   v_DBLINK      authtype.DBLINK%TYPE;
   v_USERPAWD    syusrmas.USERPAWD%TYPE;
   v_chk         NUMBER;
   v_appflg      syusrmas.appflg%TYPE;
   l_sql_stmt    VARCHAR2 (1000);
   v_boolean     BOOLEAN := FALSE;
BEGIN
   SELECT VALDFLAG,
          NVL (AUTHTYPE, 'LOCAL'),
          USERPAWD,
          NVL (appflg, 'N')
     INTO v_status,
          v_AUTHTYPE,
          v_USERPAWD,
          v_appflg
     FROM SYUSRMAS
    WHERE UPPER (USERCODE) = UPPER (p_username);

   BEGIN
      SELECT LOWER (DBLINK)
        INTO v_DBLINK
        FROM AUTHTYPE
       WHERE UPPER (MODULE_NAME) = UPPER (v_AUTHTYPE);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         v_DBLINK := NULL;
      WHEN OTHERS
      THEN
         v_DBLINK := NULL;
   END;

   IF v_appflg = 'Y'
   THEN
      IF v_AUTHTYPE = 'LOCAL'
      THEN
         PROC_CREATE_PASSWORD (UPPER (p_username), p_password, vEncryptVal);

         IF v_status = 'A'
         THEN
            IF v_USERPAWD = vEncryptVal
            THEN
               RETURN TRUE;
            ELSE
               RETURN FALSE;
            END IF;
         ELSIF v_status = 'N'
         THEN
            IF v_USERPAWD = vEncryptVal
            THEN
               RETURN TRUE;
            ELSE
               RETURN FALSE;
            END IF;
         ELSE
            RETURN FALSE;
         END IF;
      ELSIF v_DBLINK IS NOT NULL
      THEN
         ---  ElsIf v_AUTHTYPE = 'iSTELAR' then
         
         
         Execute Immediate
           'stlbas.DPG_BEFTN_CLEARING.APEX_CUSTOM_AUTH@'||V_DBLINK||'('''||upper(p_username)||''', '''||p_password||''');' into v_boolean;
         RETURN v_boolean;
         
       -----------------  RETURN stlbas.DPG_BEFTN_CLEARING.APEX_CUSTOM_AUTH@st_rep (UPPER (p_username),p_password);

         --  l_sql_stmt :=  'Return stlbas.DPG_BEFTN_CLEARING.apex_custom_auth@st_rep(upper(100140), 1234567)';
         --' Return stlbas.DPG_BEFTN_CLEARING.apex_custom_auth@st_rep('''||UPPER(p_username)||''','''||p_password||'''); END;';

         DBMS_OUTPUT.put_line (l_sql_stmt);
      --  EXECUTE IMMEDIATE l_sql_stmt;-- USING upper(p_username),p_password;
      -- RETURN v_BOOLEAN;
      ELSE
         RETURN FALSE;
      END IF;
   ELSE
      RETURN FALSE;
   END IF;
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      RETURN FALSE;
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.put_line (l_sql_stmt || '-' || SQLERRM);
--RETURN FALSE;
END;
/
