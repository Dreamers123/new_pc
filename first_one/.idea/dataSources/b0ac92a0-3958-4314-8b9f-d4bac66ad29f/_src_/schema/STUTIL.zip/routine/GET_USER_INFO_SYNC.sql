CREATE PROCEDURE        get_user_info_sync(
   p_oprstamp     IN     VARCHAR2,
   p_branchcode      OUT VARCHAR2,
   p_branchname      OUT VARCHAR2,
   p_docdate         OUT VARCHAR2,
   p_modulename      OUT VARCHAR2,
   p_modulecode      OUT VARCHAR2,
   p_dblink          OUT VARCHAR2,
   p_errflag         OUT VARCHAR2,
   p_errmsg          OUT VARCHAR2)
IS
   /*******************************************************************************************
   Author: Fahim
          Junior Programmer,
          ERA InfoTech Ltd.
   Purpose:Retreive user information(servicewise) and synchronize any changes in remote database

   Modification History:

   SL #       DATE           Modified by                  Purpose                    Program name
   1         10/02/2019       FAHIM                SYNCHRONIZE USER BRANCH             UTILITY
   ********************************************************************************************/
   v_branchcd     VARCHAR2 (5) := NULL;
   v_barnchname   VARCHAR2 (500) := NULL;
   v_docdate      DATE;
   v_modulename   VARCHAR2 (50) := NULL;
   v_modulecode   VARCHAR2 (20) := NULL;
   v_dblink       VARCHAR2 (20) := NULL;
   v_sql          VARCHAR2 (4000);
   v_user         stlbas.DPG_BEFTN_CLEARING.typ_user_info@STUTLTOCBS;
   v_errflag      VARCHAR2 (5) := NULL;
   v_errmsg       VARCHAR2 (400) := NULL;
BEGIN
   BEGIN
      SELECT UPPER (authtype), divncode
        INTO v_modulename, v_branchcd
        FROM syusrmas
       WHERE UPPER (usercode) = UPPER (p_oprstamp);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         v_errflag := 'E1';
         v_errmsg :=
            'User Information Not Found for user- (' || p_oprstamp || ').';
         GOTO ON_ERROR;
      WHEN OTHERS
      THEN
         v_errflag := 'E2';
         v_errmsg :=
               'Error Getting User Information for user- ('
            || p_oprstamp
            || ').'
            || SQLERRM;
         GOTO ON_ERROR;
   END;

   BEGIN
      SELECT module_code, dblink
        INTO v_modulecode, v_dblink
        FROM authtype
       WHERE UPPER (module_name) = v_modulename;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         v_modulename := 'LOCAL';
      WHEN OTHERS
      THEN
         v_modulename := 'LOCAL';
   END;

   ----- Getting Branch Name from User Module via DBLINK

   IF v_modulecode <> 'LOCAL'               ---- was modulename 16032017 FAHIM
   THEN
      IF v_dblink IS NOT NULL
      THEN
         ------------ Check for Syncronization -----------
         BEGIN
            stlbas.DPG_BEFTN_CLEARING.get_istelar_user_info@STUTLTOCBS (
               UPPER (p_oprstamp),
               v_user,
               v_errmsg);

            IF v_errmsg IS NOT NULL
            THEN
               v_errflag := 'E3';
               GOTO ON_ERROR;
            END IF;
--raise_application_error(-20001,'v_user.divncode--'||v_user.divncode ||'--v_branchcd--' || v_branchcd);
            IF v_user.divncode <> v_branchcd
            THEN
               ---------- SYNCHRONIZE -------
               BEGIN
                  UPDATE STUTIL.SYUSRMAS
                     SET DIVNCODE = v_user.divncode,
                         APPRBY = 'SYSTEM',
                         APPRDT = SYSDATE
                   WHERE UPPER (usercode) = UPPER (p_oprstamp);

                  IF SQL%NOTFOUND
                  THEN
                     v_errflag := 'E4';
                     v_errmsg :=
                        'Failed to synchronize teller branch information. Please contact IT support.';
                     GOTO ON_ERROR;
                  END IF;
               END;
               
               v_branchcd := v_user.divncode;
               
            END IF;
         END;

         -----------------------------------------------
         BEGIN
            v_sql :=
                  'SELECT cacmpnam FROM stlbas.syparmas@'
               || v_dblink
               || '  WHERE cagrpcde = ''001'' AND cacmpcde = :2';


            EXECUTE IMMEDIATE v_sql INTO v_barnchname USING v_branchcd;

            v_sql := NULL;
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               v_errflag := 'E3';
               v_errmsg :=
                     'Error Getting Branch Information for Branch- '
                  || v_branchcd
                  || '. User- '
                  || p_oprstamp
                  || '. Module Name- '
                  || v_modulename
                  || '. DBLINK - '
                  || v_dblink;
               GOTO ON_ERROR;
            WHEN OTHERS
            THEN
               v_errflag := 'E4';
               v_errmsg :=
                  'Error Getting Branch Information for Branch- ' || SQLERRM;
               GOTO ON_ERROR;
         END;

         ------------------------------------------------
         BEGIN
            v_sql :=
                  'SELECT modday 
              FROM stlbas.stmodnam@'
               || v_dblink
               || '
              WHERE modopn = ''O'' AND brancd = :1';

            EXECUTE IMMEDIATE v_sql INTO v_docdate USING v_branchcd;

            v_sql := NULL;

            APEX_UTIL.set_session_state ('AI_CHCK_DAYOPN', 'OPEN');
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               v_docdate := SYSDATE;
               APEX_UTIL.set_session_state ('AI_CHCK_DAYOPN', 'CLOSED');
            WHEN OTHERS
            THEN
               v_errflag := 'E6';
               v_errmsg :=
                     'Error Getting Modday ( '
                  || v_branchcd
                  || ' ). '
                  || SQLERRM;
               GOTO ON_ERROR;
         END;
      ELSE
         v_errflag := 'E7';
         v_errmsg := 'DB Link not found for module - ' || v_modulename;
         GOTO ON_ERROR;
      END IF;
   --------------------------------
   ELSE
      --------------------------------
      v_docdate := SYSDATE;
   END IF;

   GOTO ON_SUCCESS;

  <<ON_ERROR>>
   p_errflag := v_errflag;
   p_errmsg := v_errmsg;
   GOTO END_EXEC;

  <<ON_SUCCESS>>
   p_branchcode := v_branchcd;
   p_branchname := v_barnchname;
   p_docdate := v_docdate;
   p_modulename := v_modulename;
   p_modulecode := v_modulecode;
   p_dblink := v_dblink;

  <<END_EXEC>>
   NULL;
END;
/
