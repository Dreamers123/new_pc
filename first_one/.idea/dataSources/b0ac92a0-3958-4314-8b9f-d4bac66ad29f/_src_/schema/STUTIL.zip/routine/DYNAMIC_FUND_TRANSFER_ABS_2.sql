CREATE PROCEDURE        DYNAMIC_fund_transfer_ABS_2 (

   p_dblink              IN     VARCHAR2,

   p_oprbrancd           IN     VARCHAR2,

   p_oprtamp             IN     VARCHAR2,

   p_tot_amount          IN     NUMBER,

   p_tot_charge_amount   IN     NUMBER,

   p_branch_code         IN     VARCHAR2,

   p_app_user            IN     VARCHAR2,

   p_AI_DOCDAT           IN     DATE,

   p_service_id          IN     VARCHAR2,

   pAI_USER_TYPE         IN     VARCHAR2,

   pAI_GROUPCODE         IN     VARCHAR2,

   p_docnumber              OUT VARCHAR2,

   pErrorFlag               OUT VARCHAR2,

   pErrorMessage            OUT VARCHAR2)

IS

   test                number :=0 ;

   v_row               VARCHAR2 (7);

   v_opst              VARCHAR2 (7);

   amount              NUMBER;

   oprstamp            VARCHAR2 (6);

   Mv_drcode           VARCHAR2 (20);

   v_tnum              VARCHAR2 (50) := NULL;

   v_erritem           VARCHAR2 (50) := NULL;

   O_ERR_FLG           VARCHAR2 (5) := NULL;

   O_ERR_MSG           VARCHAR2 (4000) := NULL;

   V_ACTYPE            VARCHAR2 (20);

   V_ACTNUM            VARCHAR2 (30);

   V_DOCTYPE           VARCHAR2 (5);

   V_oprcod            VARCHAR2 (50);

   v_errflg            VARCHAR2 (10) := NULL;

   V_VAT               VARCHAR2 (20) := 0;

   v_errmsg            VARCHAR2 (5000) := NULL;

   v_lmtamt            NUMBER := 0;

   o_curcde            VARCHAR2 (50);

   v_vat_crg           NUMBER := 0;

   V_CHRG              VARCHAR2 (20) := 0;

   v_Com_crg           NUMBER := 0;

   v_drcode            VARCHAR2 (10) := NULL;                            

   v_crcode            VARCHAR2 (10) := NULL;

   v_doctype2          VARCHAR2 (3) := NULL;

   v_p154_service_id   VARCHAR2 (50) := NULL;

   

   

   v_count             NUMBER ;

   V_PARKING_GL        VARCHAR2 (12);

   V_AC_GL_TYPE        VARCHAR2 (5);

   vCbsDocNo        VARCHAR2 (13);

   vDocNo           VARCHAR2 (20);

   vDocDate         DATE;

   vErrorFlag       VARCHAR2 (1) := NULL;

   vErrorMessage    VARCHAR2 (1024) := NULL;

BEGIN

  BEGIN           -------------DYNAMIN A/C TYPE / A/C NUM--------------------

      --raise_application_error (-20001,p_service_id);

      SELECT SERVICE_PRO_ACC_NO,

             (SELECT DISTINCT ACTYPE

                FROM STFACMAS@ST_REP, SERVICE_PRO_INFO A

               WHERE     ACTNUM = A.SERVICE_PRO_ACC_NO

                     AND BRANCD = SUBSTR (A.SERVICE_PRO_ACC_NO, 1, 3)

                     AND ACSTAT NOT IN ('CLS', 'TRF'))

                ACTYPE,

             PARKING_GL,

             AC_TYPE

        INTO V_ACTNUM,

             V_ACTYPE,

             V_PARKING_GL,

             V_AC_GL_TYPE

        FROM SERVICE_PRO_INFO

       WHERE UPPER (SERVICE_ID) = UPPER (p_service_id);

   EXCEPTION

      WHEN NO_DATA_FOUND

      THEN

         raise_application_error (

            -20001,

            'Destination A/c Information Not Found in SERVICE_PRO_INFO');

      WHEN TOO_MANY_ROWS

      THEN

         raise_application_error (

            -20001,

            'Too Many Destination A/c Information Not Found in SERVICE_PRO_INFO');

      WHEN OTHERS

      THEN

         raise_application_error (

            -20001,

            'Error Getting Destination A/c Information-ERROR:' || SQLERRM);

   END;



   --------VAT GL ----------



   ------------------------------------------------------DOCTYPE ASSIGN------------------



   BEGIN

      IF p_branch_code = SUBSTR (V_ACTNUM, 1, 3)

      THEN

         V_DOCTYPE := 'CS';

         V_oprcod := 'DEP';

         v_doctype2 := 'DC';

      ELSE

         V_DOCTYPE := 'IC';

         V_oprcod := 'IB1';

         v_doctype2 := 'IT';

      END IF;

   END;

   ---------------------------Teller Limit------------



    BEGIN

            dpr_teller_limit_check (p_dblink       => p_dblink, ----------->PASSINGDBLINKFROMAPPLICATIONITEM

                                    p_brancd       => p_branch_code,

                                    p_appusr       => p_app_user,

                                    p_doctyp       => V_DOCTYPE,

                                    p_oprcod       => V_oprcod,

                                    p_actype       => V_ACTYPE,

                                    p_curcde       => 'BDT',

                                    p_debcre       => 'C',

                                    p_typcde       => 'TLR',

                                    p_lmtamt       => v_lmtamt,

                                    p_tlr_curcde   => o_curcde,

                                    p_errflg       => v_errflg,

                                    p_errmsg       => v_errmsg);



            IF v_errmsg IS NOT NULL

            THEN

               raise_application_error (-20001, v_errflg || '-' || v_errmsg);

            ELSIF p_tot_amount > v_lmtamt

            THEN

               v_errmsg :=

                  'Limit Amount for this transaction has exceeded....!REF: TLR/'

                  || p_app_user

                  || '/'

                  || V_DOCTYPE

                  || '/'

                  || V_oprcod

                  || '/'

                  || V_ACTYPE

                  || '/BDT';

               raise_application_error (-20001, v_errmsg);

            ELSE

               v_errmsg := NULL;

            END IF;

         EXCEPTION

            WHEN OTHERS

            THEN

               raise_application_error (-20001, v_errmsg || SQLERRM);

         END;



   ----------------------------------------------------------------end teller----



   IF v_errmsg IS NULL

   THEN

      ----------------------DOCUMENT GENERATION PROCESS--------------------------



        BEGIN

      EMOB.COMPANY_COLLECTION_NEW.COLLECTION_POSTING@utility_to_agent (

         pStelarRunUser       => p_app_user,                       ---APP_USER

         pStelarLoginBranch   => p_branch_code,               ----AI_BRANCHCOD

         pDebitAcType         => V_AC_GL_TYPE,                                 --GL/PT

         pDebitAcNo           => V_PARKING_GL,

         pCreditBranch        => SUBSTR (V_ACTNUM, 1, 3),

         pTotalAmount         => p_tot_amount,

         pCbsDocNo            => vCbsDocNo,

         pDocNo               => vDocNo,

         pDocDate             => vDocDate,

         pErrorFlag           => vErrorFlag,

         pErrorMessage        => vErrorMessage);

         

         p_docnumber:=vCbsDocNo ;

   EXCEPTION

      WHEN OTHERS

      THEN

         raise_application_error (

            -20001,

            'ABS Process Calling Problem A1. - ' || SQLERRM);

   END;



    

         /*    --*******************

   SELECT COUNT(ID) INTO V_COUNT FROM STCHINFO WHERE SERVICENO=P_SERVICE_ID  ;



   FOR i IN  1.. V_COUNT

   LOOP

   TEST:=TEST+i ;

   END LOOP ;

   

   RAISE_APPLICATION_ERROR (-20001,'test---'||TEST);



      --**************** */

      



      BEGIN

         SELECT VATGL, CHRGL

           INTO V_VAT, V_CHRG

           FROM STCHINFO

          WHERE UPPER (SERVICENO) = UPPER (p_service_id) AND ID = '1';

      -- raise_application_error (-20001,V_VAT||V_CHRG);

      EXCEPTION

         WHEN NO_DATA_FOUND

         THEN

            raise_application_error (-20001,

                                     'Vat GL not found in STCHINFO table.');

      END;

      --------IF other charge is available then  Condition-------- *********************



      IF V_VAT IS NOT NULL AND V_CHRG IS NOT NULL

      THEN

         -----------vat GL Amount %-------------------------

         BEGIN

          

            SELECT ROUND ( (VATPER * p_tot_amount) / 100, 2)

              INTO v_vat_crg

              FROM STCHINFO

             WHERE UPPER (SERVICENO) = UPPER (p_service_id) AND ID = '1'; --- ID WILL VERIABLE USING LOOP...

         EXCEPTION

            WHEN NO_DATA_FOUND

            THEN

               raise_application_error (-20001, 'Vat Percentage not Found');

         END;                                                -----------------



         ----------commission GL amount %---------------------

         BEGIN

            SELECT ROUND ( (CHARGE * p_tot_amount) / 100, 2) --p_tot_amount   (1 - VATPER)

              INTO v_Com_crg

              FROM STCHINFO

             WHERE UPPER (SERVICENO) = UPPER (p_service_id) AND ID = '1'; --- ID WILL VERIABLE  USING LOOP....

         EXCEPTION

            WHEN NO_DATA_FOUND

            THEN

               raise_application_error (-20001,

                                        'Comission Percentage not Found');

         END;



         -- raise_application_error (-20001,p_branch_code||'-'||SUBSTR(V_ACTNUM,1, 3)) ;



         IF vErrorMessage  IS NULL  --O_ERR_MSG

         THEN

            -- AC GL Code Start--



            BEGIN

               stutil.dpr_getacglcode (p_dblink    => p_dblink,

                                       p_brancd    => SUBSTR (V_ACTNUM, 1, 3),

                                       p_actype    => V_ACTYPE,

                                       p_docdate   => p_AI_DOCDAT, --:AI_DOCDAT,

                                       p_glcode    => v_drcode,

                                       p_errflg    => O_ERR_FLG,

                                       p_errmsg    => O_ERR_MSG);



               IF O_ERR_FLG IS NOT NULL

               THEN

                  raise_application_error (-20001,

                                           O_ERR_FLG || ' - ' || O_ERR_MSG);



                  ROLLBACK;

                  RETURN;

               END IF;

            END;



            -- AC GL Code End--

            -- Get branch gl code

            --raise_application_error ( -20001,'ssssssssssss'||p_oprbrancd);

            IF (SUBSTR (V_ACTNUM, 1, 3) <> p_oprbrancd)

            THEN

               BEGIN

                  stutil.dpr_get_branch_glcode (p_dblink   => p_dblink,

                                                p_brancd   => p_oprbrancd,

                                                p_glcode   => v_crcode,

                                                p_errflg   => O_ERR_FLG,

                                                p_errmsg   => O_ERR_MSG);



                  IF O_ERR_FLG IS NOT NULL

                  THEN

                     raise_application_error (

                        -20001,

                        O_ERR_FLG || ' - ' || O_ERR_MSG || 'E11');

                     ROLLBACK;

                     RETURN;

                  END IF;

               END;

            ELSE

               v_crcode := 'DUMMY';

            END IF;

            ----------------------- Credit Entry-------------------------

            

            BEGIN 

               dpr_insert_fetran (

                  p_dblink     => p_dblink,

                  p_brancd     => SUBSTR (V_ACTNUM, 1, 3),                   --p_branch_code,

                  p_doctyp     => v_doctype2,

                  p_docnum     => vCbsDocNo,

                  p_sernum     => 1,

                  p_docdat     => p_AI_DOCDAT,

                  p_valdat     => p_AI_DOCDAT,

                  p_oprcod     => V_oprcod,

                  p_actype     => v_actype,

                  p_actnum     => V_ACTNUM,       --p_branch_code||'00000099',

                  p_curcde     => 'BDT',

                  p_exrate     => 1,

                  p_debcre     => 'C',                                 -------

                  p_dbamfc     => 0,

                  --------0,

                  p_dbamlc     => 0,

                  --------0,

                  p_cramfc     =>  p_tot_amount, -------TO_NUMBER(APEX_APPLICATION.G_F09(v_row),'999G999G999G999G990D00'),

                  p_cramlc     =>  p_tot_amount, -------TO_NUMBER(APEX_APPLICATION.G_F09(v_row),'999G999G999G999G990D00'),

                  p_curbal     =>  0,

                  p_balflg     => 'Y',

                  p_chgflg     => 'N',

                  p_chqser     => NULL,

                  p_chqnum     => NULL,

                  p_chqdat     => NULL,

                  p_trbrancd   => p_oprbrancd,                           --085

                  p_tractype   => NULL,                         ---v_depactyp,

                  p_tractnum   => NULL,                          ---v_depacno,

                  p_trchqser   => NULL,

                  p_trchqnum   => NULL,

                  p_trchqdat   => NULL,

                  p_clrzon     => NULL,

                  p_clrday     => NULL,

                  p_prtflg     => 'N',

                  p_glcode     => NULL,

                  p_opbrancd   => p_branch_code,                         --085

                  p_remark     => p_service_id || ' ' || 'Bill Collection.',

                  p_yrprfx     => NULL,

                  p_chgcde     => 'N',

                  p_modcde     => 'ST',

                  p_supid2     => p_app_user,

                  p_drcode     => v_crcode, -- v_drcode,                      --'10100-01',

                  p_crcode     => v_drcode, --v_crcode,                      --'15700-01',

                  p_oprstamp   => p_oprtamp,

                  p_timstamp   => SYSTIMESTAMP,

                  p_glflag     => 'Y',

                  p_refno5     => NULL,

                  p_errflg     => O_ERR_FLG,

                  p_errmsg     => O_ERR_MSG);



               IF O_ERR_FLG IS NOT NULL

               THEN

                  raise_application_error (

                     -20001,

                     O_ERR_FLG || '-' || O_ERR_MSG || 'E1');

               END IF;

            END;



            -- Get branch gl code

            --withdrawal start charge----------D

            BEGIN

               dpr_insert_fetran (

                  p_dblink     => p_dblink,

                  p_brancd     => SUBSTR (V_ACTNUM, 1, 3), --v_depbranch, --:AI_BRANCH_CODE,

                  p_doctyp     => 'IT',

                  p_docnum     => vCbsDocNo,

                  p_sernum     => 3,

                  p_docdat     => p_AI_DOCDAT,                   --:AI_DOCDAT,

                  p_valdat     => p_AI_DOCDAT,                   --:AI_DOCDAT,

                  p_oprcod     => 'WDL',                       ------v_oprcod,

                  p_actype     => V_ACTYPE,                          -- 'Z99',

                  p_actnum     => V_ACTNUM,       ---v_depbranch|| '00000099',

                  p_curcde     => 'BDT',

                  p_exrate     => 1,

                  p_debcre     => 'D',                                 -------

                  p_dbamfc     => v_Com_crg, --TO_NUMBER (APEX_APPLICATION.G_F09 (v_row),'999G999G999G999G990D00'), --------0,

                  p_dbamlc     => v_Com_crg, --TO_NUMBER (APEX_APPLICATION.G_F09 (v_row),'999G999G999G999G990D00'), --------0,

                  p_cramfc     => 0, -------TO_NUMBER (APEX_APPLICATION.G_F09 (v_row),'999G999G999G999G990D00'),

                  p_cramlc     => 0, -------TO_NUMBER (APEX_APPLICATION.G_F09 (v_row),'999G999G999G999G990D00'),

                  p_curbal     => 0,

                  p_balflg     => 'Y',

                  p_chgflg     => 'N',

                  p_chqser     => NULL,

                  p_chqnum     => NULL,

                  p_chqdat     => NULL,

                  p_trbrancd   => p_oprbrancd, --APEX_APPLICATION.G_F01 (v_row),

                  p_tractype   => NULL,                         ---v_depactyp,

                  p_tractnum   => NULL,                          ---v_depacno,

                  p_trchqser   => NULL,

                  p_trchqnum   => NULL,

                  p_trchqdat   => NULL,

                  p_clrzon     => NULL,

                  p_clrday     => NULL,

                  p_prtflg     => 'N',

                  p_glcode     => NULL,

                  p_opbrancd   => p_branch_code, --:AI_BRANCH_CODE,--SUBSTR (V_ACTNUM, 1, 3), --v_ai_branch_code, ----------:AI_BRANCH_CODE,

                  p_remark     =>    p_service_id

                                  || ' '

                                  || 'BILL COLLECTION-CHARGE FEE.',

                  p_yrprfx     => NULL,

                  p_chgcde     => 'N',

                  p_modcde     => 'ST',

                  p_supid2     => p_app_user,                     --:APP_USER,

                  p_drcode     => v_drcode,                      --'10100-01',

                  p_crcode     => '14100-01',                    --'15700-01',

                  p_oprstamp   => p_oprtamp,                    --p_oprbrancd,

                  p_timstamp   => SYSTIMESTAMP,

                  p_glflag     => 'Y',

                  p_refno5     => NULL,

                  p_errflg     => O_ERR_FLG,

                  p_errmsg     => O_ERR_MSG);



               IF O_ERR_FLG IS NOT NULL

               THEN

                  raise_application_error (

                     -20001,

                     O_ERR_FLG || '-' || O_ERR_MSG || 'E2');

               END IF;

            EXCEPTION

               WHEN OTHERS

               THEN

                  raise_application_error (

                     -20001,

                     'ERROR: "dpr_insert_fetran1 -" ' || SQLERRM);

                  ROLLBACK;

                  RETURN;

            END;



            BEGIN      -----------------------VATFee-------------------------D

               dpr_insert_fetran (

                  p_dblink     => p_dblink,

                  p_brancd     => SUBSTR (v_actnum, 1, 3),  --:AI_BRANCH_CODE,

                  p_doctyp     => 'IT',

                  p_docnum     => vCbsDocNo,

                  p_sernum     => 5,

                  p_docdat     => p_AI_DOCDAT,                   --:AI_DOCDAT,

                  p_valdat     => p_AI_DOCDAT,                   --:AI_DOCDAT,

                  p_oprcod     => 'WDL',

                  p_actype     => v_actype,

                  p_actnum     => V_ACTNUM,     --:AI_BRANCH_CODE||'00000099',

                  p_curcde     => 'BDT',

                  p_exrate     => 1,

                  p_debcre     => 'D',                                 -------

                  p_dbamfc     => v_vat_crg,

                  p_dbamlc     => v_vat_crg,

                  p_cramfc     => 0,

                  p_cramlc     => 0,

                  p_curbal     => 0,

                  p_balflg     => 'Y',

                  p_chgflg     => 'N',

                  p_chqser     => NULL,

                  p_chqnum     => NULL,

                  p_chqdat     => NULL,

                  p_trbrancd   => p_oprbrancd, --APEX_APPLICATION.G_F02(v_row),--:AI_BRANCH_CODE,        --085

                  p_tractype   => NULL,                         ---v_depactyp,

                  p_tractnum   => NULL,                          ---v_depacno,

                  p_trchqser   => NULL,

                  p_trchqnum   => NULL,

                  p_trchqdat   => NULL,

                  p_clrzon     => NULL,

                  p_clrday     => NULL,

                  p_prtflg     => 'N',

                  p_glcode     => NULL,

                  p_opbrancd   => p_branch_code, --:AI_BRANCH_CODE,                       --085

                  p_remark     =>    p_service_id

                                  || ' '

                                  || 'BILL COLLECTION-VAT FEE.',

                  p_yrprfx     => NULL,

                  p_chgcde     => 'N',

                  p_modcde     => 'ST',

                  p_supid2     => p_app_user,                     --:APP_USER,

                  p_drcode     => v_drcode,                      --'10100-01',

                  p_crcode     => '14100-01',                    --'15700-01',

                  p_oprstamp   => p_oprtamp,

                  p_timstamp   => SYSTIMESTAMP,

                  p_glflag     => 'Y',

                  p_refno5     => NULL,

                  p_errflg     => O_ERR_FLG,

                  p_errmsg     => O_ERR_MSG);



               IF O_ERR_FLG IS NOT NULL

               THEN

                  raise_application_error (

                     -20001,

                     O_ERR_FLG || '-' || O_ERR_MSG || 'E3');

               END IF;

            EXCEPTION

               WHEN OTHERS

               THEN

                  raise_application_error (

                     -20001,

                     'ERROR: "dpr_insert_fetran2 -" ' || SQLERRM);

                  ROLLBACK;

                  RETURN;

            END;

            BEGIN

               stutil.dpr_get_branch_glcode (

                  p_dblink   => p_dblink,

                  p_brancd   => SUBSTR (v_actnum, 1, 3),

                  p_glcode   => Mv_drcode,

                  p_errflg   => O_ERR_FLG,

                  p_errmsg   => O_ERR_MSG);

               IF O_ERR_FLG IS NOT NULL

               THEN

                  raise_application_error (-20001,

                                           O_ERR_FLG || '-' || O_ERR_MSG);



                  ROLLBACK;

                  RETURN;

               END IF;

            END;

            BEGIN ---------------------------ChargeFee------------------------------------C

               dpr_insert_fetran (

                  p_dblink     => p_dblink,

                  p_brancd     => '100',

                  p_doctyp     => 'IT',                  ------------bujhbo na

                  p_docnum     => vCbsDocNo,

                  p_sernum     => 4,

                  p_docdat     => p_AI_DOCDAT,                   --:AI_DOCDAT,

                  p_valdat     => p_AI_DOCDAT,                   --:AI_DOCDAT,

                  p_oprcod     => 'DEP',

                  p_actype     => 'Z99',

                  p_actnum     => '10000000099',

                  p_curcde     => 'BDT',

                  p_exrate     => 1,

                  p_debcre     => 'C',                                 -------

                  p_dbamfc     => 0,

                  p_dbamlc     => 0,

                  p_cramfc     => v_Com_crg,

                  p_cramlc     => v_Com_crg,

                  p_curbal     => 0,

                  p_balflg     => 'Y',

                  p_chgflg     => 'N',

                  p_chqser     => NULL,

                  p_chqnum     => NULL,

                  p_chqdat     => NULL,

                  p_trbrancd   => p_oprbrancd, --APEX_APPLICATION.G_F02(v_row),

                  p_tractype   => NULL,                         ---v_depactyp,

                  p_tractnum   => NULL,                          ---v_depacno,

                  p_trchqser   => NULL,

                  p_trchqnum   => NULL,

                  p_trchqdat   => NULL,

                  p_clrzon     => NULL,

                  p_clrday     => NULL,

                  p_prtflg     => 'N',

                  p_glcode     => NULL,

                  p_opbrancd   => p_branch_code,            --:AI_BRANCH_CODE,

                  p_remark     =>    p_service_id

                                  || ' '

                                  || 'BILL COLLECTION-CHARGE FEE.',

                  p_yrprfx     => NULL,

                  p_chgcde     => 'N',

                  p_modcde     => 'ST',

                  p_supid2     => p_app_user,                     --:APP_USER,

                  p_drcode     => Mv_drcode,                     --'10100-01',

                  p_crcode     => V_CHRG, --cgargeGL                      --'10100-01',

                  p_oprstamp   => p_oprtamp,

                  p_timstamp   => SYSTIMESTAMP,

                  p_glflag     => 'Y',

                  p_refno5     => NULL,

                  p_errflg     => O_ERR_FLG,

                  p_errmsg     => O_ERR_MSG);



               IF O_ERR_FLG IS NOT NULL

               THEN

                  raise_application_error (

                     -20001,

                     O_ERR_FLG || '-' || O_ERR_MSG || 'E5');

               END IF;

            EXCEPTION

               WHEN OTHERS

               THEN

                  raise_application_error (

                     -20001,

                     'ERROR: "dpr_insert_fetran3 -" ' || SQLERRM);

                  ROLLBACK;

                  RETURN;

            END;



            BEGIN                                 -------------vatfeee------ C

               dpr_insert_fetran (

                  p_dblink     => p_dblink,

                  p_brancd     => '100',

                  p_doctyp     => 'IT',                      -----bujhono na 2

                  p_docnum     => vCbsDocNo,

                  p_sernum     => 6,

                  p_docdat     => p_AI_DOCDAT,                   --:AI_DOCDAT,

                  p_valdat     => p_AI_DOCDAT,                   --:AI_DOCDAT,

                  p_oprcod     => 'DEP',

                  p_actype     => 'Z99',

                  p_actnum     => '10000000099',

                  p_curcde     => 'BDT',

                  p_exrate     => 1,

                  p_debcre     => 'C',                                 -------

                  p_dbamfc     => 0,

                  p_dbamlc     => 0,

                  p_cramfc     => v_vat_crg,

                  p_cramlc     => v_vat_crg,

                  p_curbal     => 0,

                  p_balflg     => 'Y',

                  p_chgflg     => 'N',

                  p_chqser     => NULL,

                  p_chqnum     => NULL,

                  p_chqdat     => NULL,

                  p_trbrancd   => p_oprbrancd,

                  p_tractype   => NULL,                         ---v_depactyp,

                  p_tractnum   => NULL,                          ---v_depacno,

                  p_trchqser   => NULL,

                  p_trchqnum   => NULL,

                  p_trchqdat   => NULL,

                  p_clrzon     => NULL,

                  p_clrday     => NULL,

                  p_prtflg     => 'N',

                  p_glcode     => NULL,

                  p_opbrancd   => p_branch_code,            --:AI_BRANCH_CODE,

                  p_remark     =>    p_service_id

                                  || ' '

                                  || 'BILL COLLECTION-VAT FEE.',

                  p_yrprfx     => NULL,

                  p_chgcde     => 'N',

                  p_modcde     => 'ST',

                  p_supid2     => p_app_user,                     --:APP_USER,

                  p_drcode     => Mv_drcode,                     --'10100-01',

                  p_crcode     => V_VAT, ---vatGL                       --'15700-01',

                  p_oprstamp   => p_oprtamp,

                  p_timstamp   => SYSTIMESTAMP,

                  p_glflag     => 'Y',

                  p_refno5     => NULL,

                  p_errflg     => O_ERR_FLG,

                  p_errmsg     => O_ERR_MSG);



               IF O_ERR_FLG IS NOT NULL

               THEN

                  raise_application_error (

                     -20001,

                     O_ERR_FLG || '-' || O_ERR_MSG || 'E6');

               END IF;

            EXCEPTION

               WHEN OTHERS

               THEN

                  raise_application_error (

                     -20001,

                     'ERROR: "dpr_insert_fetran4 -" ' || SQLERRM);

                  ROLLBACK;

                  RETURN;

            END;

         END IF;

         

         IF O_ERR_MSG IS NULL

         THEN

            BEGIN

               -- raise_application_error (-20001,OPRSTAMP||'/'||APEX_APPLICATION.G_f01(i));

               UPDATE STUTLINF

                  SET APPFLG = 'Y',

                      OPRSTAMP_APP = p_app_user,

                      TIMSTAMP_APP = SYSDATE,

                      DOCNUM = vCbsDocNo,

                      DOCTYP = V_DOCTYPE,

                      DOCDATE = p_AI_DOCDAT

                WHERE 

                       UPPER (SERVICE_ID) = UPPER (p_service_id)  -- UPPER (SERVICE_ID) = UPPER (NVL(:P154_SERVICE_ID, '0'))

                       AND APPFLG = 'N'

                       AND OPRSTAMP_APP is null

                       and  TIMSTAMP_APP is null

                       AND OPRSTAMP=p_oprbrancd

                       AND BRANCD='108';

                



               IF SQL%NOTFOUND

               THEN

                  raise_application_error (-20001, 'DATA not found !');

                  ROLLBACK;

                  RETURN;

               END IF;

            EXCEPTION

               WHEN OTHERS

               THEN

                  raise_application_error (

                     -20001,

                     'STUTLINF Update Failed! ERROR: ' || SQLERRM);

                  ROLLBACK;

                  RETURN;

            END;

         ELSE

            raise_application_error (-20001, 'ERROR-101 : ' || O_ERR_MSG);

            ROLLBACK;

            RETURN;    

         END IF;

      END IF;

      

    ELSE

         raise_application_error (-20001, 'ERROR-101 : ' || O_ERR_MSG);

         ROLLBACK;

         RETURN;

      --END IF;

      END IF;

  

END;
/
