CREATE PROCEDURE json_generate (txt OUT VARCHAR2)
IS
BEGIN
   APEX_JSON.INITIALIZE_CLOB_OUTPUT;
   APEX_JSON.OPEN_OBJECT;

   --RAISE_APPLICATION_ERROR(-20001, 'TEST -- ');
   FOR i IN (SELECT c001,
                    c002,
                    c003,
                    c004,
                    c005
               FROM apex_collections
              WHERE collection_name = 'BURO')
   LOOP
      APEX_JSON.OPEN_OBJECT;
      APEX_JSON.WRITE ('ID', i.c001);
      APEX_JSON.WRITE ('NAME', i.c002);
      APEX_JSON.WRITE ('AMOUNT', i.c003);
      APEX_JSON.WRITE ('INSTALLMENT', i.c004);
      APEX_JSON.WRITE ('SURCHARGE', i.c005);
      APEX_JSON.CLOSE_OBJECT;
   END LOOP;

   APEX_JSON.CLOSE_OBJECT;
   APEX_JSON.CLOSE_ALL;
   raise_application_error (-20001, 'test -- ' || APEX_JSON.GET_CLOB_OUTPUT);
   APEX_JSON.FREE_OUTPUT;
END;
/
