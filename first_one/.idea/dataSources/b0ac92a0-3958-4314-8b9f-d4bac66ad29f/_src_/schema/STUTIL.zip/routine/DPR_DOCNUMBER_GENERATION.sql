CREATE PROCEDURE dpr_docnumber_generation (
   p_dblink     IN     VARCHAR2, 
   p_compcd     IN     VARCHAR2,
   p_modlcd     IN     VARCHAR2,
   p_doctyp     IN     VARCHAR2,
   p_subtyp     IN     VARCHAR2,
   p_docdat     IN     VARCHAR2,
   p_loccde     IN     VARCHAR2,
   p_origmodl   IN     VARCHAR2,
   p_docnum        OUT VARCHAR2,
   p_errflag       OUT VARCHAR2,
   p_errmsg        OUT VARCHAR2)
IS
   v_sql   VARCHAR2 (4000) := NULL;
BEGIN
   v_sql :=
      'begin docnumber_generation@'||p_dblink||'(:1,:2,:3, :4, :5, :6, :7,:8); end;';

   EXECUTE IMMEDIATE v_sql
      USING IN p_compcd,
            IN p_modlcd,
            IN p_doctyp,
            IN p_subtyp,
            IN p_docdat,
            IN p_loccde,
            IN p_origmodl,
            OUT p_docnum;
EXCEPTION
   WHEN OTHERS
   THEN
      p_errflag := 'E';
      p_errmsg := SQLERRM;
END;
/
