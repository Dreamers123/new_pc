CREATE FUNCTION stamp_fee (p_amount NUMBER)
   RETURN NUMBER
IS
   v_stamp   NUMBER;
BEGIN
   IF p_amount >= 400
   THEN
      BEGIN
         SELECT AMT
           INTO v_stamp
           FROM STPARAMT
          WHERE TYPE = 'MET' AND SUBTYPE = 'STM';
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            raise_application_error (
               -20001,
               'Destination A/c Information Not Found in STPARAMT (TYPE- MET ,SUBTYPE=STM)');
         WHEN OTHERS
         THEN
            raise_application_error (
               -20001,
                  'Error Getting Destination A/c Information - ERROR : '
               || SQLERRM);
      END;
   ELSE
      v_stamp := 00;
   END IF;

   RETURN v_stamp;
END;
/
