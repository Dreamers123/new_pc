CREATE PROCEDURE dpr_teller_limit_check (
   p_dblink       IN     VARCHAR2,
   p_brancd       IN     VARCHAR2,
   p_appusr       IN     VARCHAR2,
   p_doctyp       IN     VARCHAR2,
   p_oprcod       IN     VARCHAR2,
   p_actype       IN     VARCHAR2,
   p_curcde       IN     VARCHAR2,
   p_debcre       IN     VARCHAR2,
   p_typcde       IN     VARCHAR2,
   p_lmtamt          OUT VARCHAR2,
   p_tlr_curcde      OUT VARCHAR2,
   p_errflg         OUT VARCHAR2,
   p_errmsg          OUT VARCHAR2)
IS
   v_sql      VARCHAR2 (4000) := NULL;

BEGIN
   v_sql :=
         'begin 
          dpk_all_tran.dpr_teller_limit_check@'
      || p_dblink
      || ' (
            i_brancd       => :1,
            i_appusr       => :2,
            i_doctyp       => :3,
            i_oprcod       => :4,
            i_actype       => :5,
            i_curcde       => :6,
            i_debcre       => :7,
            i_typcde       => :8,
            o_lmtamt       => :9,
            o_tlr_curcde   => :10,
            errflg         => :11,
            errmsg         => :12);
            end;';

   EXECUTE IMMEDIATE v_sql
      USING IN p_brancd,
            IN p_appusr,
            IN p_doctyp,
            IN p_oprcod,
            IN p_actype,
            IN p_curcde,
            IN p_debcre,
            IN p_typcde,
            OUT p_lmtamt,
            OUT p_tlr_curcde,
            OUT p_errflg,
            OUT p_errmsg;
END;
/
