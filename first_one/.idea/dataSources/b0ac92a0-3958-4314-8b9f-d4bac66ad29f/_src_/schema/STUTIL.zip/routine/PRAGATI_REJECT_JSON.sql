CREATE procedure        pragati_reject_json(receipt IN varchar2,
                                     status OUT VARCHAR2,
                                     no_sub OUT NUMBER)
is 
v_url             VARCHAR2 (200);
l_response_text   CLOB;
l_count number;
v_reqid number;
begin

   v_url := 'http://plil.pragatilife.com/banktrans/creceipt';
   apex_web_service.g_request_headers (1).name := 'Content-Type';
   apex_web_service.g_request_headers (1).VALUE :=
      'application/x-www-form-urlencoded';

   l_response_text :=
      apex_web_service.make_rest_request (
         p_url           => v_url,
         p_http_method   => 'POST',
         p_parm_name     => APEX_UTIL.string_to_table (
                              'marid:marpass:mreceipt'),
         p_parm_value    => APEX_UTIL.string_to_table (
                                 '000555'
                              || ':'
                              || '000555'
                              || ':'
                              || receipt));



   IF l_response_text IS NULL
   THEN
      raise_application_error (-20002, 'API calling Failed !!!');
   END IF;
   
   APEX_JSON.PARSE(l_response_text);
   
   l_count := APEX_JSON.get_count (p_path => '.');--, p_values => sJsonIndex);
   for i in 1..l_count
   loop
   status := NVL (APEX_JSON.get_varchar2 (p_path => '[%d].STATUS', p0 => i), 'NIL');
   no_sub := TO_NUMBER (APEX_JSON.get_varchar2 (p_path => '[%d].NO_OF_SUB', p0 => i));
   
   end loop;
   DBMS_OUTPUT.put_line('status -'||status|| '  sub --' || no_sub);
   
   SELECT NVL (MAX (REQUESTID), 0) + 1
     INTO v_reqid
     FROM IN_OUT_JSON;

   INSERT INTO IN_OUT_JSON (REQUESTID,
                            REQUEST_name,
                            request,
                            JSON_RESPONSE,
                            in_time
                            )
        VALUES (v_reqid,
                'Pragati Reject Payment',
                v_url || 'Receipt No.-' || receipt,
                l_response_text,
                SYSDATE
                );
        commit ;        

end pragati_reject_json;
/
