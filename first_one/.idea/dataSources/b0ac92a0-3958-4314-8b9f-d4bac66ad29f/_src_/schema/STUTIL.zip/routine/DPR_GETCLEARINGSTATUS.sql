CREATE PROCEDURE        dpr_getClearingStatus (
   p_dblink         IN     VARCHAR2,
   p_tansactionid   IN     VARCHAR2,
   p_custype        IN     VARCHAR2,
   p_isgovt         IN     VARCHAR2,
   p_service        IN     VARCHAR2,
   p_clearing          OUT VARCHAR2, -- TRUE / FALSE
   p_status            OUT VARCHAR2, -- ERROR / SENT / POSTED / BOUNCED
   p_docnumber         OUT VARCHAR2,
   p_errflg            OUT VARCHAR2,
   p_errmsg            OUT VARCHAR2)
IS
   v_sql          VARCHAR2 (4000) := NULL;
   v_dep_branch   VARCHAR2 (5) := NULL;
   v_dep_acno     VARCHAR2 (15) := NULL;
   v_dep_actype   VARCHAR2 (5) := NULL;
   v_chqno        VARCHAR2 (15) := NULL;
   v_chqdate      DATE;
   v_amount       NUMBER := 0;
   v_status       VARCHAR2 (10) := NULL;
   V_service    VARCHAR2(20);
BEGIN

   p_clearing := 'TRUE';
   p_errflg := 'N';
   p_errmsg := NULL;
   V_service := p_service ;
  -- RAISE_APPLICATION_ERROR(-20001,p_service);
   IF  UPPER(V_service) = UPPER('KGDCL') THEN
   BEGIN
      SELECT SUBSTR (PARAVAL, 1, 3), SUBTYPE, PARAVAL
        INTO v_dep_branch,v_dep_actype,v_dep_acno
        FROM STUTIL.STPARAMT
       WHERE     TYPE = p_custype
             AND RESPONSECODE = DECODE (p_isgovt, 'YES', 2, 1);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         p_clearing := 'FALSE';
         p_status := 'ERROR';
         p_errflg := 'E1';
         p_errmsg := 'Destination A/c not found.';
      WHEN OTHERS
      THEN
         p_clearing := 'FALSE';
         p_status := 'ERROR';
         p_errflg := 'E1';
         p_errmsg := 'Error Getting destination A/c Info.'||SQLERRM;
   END;
   
  BEGIN
      SELECT CHQNUM, CHQDAT, TOTALBIL
        INTO v_chqno, v_chqdate, v_amount
        FROM STUTIL.STKGDCLB
       WHERE TRANID = p_tansactionid;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         p_clearing := 'FALSE';
         p_status := 'ERROR';
         p_errflg := 'E2';
         p_errmsg := 'Cheque Information Not Found.';
      WHEN OTHERS
      THEN
         p_clearing := 'FALSE';
         p_status := 'ERROR';
         p_errflg := 'E2';
         p_errmsg := 'Error Getting cheque Info.'||SQLERRM;
   END;

   ELSIF  UPPER(V_service) = UPPER('BGDCL') THEN

   BEGIN
      SELECT SUBSTR (PARAVAL, 1, 3), SUBTYPE, PARAVAL
        INTO v_dep_branch,v_dep_actype,v_dep_acno
        FROM STUTIL.STPARAMT
       WHERE     TYPE = p_custype
             AND RESPONSECODE = DECODE (p_isgovt, 'YES', 3, 4);
 -- RAISE_APPLICATION_ERROR(-20001,'TESTSFDF');
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         p_clearing := 'FALSE';
         p_status := 'ERROR';
         p_errflg := 'E1';
         p_errmsg := 'Destination A/c not found.';
      WHEN OTHERS
      THEN
 --RAISE_APPLICATION_ERROR(-20001,'TESTSFDF'||V_service||p_custype||p_isgovt);
         p_clearing := 'FALSE';
         p_status := 'ERROR';
         p_errflg := 'E1';
         p_errmsg := 'Error Getting destination A/c Info.'||SQLERRM;
   END;
   
      BEGIN
      SELECT CHQNUM, CHQDAT, TOTALBIL
        INTO v_chqno, v_chqdate, v_amount
        FROM STUTIL.STBGDCLB
       WHERE TRANID = p_tansactionid;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         p_clearing := 'FALSE';
         p_status := 'ERROR';
         p_errflg := 'E2';
         p_errmsg := 'Cheque Information Not Found.';
      WHEN OTHERS
      THEN
         p_clearing := 'FALSE';
         p_status := 'ERROR';
         p_errflg := 'E2';
         p_errmsg := 'Error Getting cheque Info.'||SQLERRM;
   END;

   END IF  ;
   
   --------- TEMPORARY SUPPORT -----------  FOR WRONG CLEARING A/C
   IF p_tansactionid = '2001120810000000256' THEN  --'1801250810000000018'   
   v_dep_branch := '081';
   v_dep_actype := 'S04';
   v_dep_acno := '08136000052';
   END IF;
   -------------------------------------- 

--RAISE_APPLICATION_ERROR(-20001,v_dep_branch||'-'||v_dep_actype||'--'||v_dep_acno);
--RAISE_APPLICATION_ERROR(-20001,' T '||v_dep_actype||' B '||v_dep_branch||' AC '||v_dep_acno||' C '||v_chqno||' A '||v_amount||'SDF'||p_custype);
   BEGIN
      v_sql :=
            'SELECT DECODE(STSFLG,''P'',''Posted'',''S'',''Sent'',''B'',''Bounced'',STSFLG) STSFLG,
                    DOCNUM
               FROM STLBAS.STFETRAN@'
         || p_dblink|| ' WHERE BRANCD = :v_dep_branch
                AND ACTYPE = :v_dep_actype
                AND ACTNUM = :v_dep_acno
                AND TRCHQNUM = :v_chqno
                AND CRAMLC = :v_amount
                AND DOCTYP = ''MO''';

      EXECUTE IMMEDIATE v_sql
         INTO v_status,p_docnumber
         USING v_dep_branch, v_dep_actype, v_dep_acno,v_chqno,v_amount;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         p_clearing := 'FALSE';
         p_errflg := 'E3';
         p_errmsg := 'This Cheque has not been sent for clearing'||v_dep_branch||' - '||v_dep_actype||' - '||v_dep_acno||' - '||v_chqno||' - '||v_amount;
      WHEN OTHERS
      THEN
         p_clearing := 'FALSE';
         p_errflg := 'E';
         p_errmsg := 'Failed to get cheque clearing info from CBS.....! '||SQLERRM;
   END;
   
   IF p_errflg = 'N' THEN
      p_status := v_status;
      p_errmsg := 'Success';
   END IF;   
  
END;
/
