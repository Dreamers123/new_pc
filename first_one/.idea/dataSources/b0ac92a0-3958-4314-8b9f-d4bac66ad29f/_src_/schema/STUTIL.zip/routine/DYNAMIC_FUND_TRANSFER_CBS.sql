CREATE PROCEDURE        DYNAMIC_fund_transfer_CBS (
   p_dblink              IN     VARCHAR2,
   p_opr_brancd          IN     VARCHAR2,
   p_oprstamp            IN     VARCHAR2,
   p_amount              IN     NUMBER,
   p_tot_charge_amount   IN     NUMBER,
   p_branch_code         IN     VARCHAR2,
   p_app_user            IN     VARCHAR2,
   p_AI_DOCDAT           IN     DATE,
   p_service_id          IN     VARCHAR2,
   p_ai_user_type        IN     VARCHAR2,
   p_AI_GROUPCODE        IN     VARCHAR2,
 --  p_tranid              IN     VARCHAR2,
   p_docnumber              OUT VARCHAR2,
   pErrorFlag               OUT VARCHAR2,
   pErrorMessage            OUT VARCHAR2)
IS
   oprstamp            VARCHAR2 (6);
   Mv_drcode           VARCHAR2 (20);
   v_tnum              VARCHAR2 (50) := NULL;
   v_erritem           VARCHAR2 (50) := NULL;
   O_ERR_FLG           VARCHAR2 (5) := NULL;
   O_ERR_MSG           VARCHAR2 (4000) := NULL;
   V_ACTYPE            VARCHAR2 (20);
   V_ACTNUM            VARCHAR2 (30);
   V_DOCTYPE           VARCHAR2 (5);
   V_oprcod            VARCHAR2 (50);
   v_errflg            VARCHAR2 (10) := NULL;
   V_VAT               VARCHAR2 (20) := 0;
   V_VATBRAN           VARCHAR2 (5);
   v_errmsg            VARCHAR2 (5000) := NULL;
   v_lmtamt            NUMBER := 0;
   o_curcde            VARCHAR2 (50);
   v_vat_crg           NUMBER := 0;
   V_AC_CHRG           VARCHAR2 (20) := 0;
   V_BRANCD_CRG        VARCHAR2 (5);
   V_ACTYPE_CRG        VARCHAR2 (5) := 0;
   v_Com_crg           NUMBER := 0;
   v_drcode            VARCHAR2 (10) := NULL;
   v_crcode            VARCHAR2 (10) := NULL;
   v_doctype2          VARCHAR2 (3) := NULL;
   v_amount            NUMBER := 0;
   v_total_com         NUMBER := 0;
   v_service_id        VARCHAR2 (50) := 0;
   v_opr_brancd        VARCHAR2 (3);
   v_oprstamp          VARCHAR2 (500) := NULL;

   V_STAMP_FLG         VARCHAR2 (10);
   V_STAMP_AMT         NUMBER;
   V_TOTAL_STAMP_AMT   NUMBER;
BEGIN

   BEGIN           -------------DYNAMIN A/C TYPE / A/C NUM--------------------
   
  
      SELECT A.SERVICE_PRO_ACC_NO,
             B.ACTYPE,
            A.STAMP_CRG_DEDUCT,
             A.STMP_AMOUNT
        INTO V_ACTNUM,
             V_ACTYPE,
            V_STAMP_FLG,
            V_STAMP_AMT
        FROM STUTIL.SERVICE_PRO_INFO A, STLBAS.STFACMAS@STUTLTOCBS B
       WHERE     B.ACTNUM = A.SERVICE_PRO_ACC_NO
             AND B.BRANCD = SUBSTR (A.SERVICE_PRO_ACC_NO, 1, 3)
             AND B.ACSTAT NOT IN ('CLS', 'TRF')
             AND UPPER (A.SERVICE_ID) = UPPER (p_service_id);
             
            
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
      
         pErrorFlag := 'E';
         pErrorMessage := 'E1- Failed to get Destination A/c Information  ';
         GOTO ON_ERROR;
      WHEN OTHERS
      THEN
      
         pErrorFlag := 'E';
         pErrorMessage :=
            'E2- Failed to get Destination A/c Information. Ref :' || SQLERRM;
         GOTO ON_ERROR;  
   END;


   ------------------------------DOCTYPE ASSIGN------------------

   BEGIN
      IF p_branch_code = SUBSTR (V_ACTNUM, 1, 3)
      THEN
         V_DOCTYPE := 'CS';
         V_oprcod := 'DEP';
         v_doctype2 := 'DC';
      ELSE
         V_DOCTYPE := 'IC';
         V_oprcod := 'IB1';
         v_doctype2 := 'IT';
      END IF;
   END;


   BEGIN
      stutil.dpr_getacglcode (p_dblink    => p_dblink,
                              p_brancd    => SUBSTR (V_ACTNUM, 1, 3),
                              p_actype    => v_actype,
                              p_docdate   => p_AI_DOCDAT,
                              p_glcode    => v_drcode,
                              p_errflg    => O_ERR_FLG,
                              p_errmsg    => O_ERR_MSG);

      IF O_ERR_FLG IS NOT NULL
      THEN
         raise_application_error (-20001, O_ERR_FLG || '-' || O_ERR_MSG);
         ROLLBACK;
         RETURN;
      END IF;
   END;

   IF (SUBSTR (V_ACTNUM, 1, 3) <> p_branch_code) -----------------Getbranchglcode
   THEN
      BEGIN
         stutil.dpr_get_branch_glcode (p_dblink   => p_dblink,
                                       p_brancd   => p_branch_code,
                                       p_glcode   => v_crcode,
                                       p_errflg   => O_ERR_FLG,
                                       p_errmsg   => O_ERR_MSG);

         IF O_ERR_FLG IS NOT NULL
         THEN
            raise_application_error (-20001, O_ERR_FLG || '-' || O_ERR_MSG);
            ROLLBACK;
            RETURN;
         END IF;
      END;
   ELSE
      v_crcode := 'DUMMY';
   END IF;

   ---------------------------Teller Limit------------

   BEGIN
      STUTIL.dpr_teller_limit_check (p_dblink       => p_dblink,
                                     p_brancd       => p_branch_code,
                                     p_appusr       => p_app_user, --:APP_USER,
                                     p_doctyp       => V_DOCTYPE,
                                     p_oprcod       => V_oprcod,
                                     p_actype       => V_ACTYPE,
                                     p_curcde       => 'BDT',
                                     p_debcre       => 'C',
                                     p_typcde       => 'TLR',
                                     p_lmtamt       => v_lmtamt,
                                     p_tlr_curcde   => o_curcde,
                                     p_errflg       => v_errflg,
                                     p_errmsg       => v_errmsg);

      IF v_errmsg IS NOT NULL
      THEN
         raise_application_error (-20003, p_branch_code || '/' || v_errmsg); ----Muhammad Abdul Qaium

         ROLLBACK;
         RETURN;
      END IF;
   END;

   ---------end teller----------

   BEGIN
      STUTIL.dpr_docnumber_generation (p_dblink     => p_dblink,
                                       p_compcd     => p_branch_code,
                                       p_modlcd     => 'ST',
                                       p_doctyp     => V_DOCTYPE,
                                       p_subtyp     => 1,
                                       p_docdat     => SYSDATE,
                                       p_loccde     => NULL,
                                       p_origmodl   => 'ST',
                                       p_docnum     => v_tnum,
                                       p_errflag    => v_errflg,
                                       p_errmsg     => v_errmsg);

      IF v_errmsg IS NULL
      THEN
         v_tnum := p_branch_code || v_tnum;

         p_docnumber := v_tnum;
      ELSE
         raise_application_error (
            -20001,
               v_errflg
            || '- '
            || v_errmsg
            || 'Document Number Generation Problem!!!');

         ROLLBACK;

         RETURN;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         raise_application_error (
            -20001,
               'Error Generating Docnumber - '
            || v_tnum
            || '. Error : '
            || SQLERRM);
         ROLLBACK;
         RETURN;
   END;

   -- raise_application_error(-20001,p_oprstamp);
   IF p_service_id IN ('PRAGATI',
                       'TITAS_NON_M',
                       'TITAS_METERED',
                       'TITAS_NON_M_DEMAND_NOTE')
   THEN
      BEGIN
           SELECT SERVICE_ID,                 
                --  BILLNO ,
                --  OPRSTAMP,
                  OPBRANCD,
                  CASE SERVICE_ID
                     WHEN 'TITAS_NON_M' THEN SUM (TOTAL_AMT) + SUM (SUR_AMT)
                     WHEN 'TITAS_METERED' THEN SUM (COLUMNC1)
                     WHEN 'TITAS_NON_M_DEMAND_NOTE' THEN SUM (TOTAL_AMT)
                     WHEN 'PRAGATI' THEN SUM (TOTAL_AMT)
                  END
                     "Total Amount",
                  SUM (
                     CASE
                        WHEN TOTAL_AMT >= 400 AND V_STAMP_FLG = 'E'
                        THEN
                           V_STAMP_AMT
                        ELSE
                           0
                     END)
                     STMP,
                  SUM (NVL (CHRG_AMT, 0)) CHARGE,
                  SUM (NVL (VAT_AMT, 0)) VAT
             INTO v_service_id,
                --  p_oprstamp,
                  v_opr_brancd,
                  v_amount,
                  V_TOTAL_STAMP_AMT,
                  v_Com_crg,
                  v_vat_crg
             FROM STUTIL.STUTLINF
            WHERE     UPPER (SERVICE_ID) = UPPER (p_service_id)
                  AND TO_NUMBER (OPBRANCD) <> 108
                  /*     AND ((OPBRANCD =DECODE (p_branch_code,100, OPBRANCD,p_branch_code))
                            OR (p_ai_user_type = 'A' AND p_AI_GROUPCODE = '010')) */
                  AND APPFLG = 'N'
                  AND OPBRANCD = TO_CHAR (p_opr_brancd)
         -- AND OPRSTAMP = p_oprstamp
         GROUP BY SERVICE_ID, OPBRANCD;
         
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            raise_application_error (-20001, 'No Data Found in STUTLINF');
         WHEN TOO_MANY_ROWS
         THEN
            raise_application_error (
               -20001,
               'More Than One Record Found in STUTLINF');
         WHEN OTHERS
         THEN
            raise_application_error (-20001,
                                     'Error for Finding Data From STUTLINF');
      END;
       
      



      BEGIN
         STUTIL.dpr_complete_transaction (
            p_dblink        => p_dblink,
            p_brancd        => p_branch_code,
            p_tran_type     => 'REG',
            p_acbrancd      => SUBSTR (V_ACTNUM, 1, 3),
            p_oprcod        => V_oprcod,
            p_modday        => p_AI_DOCDAT,
            p_valdat        => p_AI_DOCDAT,
            p_actype        => V_ACTYPE,
            p_actnum        => V_ACTNUM,
            p_chqsrl        => NULL,
            p_chqnum        => NULL,
            p_chqdat        => NULL,
            p_loccur        => 'BDT',
            p_doctyp        => V_DOCTYPE,
            p_modcde        => 'ST',
            p_trbrancd      => p_branch_code,
            p_tractype      => NULL,
            p_tractnum      => NULL,
            p_trchqser      => NULL,
            p_trchqnum      => NULL,
            p_trchqdat      => NULL,
            p_appusr        => p_oprstamp,
            p_action        => 'STALLTRN',
            p_appflg        => 'Y',
            p_supid2        => p_app_user,
            p_amount        => v_amount,
            p_tinnum        => NULL,
            p_appque        => 'N',
            p_serlno        => 1,
            p_docnum        => v_tnum,
            p_acvalid_req   => 'Y',
            p_clrzon        => NULL,
            p_clrday        => NULL,
            p_glcode        => NULL,
            p_yrprfx        => NULL,
            p_chgcde        => 'N',
            p_typcde        => 'TLR',
            p_glflag        => 'Y',
            p_remarks       => p_service_id || ' ' || 'Bill Collection.',
            p_erritem       => v_erritem,
            p_errflg        => O_ERR_FLG,
            p_errmsg        => O_ERR_MSG);

         -- raise_application_error (-20001, 'p_brancd' || ' - ' || p_branch_code||'a/c' ||V_ACTNUM||'a/c TYPE'
          --  ||V_ACTYPE||'OPR---'||V_oprcod||'DOCTYPE--'||V_DOCTYPE||'APPUSER--'||p_oprstamp||'AMOUNT--'||v_amount); 



         IF o_err_flg IS NOT NULL
         THEN
            raise_application_error (
               -20001,
                  o_err_flg
               || '-'
               || o_err_msg
               || 'CBS Transaction Not Complete...!');
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            raise_application_error (
               -20001,
               'ERROR: "dpr_complete_transaction -" ' || SQLERRM);
            ROLLBACK;
            RETURN;
      END;
     

      IF v_Com_crg > 0 OR v_vat_crg > 0
      THEN
         BEGIN
            SELECT VATGL,
                   VATBRAN,
                   BRANCH,
                   ACTYPE,
                   ACTNUM
              INTO V_VAT,                                             --Vat GL
                   V_VATBRAN,                                  --Vat GL Branch
                   V_BRANCD_CRG,                            --Charge GL Branch
                   V_ACTYPE_CRG,                              --Charge GL Type
                   V_AC_CHRG                                      -- Charge GL
              FROM STUTIL.STCHINFO
             WHERE UPPER (SERVICENO) = UPPER (p_service_id) AND ID = '1';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               raise_application_error (
                  -20001,
                  'Vat GL not found in STCHINFO table.');
         END;
      END IF;

      /*  BEGIN
           stutil.dpr_getacglcode (p_dblink    => p_dblink,
                                   p_brancd    => SUBSTR (V_ACTNUM, 1, 3),
                                   p_actype    => V_ACTYPE,
                                   p_docdate   => p_AI_DOCDAT,        --:AI_DOCDAT,
                                   p_glcode    => v_drcode,
                                   p_errflg    => O_ERR_FLG,
                                   p_errmsg    => O_ERR_MSG);

           IF O_ERR_FLG IS NOT NULL
           THEN
              raise_application_error (-20001, O_ERR_FLG || ' - ' || O_ERR_MSG);

              ROLLBACK;
              RETURN;
           END IF;
        END;

        -- AC GL Code End--
        IF (SUBSTR (V_ACTNUM, 1, 3) <> v_opr_brancd)
        THEN
           BEGIN
              stutil.dpr_get_branch_glcode (p_dblink   => p_dblink,
                                            p_brancd   => v_opr_brancd,
                                            p_glcode   => v_crcode,
                                            p_errflg   => O_ERR_FLG,
                                            p_errmsg   => O_ERR_MSG);

              IF O_ERR_FLG IS NOT NULL
              THEN
                 raise_application_error (
                    -20001,
                    O_ERR_FLG || ' - ' || O_ERR_MSG || 'E11');
                 ROLLBACK;
                 RETURN;
              END IF;
           END;
        ELSE
           v_crcode := 'DUMMY';
        END IF; */



      --    IF V_AC_CHRG IS NOT NULL
      --  THEN
      -------------------------
      IF V_TOTAL_STAMP_AMT IS NOT NULL
      THEN                                        -- IF COLLECTION HAVE CHARGE
         BEGIN
         
      
            STUTIL.dpr_insert_fetran (
               p_dblink     => p_dblink,
               p_brancd     => SUBSTR (V_ACTNUM, 1, 3),
               p_doctyp     => v_doctype2,
               p_docnum     => v_tnum,
               p_sernum     => 3,
               p_docdat     => p_AI_DOCDAT,
               p_valdat     => p_AI_DOCDAT,
               p_oprcod     => 'WDL',
               p_actype     => V_ACTYPE,
               p_actnum     => V_ACTNUM,
               p_curcde     => 'BDT',
               p_exrate     => 1,
               p_debcre     => 'D',
               p_dbamfc     => V_TOTAL_STAMP_AMT,                 --v_Com_crg,
               p_dbamlc     => V_TOTAL_STAMP_AMT,
               p_cramfc     => 0,
               p_cramlc     => 0,
               p_curbal     => 0,
               p_balflg     => 'Y',
               p_chgflg     => 'N',
               p_chqser     => NULL,
               p_chqnum     => NULL,
               p_chqdat     => NULL,
               p_trbrancd   => v_opr_brancd,
               p_tractype   => NULL,
               p_tractnum   => NULL,
               p_trchqser   => NULL,
               p_trchqnum   => NULL,
               p_trchqdat   => NULL,
               p_clrzon     => NULL,
               p_clrday     => NULL,
               p_prtflg     => 'N',
               p_glcode     => NULL,
               p_opbrancd   => p_branch_code,
               p_remark     =>    p_service_id
                               || ' '
                               || 'BILL COLLECTION-STAMP CHARGE DB.',
               p_yrprfx     => NULL,
               p_chgcde     => 'N',
               p_modcde     => 'ST',
               p_supid2     => p_app_user,                        --:APP_USER,
               p_drcode     => v_drcode,                         --'10100-01',
               p_crcode     => v_crcode,                         --'15700-01',
               p_oprstamp   => p_oprstamp,                     --v_opr_brancd,
               p_timstamp   => SYSTIMESTAMP,
               p_glflag     => 'Y',
               p_refno5     => NULL,
               p_errflg     => O_ERR_FLG,
               p_errmsg     => O_ERR_MSG);

            IF O_ERR_FLG IS NOT NULL
            THEN
               raise_application_error (
                  -20001,
                  O_ERR_FLG || '-' || O_ERR_MSG || 'E2');
            END IF;
         EXCEPTION
            WHEN OTHERS
            THEN
               raise_application_error (
                  -20001,
                  'ERROR: "dpr_insert_fetran1 -" ' || SQLERRM);
               ROLLBACK;
               RETURN;
         END;
          
   
         IF (SUBSTR (V_ACTNUM, 1, 3) <> v_opr_brancd)
         THEN
            BEGIN
               STUTIL.dpr_get_branch_glcode (
                  p_dblink   => p_dblink,
                  p_brancd   => SUBSTR (v_actnum, 1, 3),
                  p_glcode   => v_drcode,
                  p_errflg   => O_ERR_FLG,
                  p_errmsg   => O_ERR_MSG);

               IF O_ERR_FLG IS NOT NULL
               THEN
                  raise_application_error (
                     -20001,
                        'dpr_get_branch_glcode -'
                     || O_ERR_FLG
                     || '-'
                     || O_ERR_MSG);
                  ROLLBACK;
                  RETURN;
               END IF;
            END;
         ELSE
            v_drcode := 'DUMMY';
         END IF;
      END IF;
      
      
      

      BEGIN ---------------------------ChargeFee-----------------------------------
         IF V_TOTAL_STAMP_AMT IS NOT NULL
         THEN
           
     
            STUTIL.dpr_insert_fetran (
               p_dblink     => p_dblink,
               p_brancd     => v_opr_brancd,
               p_doctyp     => v_doctype2,
               p_docnum     => v_tnum,
               p_sernum     => 4,
               p_docdat     => p_AI_DOCDAT,
               p_valdat     => p_AI_DOCDAT,
               p_oprcod     => 'DEP',
               p_actype     => 'Z99',
               p_actnum     => v_opr_brancd || '00000099',
               p_curcde     => 'BDT',
               p_exrate     => 1,
               p_debcre     => 'C',
               p_dbamfc     => 0,
               p_dbamlc     => 0,
               p_cramfc     => V_TOTAL_STAMP_AMT,                 --v_Com_crg,
               p_cramlc     => V_TOTAL_STAMP_AMT,
               p_curbal     => 0,
               p_balflg     => 'Y',
               p_chgflg     => 'N',
               p_chqser     => NULL,
               p_chqnum     => NULL,
               p_chqdat     => NULL,
               p_trbrancd   => SUBSTR (v_actnum, 1, 3),
               p_tractype   => NULL,
               p_tractnum   => NULL,
               p_trchqser   => NULL,
               p_trchqnum   => NULL,
               p_trchqdat   => NULL,
               p_clrzon     => NULL,
               p_clrday     => NULL,
               p_prtflg     => 'N',
               p_glcode     => NULL,
               p_opbrancd   => p_branch_code,
               p_remark     =>    p_service_id
                               || ' '
                               || 'BILL COLLECTION-STAMP CHARGE CR.',
               p_yrprfx     => NULL,
               p_chgcde     => 'N',
               p_modcde     => 'ST',
               p_supid2     => p_app_user,
               p_drcode     => v_drcode,
               p_crcode     => '15700-01',
               p_oprstamp   => p_oprstamp,
               p_timstamp   => SYSTIMESTAMP,
               p_glflag     => 'Y',
               p_refno5     => NULL,
               p_errflg     => O_ERR_FLG,
               p_errmsg     => O_ERR_MSG);
         END IF;
         
         

         IF v_Com_crg IS NOT NULL AND v_Com_crg > 0
         THEN
            BEGIN
            
               STUTIL.dpr_insert_fetran (
                  p_dblink     => p_dblink,
                  p_brancd     => SUBSTR (V_ACTNUM, 1, 3), --v_depbranch, --:AI_BRANCH_CODE,
                  p_doctyp     => 'IT',
                  p_docnum     => v_tnum,
                  p_sernum     => 5,
                  p_docdat     => p_AI_DOCDAT,                   --:AI_DOCDAT,
                  p_valdat     => p_AI_DOCDAT,                   --:AI_DOCDAT,
                  p_oprcod     => 'WDL',                       ------v_oprcod,
                  p_actype     => V_ACTYPE,                          -- 'Z99',
                  p_actnum     => V_ACTNUM,       ---v_depbranch|| '00000099',
                  p_curcde     => 'BDT',
                  p_exrate     => 1,
                  p_debcre     => 'D',
                  p_dbamfc     => v_Com_crg,
                  p_dbamlc     => v_Com_crg,
                  p_cramfc     => 0,
                  p_cramlc     => 0,
                  p_curbal     => 0,
                  p_balflg     => 'Y',
                  p_chgflg     => 'N',
                  p_chqser     => NULL,
                  p_chqnum     => NULL,
                  p_chqdat     => NULL,
                  p_trbrancd   => v_opr_brancd,
                  p_tractype   => NULL,
                  p_tractnum   => NULL,
                  p_trchqser   => NULL,
                  p_trchqnum   => NULL,
                  p_trchqdat   => NULL,
                  p_clrzon     => NULL,
                  p_clrday     => NULL,
                  p_prtflg     => 'N',
                  p_glcode     => NULL,
                  p_opbrancd   => p_branch_code,
                  p_remark     =>    p_service_id
                                  || ' '
                                  || 'BILL COLLECTION-CHARGE DB.',
                  p_yrprfx     => NULL,
                  p_chgcde     => 'N',
                  p_modcde     => 'ST',
                  p_supid2     => p_app_user,
                  p_drcode     => v_drcode,
                  p_crcode     => '14100-01',
                  p_oprstamp   => p_oprstamp,
                  p_timstamp   => SYSTIMESTAMP,
                  p_glflag     => 'Y',
                  p_refno5     => NULL,
                  p_errflg     => O_ERR_FLG,
                  p_errmsg     => O_ERR_MSG);

               IF O_ERR_FLG IS NOT NULL
               THEN
                  raise_application_error (
                     -20001,
                     O_ERR_FLG || '-' || O_ERR_MSG || 'E2');
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  raise_application_error (
                     -20001,
                     'ERROR: "dpr_insert_fetran2 ---" ' || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;
             
         END IF;

               --raise_application_error(-20001,'test'||V_BRANCD_CRG||'-------sdsd'||O_ERR_MSG);
         IF v_vat_crg IS NOT NULL AND v_vat_crg > 0
         THEN
            BEGIN      -----------------------VATFee-------------------------D
               STUTIL.dpr_insert_fetran (
                  p_dblink     => p_dblink,
                  p_brancd     => SUBSTR (v_actnum, 1, 3),
                  p_doctyp     => 'IT',
                  p_docnum     => v_tnum,
                  p_sernum     => 6,
                  p_docdat     => p_AI_DOCDAT,
                  p_valdat     => p_AI_DOCDAT,
                  p_oprcod     => 'WDL',
                  p_actype     => v_actype,
                  p_actnum     => V_ACTNUM,
                  p_curcde     => 'BDT',
                  p_exrate     => 1,
                  p_debcre     => 'D',
                  p_dbamfc     => v_vat_crg,
                  p_dbamlc     => v_vat_crg,
                  p_cramfc     => 0,
                  p_cramlc     => 0,
                  p_curbal     => 0,
                  p_balflg     => 'Y',
                  p_chgflg     => 'N',
                  p_chqser     => NULL,
                  p_chqnum     => NULL,
                  p_chqdat     => NULL,
                  p_trbrancd   => v_opr_brancd,
                  p_tractype   => NULL,
                  p_tractnum   => NULL,
                  p_trchqser   => NULL,
                  p_trchqnum   => NULL,
                  p_trchqdat   => NULL,
                  p_clrzon     => NULL,
                  p_clrday     => NULL,
                  p_prtflg     => 'N',
                  p_glcode     => NULL,
                  p_opbrancd   => p_branch_code,
                  p_remark     =>    p_service_id
                                  || ' '
                                  || 'BILL COLLECTION-VAT DB.',
                  p_yrprfx     => NULL,
                  p_chgcde     => 'N',
                  p_modcde     => 'ST',
                  p_supid2     => p_app_user,
                  p_drcode     => v_drcode,
                  p_crcode     => '14100-01',
                  p_oprstamp   => p_oprstamp,
                  p_timstamp   => SYSTIMESTAMP,
                  p_glflag     => 'Y',
                  p_refno5     => NULL,
                  p_errflg     => O_ERR_FLG,
                  p_errmsg     => O_ERR_MSG);

               IF O_ERR_FLG IS NOT NULL
               THEN
                  raise_application_error (
                     -20001,
                     O_ERR_FLG || '-' || O_ERR_MSG || 'E3');
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  raise_application_error (
                     -20001,
                     'ERROR: "dpr_insert_fetran3 -" ' || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;
           
         END IF;


         BEGIN
            STUTIL.dpr_get_branch_glcode (
               p_dblink   => p_dblink,
               p_brancd   => SUBSTR (v_actnum, 1, 3),
               p_glcode   => Mv_drcode,
               p_errflg   => O_ERR_FLG,
               p_errmsg   => O_ERR_MSG);

            IF O_ERR_FLG IS NOT NULL
            THEN
               raise_application_error (-20001,
                                        O_ERR_FLG || '-' || O_ERR_MSG);

               ROLLBACK;
               RETURN;
            END IF;
            
         END;

         IF v_Com_crg IS NOT NULL AND v_Com_crg > 0
         THEN
            BEGIN                         -----------ChargeFee----------------
               STUTIL.dpr_insert_fetran (
                  p_dblink     => p_dblink,
                  p_brancd     => V_BRANCD_CRG,
                  p_doctyp     => 'IT',
                  p_docnum     => v_tnum,
                  p_sernum     => 7,
                  p_docdat     => p_AI_DOCDAT,
                  p_valdat     => p_AI_DOCDAT,
                  p_oprcod     => 'DEP',
                  p_actype     => 'Z99',
                  p_actnum     => V_BRANCD_CRG || '00000099',
                  p_curcde     => 'BDT',
                  p_exrate     => 1,
                  p_debcre     => 'C',
                  p_dbamfc     => 0,
                  p_dbamlc     => 0,
                  p_cramfc     => v_Com_crg,
                  p_cramlc     => v_Com_crg,
                  p_curbal     => 0,
                  p_balflg     => 'Y',
                  p_chgflg     => 'N',
                  p_chqser     => NULL,
                  p_chqnum     => NULL,
                  p_chqdat     => NULL,
                  p_trbrancd   => v_opr_brancd,
                  p_tractype   => NULL,
                  p_tractnum   => NULL,
                  p_trchqser   => NULL,
                  p_trchqnum   => NULL,
                  p_trchqdat   => NULL,
                  p_clrzon     => NULL,
                  p_clrday     => NULL,
                  p_prtflg     => 'N',
                  p_glcode     => NULL,
                  p_opbrancd   => p_branch_code,
                  p_remark     =>    p_service_id
                                  || ' '
                                  || 'BILL COLLECTION-CHARGE CR.',
                  p_yrprfx     => NULL,
                  p_chgcde     => 'N',
                  p_modcde     => 'ST',
                  p_supid2     => p_app_user,
                  p_drcode     => Mv_drcode,
                  p_crcode     => V_AC_CHRG,
                  p_oprstamp   => p_oprstamp,
                  p_timstamp   => SYSTIMESTAMP,
                  p_glflag     => 'Y',
                  p_refno5     => NULL,
                  p_errflg     => O_ERR_FLG,
                  p_errmsg     => O_ERR_MSG);

               IF O_ERR_FLG IS NOT NULL
               THEN
                  raise_application_error (
                     -20001,
                     O_ERR_FLG || '-' || O_ERR_MSG || 'E5');
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  raise_application_error (
                     -20001,
                     'ERROR: "dpr_insert_fetran4 -" ' || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;
            
            --raise_application_error (-20001,
              --                       'Error for ' || v_Com_crg ); 
         END IF;

         ----------vatfeee------
         IF v_vat_crg IS NOT NULL AND v_vat_crg > 0
         THEN
            BEGIN
               STUTIL.dpr_insert_fetran (
                  p_dblink     => p_dblink,
                  p_brancd     => V_VATBRAN,
                  p_doctyp     => 'IT',
                  p_docnum     => v_tnum,
                  p_sernum     => 8,
                  p_docdat     => p_AI_DOCDAT,
                  p_valdat     => p_AI_DOCDAT,
                  p_oprcod     => 'DEP',
                  p_actype     => 'Z99',
                  p_actnum     => V_VATBRAN || '00000099',
                  p_curcde     => 'BDT',
                  p_exrate     => 1,
                  p_debcre     => 'C',
                  p_dbamfc     => 0,
                  p_dbamlc     => 0,
                  p_cramfc     => v_vat_crg,
                  p_cramlc     => v_vat_crg,
                  p_curbal     => 0,
                  p_balflg     => 'Y',
                  p_chgflg     => 'N',
                  p_chqser     => NULL,
                  p_chqnum     => NULL,
                  p_chqdat     => NULL,
                  p_trbrancd   => v_opr_brancd,
                  p_tractype   => NULL,
                  p_tractnum   => NULL,
                  p_trchqser   => NULL,
                  p_trchqnum   => NULL,
                  p_trchqdat   => NULL,
                  p_clrzon     => NULL,
                  p_clrday     => NULL,
                  p_prtflg     => 'N',
                  p_glcode     => NULL,
                  p_opbrancd   => p_branch_code,
                  p_remark     =>    p_service_id
                                  || ' '
                                  || 'BILL COLLECTION-VAT CR.',
                  p_yrprfx     => NULL,
                  p_chgcde     => 'N',
                  p_modcde     => 'ST',
                  p_supid2     => p_app_user,
                  p_drcode     => Mv_drcode,
                  p_crcode     => V_VAT,
                  p_oprstamp   => p_oprstamp,
                  p_timstamp   => SYSTIMESTAMP,
                  p_glflag     => 'Y',
                  p_refno5     => NULL,
                  p_errflg     => O_ERR_FLG,
                  p_errmsg     => O_ERR_MSG);

               IF O_ERR_FLG IS NOT NULL
               THEN
                  raise_application_error (
                     -20001,
                     O_ERR_FLG || '-' || O_ERR_MSG || 'E6');
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  raise_application_error (
                     -20001,
                     'ERROR: "dpr_insert_fetran5 -" ' || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;
         END IF;

         IF O_ERR_FLG IS NOT NULL
         THEN
            raise_application_error (-20001,
                                     O_ERR_FLG || '-' || O_ERR_MSG || 'E5');
         ELSE
            BEGIN
               UPDATE STUTIL.STUTLINF
                  SET APPFLG = 'Y',
                      OPRSTAMP_APP = p_app_user,
                      TIMSTAMP_APP = SYSDATE,
                      DOCNUM = v_tnum,
                      DOCTYP = V_DOCTYPE,
                      DOCDATE = p_AI_DOCDAT
                WHERE     UPPER (SERVICE_ID) = UPPER (p_service_id)
                      AND OPBRANCD = p_opr_brancd
                      AND APPFLG = 'N'
                      AND UPPER (OPRSTAMP) = UPPER (p_oprstamp);

               IF SQL%NOTFOUND
               THEN
                  ROLLBACK;
                  RETURN;
                  raise_application_error (
                     -20001,
                     'You are not allowed to approve (C..)!');
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  raise_application_error (
                     -20001,
                     'STUTLINF Update Failed! ERROR: ' || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            raise_application_error (
               -20001,
               'ERROR: "dpr_insert_fetran3 -" ' || SQLERRM);
            ROLLBACK;
            RETURN;
      END;
   ELSE
      BEGIN
         IF p_branch_code = SUBSTR (V_ACTNUM, 1, 3)
         THEN
            V_DOCTYPE := 'CS';
            V_oprcod := 'DEP';
            v_doctype2 := 'DC';
         ELSE
            V_DOCTYPE := 'IC';
            V_oprcod := 'IB1';
            v_doctype2 := 'IT';
         END IF;
      END;

      BEGIN
         STUTIL.dpr_teller_limit_check (p_dblink       => p_dblink,
                                        p_brancd       => p_branch_code,
                                        p_appusr       => p_app_user,
                                        p_doctyp       => V_DOCTYPE,
                                        p_oprcod       => V_oprcod,
                                        p_actype       => V_ACTYPE,
                                        p_curcde       => 'BDT',
                                        p_debcre       => 'C',
                                        p_typcde       => 'TLR',
                                        p_lmtamt       => v_lmtamt,
                                        p_tlr_curcde   => o_curcde,
                                        p_errflg       => v_errflg,
                                        p_errmsg       => v_errmsg);

         IF v_errmsg IS NOT NULL
         THEN
            raise_application_error (-20003,
                                     p_branch_code || '/' || v_errmsg); ----Muhammad Abdul Qaium
            ROLLBACK;
            RETURN;
         END IF;
      END;

      IF v_errmsg IS NULL
      THEN
         ------------------------DOCUMENT GENERATION PROCESS--------------------------
         BEGIN
            STUTIL.dpr_docnumber_generation (p_dblink     => p_dblink, -----------> PASSING DBLINK FROM APPLICATION ITEM
                                             p_compcd     => p_branch_code,
                                             p_modlcd     => 'ST',
                                             p_doctyp     => V_DOCTYPE,
                                             p_subtyp     => 1,
                                             p_docdat     => SYSDATE,
                                             p_loccde     => NULL,
                                             p_origmodl   => 'ST',
                                             p_docnum     => v_tnum,
                                             p_errflag    => v_errflg,
                                             p_errmsg     => v_errmsg);

            IF v_errmsg IS NULL
            THEN
               v_tnum := p_branch_code || v_tnum;
               p_docnumber := v_tnum;
            ELSE
               raise_application_error (
                  -20001,
                     v_errflg
                  || '- '
                  || v_errmsg
                  || 'Docnum Generation Failed...!');
               ROLLBACK;
               RETURN;
            END IF;
         EXCEPTION
            WHEN OTHERS
            THEN
               raise_application_error (
                  -20001,
                     'Error Generating Docnumber - '
                  || v_tnum
                  || '. Error : '
                  || SQLERRM);
               ROLLBACK;
               RETURN;
         END;

         --------------------------END DOC PROCESS---------------------

         BEGIN
            STUTIL.dpr_complete_transaction (
               p_dblink        => p_dblink,
               p_brancd        => p_branch_code,
               p_tran_type     => 'REG',
               p_acbrancd      => SUBSTR (V_ACTNUM, 1, 3),
               p_oprcod        => V_oprcod,
               p_modday        => p_AI_DOCDAT,
               p_valdat        => p_AI_DOCDAT,
               p_actype        => V_ACTYPE,
               p_actnum        => V_ACTNUM,
               p_chqsrl        => NULL,
               p_chqnum        => NULL,
               p_chqdat        => NULL,
               p_loccur        => 'BDT',
               p_doctyp        => V_DOCTYPE,
               p_modcde        => 'ST',
               p_trbrancd      => p_branch_code,
               p_tractype      => NULL,
               p_tractnum      => NULL,
               p_trchqser      => NULL,
               p_trchqnum      => NULL,
               p_trchqdat      => NULL,
               p_appusr        => p_oprstamp,
               p_action        => 'STALLTRN',
               p_appflg        => 'Y',
               p_supid2        => p_app_user,
               p_amount        => v_amount,
               p_tinnum        => NULL,
               p_appque        => 'N',
               p_serlno        => 1,
               p_docnum        => v_tnum,
               p_acvalid_req   => 'Y',
               p_clrzon        => NULL,
               p_clrday        => NULL,
               p_glcode        => NULL,
               p_yrprfx        => NULL,
               p_chgcde        => 'N',
               p_typcde        => 'TLR',
               p_glflag        => 'Y',
               p_remarks       => p_service_id || ' ' || 'Bill Collection.',
               p_erritem       => v_erritem,
               p_errflg        => O_ERR_FLG,
               p_errmsg        => O_ERR_MSG);

            -- raise_application_error (-20001, 'p_brancd' || ' - ' || p_branch_code||'a/c' ||V_ACTNUM||'a/c TYPE'
            -- ||V_ACTYPE||'OPR---'||V_oprcod||'DOCTYPE--'||V_DOCTYPE||'APPUSER--'||p_oprstamp||'AMOUNT--'||v_amount);

            IF o_err_flg IS NOT NULL
            THEN
               raise_application_error (
                  -20001,
                     o_err_flg
                  || '-'
                  || o_err_msg
                  || 'Complete Transaction Error...!');
            END IF;
         EXCEPTION
            WHEN OTHERS
            THEN
               raise_application_error (
                  -20001,
                  'ERROR: "dpr_complete_transaction -" ' || SQLERRM);
               ROLLBACK;
               RETURN;
         END;
      END IF;

      IF O_ERR_MSG IS NULL
      THEN
         BEGIN
            UPDATE STUTIL.STUTLINF
               SET APPFLG = 'Y',
                   OPRSTAMP_APP = p_app_user,
                   TIMSTAMP_APP = SYSDATE,
                   DOCNUM = v_tnum,
                   DOCTYP = V_DOCTYPE
             WHERE     UPPER (SERVICE_ID) = UPPER (p_service_id)
                   AND OPBRANCD = v_opr_brancd                 --report brancd
                   AND OPBRANCD = p_branch_code                    --ai brancd
                   --   AND OPRSTAMP = p_oprstamp                 --report OPRSTAMP
                   --  AND OPRSTAMP <> p_app_user                    --ai OPRSTAMP
                   AND APPFLG = 'N';


            IF SQL%NOTFOUND
            THEN
               raise_application_error (
                  -20001,
                  'You are not allowed to approve (WC)...!');
               ROLLBACK;
               RETURN;
            END IF;
         EXCEPTION
            WHEN OTHERS
            THEN
               raise_application_error (
                  -20001,
                  'STUTLINF Update Failed! ERROR: ' || SQLERRM);
               ROLLBACK;
               RETURN;
         END;
      ELSE
         raise_application_error (-20001, 'ERROR-101 : ' || O_ERR_MSG);
         ROLLBACK;
         RETURN;
      END IF;
   END IF;

   GOTO ON_SUCCESS;

  <<ON_ERROR>>
   ROLLBACK;
   RAISE_APPLICATION_ERROR (
      -20001,
      'Flag: ' || pErrorFlag || ' Message: ' || pErrorMessage);

  <<ON_SUCCESS>>
   NULL;
END;
/
