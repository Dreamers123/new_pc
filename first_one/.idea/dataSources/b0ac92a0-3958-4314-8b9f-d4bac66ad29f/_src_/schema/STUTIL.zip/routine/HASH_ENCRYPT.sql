CREATE FUNCTION        "HASH_ENCRYPT" (p_pass IN VARCHAR2) RETURN RAW IS
 /*This Function is used to convert the data into "RAW" type */
  BEGIN
    --RETURN DBMS_CRYPTO.HASH(UTL_I18N.STRING_TO_RAW (p_pass, 'AL32UTF8'), DBMS_CRYPTO.HASH_MD5);
    RETURN UTL_I18N.STRING_TO_RAW (p_pass, 'AL32UTF8');
  END;
/
