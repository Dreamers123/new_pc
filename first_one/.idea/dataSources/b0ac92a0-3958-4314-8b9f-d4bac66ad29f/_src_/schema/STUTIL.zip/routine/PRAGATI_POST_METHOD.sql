CREATE PROCEDURE        pragati_post_method (
   customer_code   IN     VARCHAR2,
   p_json_get      IN     CLOB,
   pol_name        IN     VARCHAR2 DEFAULT NULL,
   p_TRANID        IN     VARCHAR2,
   app_user        IN     VARCHAR2,
   v_reqid            OUT NUMBER,
   no_sub             OUT NUMBER,
   receipt            OUT VARCHAR2,
   status             OUT VARCHAR2,
   org           OUT   VARCHAR2)
IS
   v_url             VARCHAR2 (200);
   l_response_text   CLOB;
   var2              VARCHAR2 (20);
   var3              VARCHAR2 (20);
   polnum            VARCHAR2 (100);
   holder            VARCHAR2 (100);
   total_due         NUMBER;
   orderid           VARCHAR2 (100);
   l_count           PLS_INTEGER;
   sJsonIndex        APEX_JSON.t_values;
BEGIN


   APEX_JSON.PARSE (sJsonIndex, p_json_get);

   l_count := APEX_JSON.get_count (p_path => '.', p_values => sJsonIndex);

   IF l_count = 1
   THEN
      FOR i IN 1 .. l_count
      LOOP
      
         total_due :=
            NVL (
               TO_NUMBER (
                  APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                          p_path     => '[%d].TOTAL_DUES',
                                          p0         => i)),
               0);
         orderid :=
            NVL (
               APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                       p_path     => '[%d].ORDERID',
                                       p0         => i),
               0);
         status := NVL (APEX_JSON.get_varchar2 (p_values   => sJsonIndex, 
                                                p_path     => '[%d].STATUS',
                                                p0         => i), 'NIL');
         IF total_due IS NULL OR total_due = '0'
         THEN
            raise_application_error (-20003, status);
         END IF;
      END LOOP;
   -----------------------End Parsing Single Data---------------------------------

   ELSE
      -----------------------Parsing Multiple Data---------------------------------
      FOR i IN 1 .. l_count
      LOOP
         holder :=
            APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                    p_path     => '[%d].NAME_OF_POLICYHOLDER',
                                    p0         => i);

         IF holder = pol_name
         THEN
            total_due :=
               NVL (
                  TO_NUMBER (
                     APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                             p_path     => '[%d].TOTAL_DUES',
                                             p0         => i)),
                  0);
            orderid :=
               NVL (
                  APEX_JSON.get_varchar2 (p_values   => sJsonIndex,
                                          p_path     => '[%d].ORDERID',
                                          p0         => i),
                  0);
            status := NVL (APEX_JSON.get_varchar2 (p_values   => sJsonIndex, 
                                                   p_path     => '[%d].STATUS', 
                                                   p0         => i), 'NIL');
            IF total_due IS NULL OR total_due = '0'
            THEN
               raise_application_error (-20003, status);
            END IF;
         END IF;
      END LOOP;
   END IF;

   DBMS_OUTPUT.put_line (p_json_get || total_due || orderid);
   -----------------------End Parsing Multiple Data---------------------------------

   /* if holder is null then
        raise_application_error(-20002, 'Could Not Get Proper Response From Pragati API !!!');
    end if ;*/
   v_url := 'http://plil.pragatilife.com/banktrans/mricipt/';
   apex_web_service.g_request_headers (1).name := 'Content-Type';
   apex_web_service.g_request_headers (1).VALUE :=
      'application/x-www-form-urlencoded';

   l_response_text :=
      apex_web_service.make_rest_request (
         p_url           => v_url,
         p_http_method   => 'POST',
         p_parm_name     => APEX_UTIL.string_to_table (
                              'marid:marpass:orderid:netrec'),
         p_parm_value    => APEX_UTIL.string_to_table (
                                 '000555'
                              || ':'
                              || '000555'
                              || ':'
                              || orderid
                              || ':'
                              || total_due));



   IF l_response_text IS NULL
   THEN
      raise_application_error (-20002, 'API calling Failed !!!');
   END IF;

   var3 := INSTR (l_response_text, ']');
   var2 := INSTR (l_response_text, '[');
   l_response_text := SUBSTR (l_response_text, var2 + 1, var3 - var2 - 1);
   DBMS_OUTPUT.put_line (var2);
   DBMS_OUTPUT.put_line (var3);
   DBMS_OUTPUT.put_line (l_response_text);

   APEX_JSON.PARSE (l_response_text);

   SELECT NVL (MAX (REQUESTID), 0) + 1
     INTO v_reqid
     FROM IN_OUT_JSON;

   INSERT INTO IN_OUT_JSON (REQUESTID,
                            REQUEST_name,
                            request,
                            JSON_RESPONSE,
                            in_time,
                            PAYMENT_ID,
                            OPRSTAMP,
                            TRANID)
        VALUES (v_reqid,
                'Pragati Premium Payment',
                v_url || 'Policy No.-' || customer_code,
                l_response_text,
                SYSDATE,
                NVL (APEX_JSON.get_varchar2 (p_path => 'RECEIPT_NO'), 'NIL'),
                app_user,
                p_TRANID);

   no_sub := TO_NUMBER (APEX_JSON.get_varchar2 (p_path => 'NO_OF_SUB'));
   
   

   IF no_sub = 2
   THEN
     
      receipt := NVL (APEX_JSON.get_varchar2 (p_path => 'RECEIPT_NO'), 'NIL');
      status := NVL (APEX_JSON.get_varchar2 (p_path => 'STATUS'), 'NIL');
      org := NVL (APEX_JSON.get_varchar2 (p_path => 'ORG_SETUP'), 0);
      
      UPDATE stutlinf 
      SET OUT_ID = receipt
      WHERE UPPER(SERVICE_ID)='PRAGATI'
      AND TRNID = p_TRANID 
      AND OPRSTAMP = app_user ;
      
      DBMS_OUTPUT.put_line (receipt || status || org);
   ELSIF no_sub = 3
   THEN
      polnum := NVL (apex_json.get_varchar2 (p_path => 'POLICY_NUMBER'), 0);
      status := NVL (APEX_JSON.get_varchar2 (p_path => 'STATUS'), 'NIL');
      raise_application_error (-20001, polnum || '  ' || status);
   ELSE
      status := NVL (APEX_JSON.get_varchar2 (p_path => 'STATUS'), 'NIL');
      raise_application_error (-20001, status);
   END IF;
END;
/
