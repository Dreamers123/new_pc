CREATE FUNCTION get_extraction_column_heading (
   p_service       IN VARCHAR2,
   p_data_type     IN VARCHAR2 DEFAULT NULL,
   p_column_name   IN NUMBER)
   RETURN VARCHAR2
IS
   CURSOR get_column_heading_c
   IS
      SELECT CPROMPT
        FROM STUTIL.STUTLPAR_DC
       WHERE SERVICE_ID = p_service AND COLUMNNM = p_column_name;

   v_column_name   STUTIL.STUTLPAR_DC.CPROMPT%TYPE;
BEGIN
   OPEN get_column_heading_c;

   FETCH get_column_heading_c INTO v_column_name;

   CLOSE get_column_heading_c;

   RETURN v_column_name;
END;
/
