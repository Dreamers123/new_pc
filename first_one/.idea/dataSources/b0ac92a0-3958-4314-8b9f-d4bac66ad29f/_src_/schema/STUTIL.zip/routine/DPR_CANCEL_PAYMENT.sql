CREATE PROCEDURE        dpr_Cancel_payment (
   p_paymentId      IN     NUMBER,
   p_invoiceNo      IN     VARCHAR2,
   p_customerCode   IN     VARCHAR2,                                  -- := 4,
   p_operator       IN     VARCHAR2,                          -- := 'sample2',
   p_reason         IN     VARCHAR2,                      -- := 'Test Cancel',
   o_errflg            OUT VARCHAR2,
   o_errmsg            OUT VARCHAR2)
IS
   l_param_list            VARCHAR2 (512);
   v_url                   VARCHAR2 (500);
   l_param_list_with_url   VARCHAR2 (512);
   l_http_request          UTL_HTTP.req;
   l_http_response         UTL_HTTP.resp;
   l_response_text         VARCHAR2 (32767);
   v_reqid                 NUMBER;
   v_status                NUMBER;
   v_message               VARCHAR2 (500);
   v_invoiceNo             VARCHAR2 (100);
   access_token            VARCHAR2 (500);
   v_errmge                VARCHAR2 (500);
   
   PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   -- service's input parameters

   UTL_HTTP.set_wallet ('file:/u01/app/oracle/product/12.1.0/db_1/wallets',
                        'master123'); --UTL_HTTP.set_wallet ('file:D:\wallets', 'master123');
   v_url := 'https://payments.titasgas.org.bd/metered/payment/cancel?';

   IF p_paymentId IS NULL
   THEN
      IF p_invoiceNo IS NULL
      THEN
         v_errmge := 'E090 Invoice Number is required. Please check.';
         GOTO exception_block;
      END IF;

      IF p_customerCode IS NULL
      THEN
         v_errmge := 'E090 Customer Code is required. Please check.';
         GOTO exception_block;
      END IF;
   END IF;

   BEGIN
      SELECT PARAVAL
        INTO access_token
        FROM stparamt
       WHERE TYPE = 'TGL' AND subtype = 'TKN';
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         v_errmge := 'E100 Token not found. Please generate token first.';
         GOTO exception_block;
   END;

   IF p_paymentId IS NOT NULL
   THEN
      IF p_paymentId IS NOT NULL
      THEN
         l_param_list_with_url :=
            l_param_list_with_url || 'paymentId=' || p_paymentId;
      END IF;

      IF p_operator IS NOT NULL
      THEN
         l_param_list_with_url :=
            l_param_list_with_url || '=' || p_operator;
      END IF;

      IF p_reason IS NOT NULL
      THEN
         l_param_list_with_url :=
            l_param_list_with_url || '=' || p_reason;
      END IF;
   END IF;


   IF p_invoiceNo IS NOT NULL AND p_paymentId IS NULL
   THEN
      IF p_invoiceNo IS NOT NULL
      THEN
         l_param_list_with_url :=
            l_param_list_with_url || 'invoiceNo=' || p_invoiceNo;
      END IF;

      IF p_customerCode IS NOT NULL
      THEN
         l_param_list_with_url :=
            l_param_list_with_url || '=' || p_customerCode;
      END IF;

      IF p_operator IS NOT NULL
      THEN
         l_param_list_with_url :=
            l_param_list_with_url || '=' || p_operator;
      END IF;

      IF p_reason IS NOT NULL
      THEN
         l_param_list_with_url :=
            l_param_list_with_url || '=' || p_reason;
      END IF;
   END IF;



   l_param_list := NULL;

   -- preparing Request...
   l_http_request :=
      UTL_HTTP.begin_request (v_url || l_param_list_with_url,
                              'POST',
                              'HTTP/1.1');

   -- 'https://payments.titasgas.org.bd/metered/payment/cancel?'

   UTL_HTTP.set_header (l_http_request,
                        'Authorization',
                        'Bearer ' || access_token);

   UTL_HTTP.set_header (l_http_request,
                        'Content-Type',
                        'application/x-www-form-urlencoded');

   -- ...set input parameters
   UTL_HTTP.write_text (l_http_request, l_param_list);

   -- get Response and obtain received value
   l_http_response := UTL_HTTP.get_response (l_http_request);


   UTL_HTTP.read_text (l_http_response, l_response_text);

   ---------------------------statr insert and parse json------------


   SELECT NVL (MAX (REQUESTID), 0) + 1 INTO v_reqid FROM IN_OUT_JSON;

   BEGIN
      INSERT INTO IN_OUT_JSON (REQUESTID,
                               REQUEST_name,
                               request,
                               JSON_RESPONSE,
                               in_time)
           VALUES (v_reqid,
                   'Cancel Payment',
                   v_url || l_param_list_with_url,
                   l_response_text,
                   SYSDATE);
   EXCEPTION
      WHEN OTHERS
      THEN
         v_errmge := 'E101 Unable to inster data into log table. ' || SQLERRM;
         GOTO exception_block;
   END;

   --- start Parsing -------------
   BEGIN
      SELECT js.JSON_RESPONSE.status, js.JSON_RESPONSE.MESSAGE
        INTO v_status, v_message
        FROM IN_OUT_JSON js
       WHERE js.REQUESTID = v_reqid;
   EXCEPTION
      WHEN OTHERS
      THEN
         v_errmge := 'E102 Unable to parse JSON data . ' || SQLERRM;
         GOTO exception_block;
   END;

   IF v_status = 200
   THEN
      UPDATE IN_OUT_JSON
         SET in_req_status = 'Success'
       WHERE REQUESTID = v_reqid;

      BEGIN
         SELECT js.JSON_RESPONSE.MESSAGE
           INTO v_message
           FROM IN_OUT_JSON js
          WHERE js.REQUESTID = v_reqid;
      EXCEPTION
         WHEN OTHERS
         THEN
            v_errmge := 'E103 Unable to parse JSON data . ' || SQLERRM;
            GOTO exception_block;
      END;
   ELSE
      UPDATE IN_OUT_JSON
         SET in_req_status = v_status || l_response_text
       WHERE REQUESTID = v_reqid;

      v_errmge :=
            v_status
         || ' '
         || v_message
         || ' . from Titas Gas server. Please contact with ICT dept.';
      GOTO exception_block;
   END IF;


   ------------------end parsing------------------------------

   DBMS_OUTPUT.put_line (l_response_text);
   GOTO successfull_block;

  ------------------end parsing------------------------------

  <<exception_block>>
   UTL_HTTP.end_response (l_http_response);
   o_errmsg := v_errmge;



  -- finalizing
  <<successfull_block>>
  commit;
   UTL_HTTP.end_response (l_http_response);
EXCEPTION
   WHEN UTL_HTTP.end_of_body
   THEN
      UTL_HTTP.end_response (l_http_response);
END;
/
