CREATE PROCEDURE aml_webservice (STUDENT_ID     IN     VARCHAR2,  --aml_webservice
                                 --O_XMLDATA      OUT CLOB,
                                 
                                 O_ERR_FLG      OUT VARCHAR2,
                                 O_ERR_MSG      OUT VARCHAR2)
   IS
      /* -------------------------------------------------------------
      /   Create by    : Kamrul Hasan Jahirul
      /   Create date  : 23/03/2015
      /   Purpose      : AML WEB Service
      /--------------------------------------------------------------- */

      HTTP_REQ       UTL_HTTP.REQ;

      HTTP_RESP      UTL_HTTP.RESP;

      REQUEST_ENV    CLOB;

      RESPONSE_ENV   CLOB;
      
      VAR VARCHAR2(500);
   BEGIN
      O_ERR_FLG := NULL; ---- SET DEFAULT to ensure no garbage value is passed
      O_ERR_MSG := NULL;

      REQUEST_ENV :=
            '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
      <soap:Body>
        <dataInsert xmlns="http://10.11.201.189:8084/PmsWebService">
          <ID>'
         || STUDENT_ID
         || '</ID>
        </dataInsert>
      </soap:Body>
    </soap:Envelope>';
    
    
    /*
    
          <sXml_Data><![CDATA['
         || PXMLDATA
         || ']]></sXml_Data>
          <sProcess_Type>'
         || P_TYPE
         || '</sProcess_Type>
    */

      HTTP_REQ :=
         UTL_HTTP.BEGIN_REQUEST (
            --   'http://10.11.1.217:8080/webserviceaml/services/DataInsertMain?wsdl',               ------  ( BA-LIVE )   AML WEB SERVICE
            --'http://10.11.201.231:8080/webserviceaml/services/DataInsertMain?wsdl',            ------   AML WEB SERVICE  ( ERA-TEST - RIKO-PC)
            'http://10.11.201.189:8084/PmsWebService/StudentInfo?wsdl', --- (BA-TEST 162)
            'POST',
            UTL_HTTP.HTTP_VERSION_1_1);
            
        VAR:=SQLERRM||'1' ;    

      UTL_HTTP.SET_HEADER (HTTP_REQ,
                           'Content-Type',
                           'text/xml; charset=utf-8');
      --  VAR:=SQLERRM||'2' ; 

      UTL_HTTP.SET_HEADER (HTTP_REQ, 'Content-Length', LENGTH (REQUEST_ENV));
     -- VAR:=SQLERRM||'3' ; 

      UTL_HTTP.SET_HEADER (HTTP_REQ, 'SOAPAction', '');
     -- VAR:=SQLERRM||'4' ; 
      UTL_HTTP.WRITE_TEXT (HTTP_REQ, REQUEST_ENV);
     -- VAR:=SQLERRM||'5' ; 
      HTTP_RESP := UTL_HTTP.GET_RESPONSE (HTTP_REQ);
     -- VAR:=SQLERRM||'6' ; 
      UTL_HTTP.READ_TEXT (HTTP_RESP, RESPONSE_ENV);
     -- VAR:=SQLERRM||'7' ; 
      
    --  O_XMLDATA :=TO_CLOB (RESPONSE_ENV) ;
          --  VAR:=SQLERRM||'8' ; 
           /* ,
              INSTR (TO_CLOB (RESPONSE_ENV), '<dataInsertReturn>')
            + LENGTH ('<dataInsertReturn>'),
              INSTR (TO_CLOB (RESPONSE_ENV), '</dataInsertReturn>')
            - INSTR (TO_CLOB (RESPONSE_ENV), '<dataInsertReturn>')
            - LENGTH ('<dataInsertReturn>'));

      O_XMLDATA := REPLACE (REPLACE (O_XMLDATA, '&lt;', '<'), '&gt;', '>');

      IF P_TYPE = 'ONS'
      THEN
         O_XMLDATA := SUBSTR (O_XMLDATA, INSTR (O_XMLDATA, '<TOKENS>'));
      ELSIF P_TYPE = 'STS'
      THEN
         O_XMLDATA := SUBSTR (O_XMLDATA, INSTR (O_XMLDATA, '<TOKENS_STS>'));
      END IF;  */

      UTL_HTTP.END_RESPONSE (HTTP_RESP);
      O_ERR_FLG := NULL;
      O_ERR_MSG := NULL;
   EXCEPTION
      WHEN UTL_HTTP.END_OF_BODY
      THEN
         O_ERR_FLG := 'E';
         O_ERR_MSG := 'UTL_HTTP.END_OF_BODY EXCEPTION-' || SQLERRM;
         UTL_HTTP.END_RESPONSE (HTTP_RESP);
      WHEN OTHERS
      THEN
         O_ERR_FLG := 'E';
         O_ERR_MSG := VAR||'--'||
          SQLERRM;
   END;
/
