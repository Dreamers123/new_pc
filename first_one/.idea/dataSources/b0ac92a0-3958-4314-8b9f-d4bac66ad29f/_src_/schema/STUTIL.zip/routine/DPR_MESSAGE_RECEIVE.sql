CREATE PROCEDURE        dpr_message_receive (
   pMobileNo             VARCHAR2,
   pMessageContent       VARCHAR2,
   pCategoryId           PLS_INTEGER,
   pAccountNo            VARCHAR2,
   pCustomerNo           VARCHAR2,
   pAmount               NUMBER,
   pRefNo                VARCHAR2,
   pInitiatorId          PLS_INTEGER,
   pGenerateTime         DATE DEFAULT SYSDATE,
   pReferenceNo      OUT VARCHAR2,
   pStatus           OUT VARCHAR2,
   pMessage          OUT VARCHAR2)
IS
   vChannelId       PLS_INTEGER;
   vPriorityValue   PLS_INTEGER;
   vLifeTime        PLS_INTEGER;
   v_operator       PLS_INTEGER;
   vSmsSize         NUMBER;
   vMyException     EXCEPTION;
   v_seq            NUMBER := SMS_ID_SEQ.NEXTVAL;
   vInitiatorId     PLS_INTEGER;
   vThreadId        PLS_INTEGER;

   PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   pStatus := 'S';


   ---- calculate LIFE_TIME , CHANNEL_ID,  PRIORITY_VALUE  as per SMS_CATEGORY  instruction
   --- If everything is OK save data in SMS_DATA table and return  pReferenceNo , pStatus ,pMessage  with proper value
   BEGIN
      SELECT PRIORITY_VALUE, LIFE_TIME
        INTO vPriorityValue, vLifeTime
        FROM SMS_CATEGORY
       WHERE CATEGORY_ID = pCategoryId;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         pMessage := 'Invalid SMS Category.';
         RAISE vMyException;
      WHEN TOO_MANY_ROWS
      THEN
         pMessage := 'Duplicate Category Found.';
         RAISE vMyException;
      WHEN OTHERS
      THEN
         pMessage := 'SMS catagory Finding Problem.' || SQLERRM;
         RAISE vMyException;
   END;

   BEGIN
      SELECT OPERATOR_ID
        INTO v_operator
        FROM SMS_SENDING_RULE
       WHERE     CATEGORY_ID = pCategoryId
             AND OPERATOR_ID =
                    (SELECT OPERATOR_ID
                       FROM sms_operator
                      WHERE OPERATOR_SHCODE = SUBSTR (pMobileNo, 1, 3));
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         v_operator := 0;
   --RAISE vMyException;
   END;

   IF v_operator = '0'
   THEN
      BEGIN
         SELECT CHANNEL_ID
           INTO vChannelId
           FROM SMS_SENDING_RULE
          WHERE CATEGORY_ID = pCategoryId;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            pMessage := 'Invalid SMS Category & Operator.';
            RAISE vMyException;
         WHEN TOO_MANY_ROWS
         THEN
            pMessage := 'Duplicate Category & Operator Found.';
            RAISE vMyException;
         WHEN OTHERS
         THEN
            pMessage := 'SMS catagory Finding Problem.' || SQLERRM;
            RAISE vMyException;
      END;
   ELSE
      BEGIN
         SELECT CHANNEL_ID
           INTO vChannelId
           FROM SMS_SENDING_RULE
          WHERE     CATEGORY_ID = pCategoryId
                AND OPERATOR_ID =
                       (SELECT OPERATOR_ID
                          FROM sms_operator
                         WHERE OPERATOR_SHCODE = SUBSTR (pMobileNo, 1, 3)); /*Added For Distinct Channel 15/12/2016*/
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            pMessage := 'Invalid SMS Category & Operator.';
            RAISE vMyException;
         WHEN TOO_MANY_ROWS
         THEN
            pMessage := 'Duplicate Category & Operator Found.';
            RAISE vMyException;
         WHEN OTHERS
         THEN
            pMessage := 'SMS catagory Finding Problem.' || SQLERRM;
            RAISE vMyException;
      END;



      BEGIN
         SELECT SMS_SIZE
           INTO vSmsSize
           FROM sms_channel
          WHERE CHANNEL_ID = vChannelId;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            pMessage := 'Invalid Channel.';
            RAISE vMyException;
         WHEN TOO_MANY_ROWS
         THEN
            pMessage := 'Duplicate Channel Found.';
            RAISE vMyException;
         WHEN OTHERS
         THEN
            pMessage := 'SMS Channel Finding Problem.' || SQLERRM;
            RAISE vMyException;
      END;
   END IF;

   IF TRIM (pMobileNo) IS NULL                          /* check mobile no  */
   THEN
      pMessage := 'Mobile number cannot be blank. ';
      RAISE vMyException;
   ELSIF TRIM (pMobileNo) IS NOT NULL
   THEN
      IF LENGTH (REPLACE (TRIM (pMobileNo), '+88', '')) < 11
      THEN
         pMessage := 'Invalid Mobile No.';
         RAISE vMyException;
      END IF;
   END IF;



   IF TRIM (pMessageContent) IS NULL
   THEN
      pMessage := 'SMS must have some value. ';
      RAISE vMyException;
   END IF;


   IF pInitiatorId IS NULL                        /* pInitiatorId validity  */
   THEN
      pMessage := 'Initiator must have some value. ';
      RAISE vMyException;
   END IF;

   BEGIN
      SELECT INI_ID
        INTO vInitiatorId
        FROM SMS_INITIATOR
       WHERE INI_KEY = pInitiatorId;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         pMessage := 'Invalid Initiator ID.';
         RAISE vMyException;
      WHEN TOO_MANY_ROWS
      THEN
         pMessage := 'Duplicate Initiator Found.';
         RAISE vMyException;
      WHEN OTHERS
      THEN
         pMessage := 'Initiator Finding Problem.' || SQLERRM;
         RAISE vMyException;
   END;


   IF pCategoryId IS NULL                         /* Check valid Category ID*/
   THEN
      pMessage := 'Catagory ID must have some value. ';
      RAISE vMyException;
   END IF;


   IF LENGTH (pMessageContent) > vSmsSize /* Message content length as per SMS_CATEGORY table sms_size*/
   THEN
      pMessage := 'SMS exceeds the maximum size. ';
      RAISE vMyException;
   END IF;

   SELECT MOD (TO_CHAR (SYSDATE, 'ss') * 2, 5) + 1
     INTO vThreadId
     FROM DUAL;


   BEGIN
      INSERT INTO SMS_DATA (SMS_ID,
                            MOBILE_NO,
                            SMS_CONTENT,
                            CATEGORY_ID,
                            ACCOUNT_NO,
                            CUSTOMER_NO,
                            AMOUNT,
                            REF_NO,
                            INI_ID,
                            LIFE_TIME,
                            CHANNEL_ID,
                            PRIORITY_VALUE,
                            THREAD_ID,
                            GENERATE_TIME)
           VALUES (v_seq,
                   TRIM (pMobileNo),
                   TRIM (pMessageContent),
                   pCategoryId,
                   pAccountNo,
                   pCustomerNo,
                   pAmount,
                   pRefNo,
                   vInitiatorId,
                   vLifeTime,
                   vChannelId,
                   vPriorityValue,
                   vThreadId,
                   pGenerateTime);
   EXCEPTION
      WHEN OTHERS
      THEN
         pMessage := 'Cannot insert value. ' || SQLERRM;
         RAISE vMyException;
   END;

   pMessage := 'Successfully Done.';
   pReferenceNo := v_seq;
   COMMIT;
EXCEPTION
   WHEN vMyException
   THEN
      pStatus := 'E';
      ROLLBACK;
END;
/
