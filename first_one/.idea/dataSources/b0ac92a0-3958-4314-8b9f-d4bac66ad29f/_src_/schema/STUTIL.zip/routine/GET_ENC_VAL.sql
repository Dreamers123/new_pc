CREATE FUNCTION        GET_ENC_VAL (p_value    IN VARCHAR2, p_key   IN RAW) RETURN RAW
IS
   l_enc_val   RAW (2000);
   l_mod       NUMBER
      :=   DBMS_CRYPTO.encrypt_aes256
         + DBMS_CRYPTO.chain_ecb
         + DBMS_CRYPTO.pad_pkcs5;
BEGIN

   l_enc_val :=
      DBMS_CRYPTO.encrypt (UTL_I18N.string_to_raw (p_value, 'AL32UTF8'),
                           l_mod,
                           p_key);
   RETURN l_enc_val;
END;
/
