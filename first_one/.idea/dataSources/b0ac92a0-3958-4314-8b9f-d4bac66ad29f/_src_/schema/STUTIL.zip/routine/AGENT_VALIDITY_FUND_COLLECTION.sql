CREATE PROCEDURE        Agent_validity_fund_collection (
   p_SessionId          VARCHAR2,
   p_UserId             VARCHAR2,
   p_LogId              NUMBER,
   p_CreditAcType       VARCHAR2,
   p_Actnum             VARCHAR2,
   p_CreditAcNo         VARCHAR2,
   p_Amount             NUMBER,
   p_CompanyName        VARCHAR2 DEFAULT NULL,
   o_DocNo          OUT VARCHAR2,
   o_DocDate        OUT DATE,
   o_ErrorFlag      OUT VARCHAR2,
   o_ErrorMessage   OUT VARCHAR2,
   o_UserName       OUT VARCHAR2,
   o_MobileNo       OUT VARCHAR2,
   o_AgentAcNo      OUT VARCHAR2)
IS
   vEmail          VARCHAR2 (100);
   vAgentId        NUMBER;
   vValidityFlag   VARCHAR2 (100);
   vPointName      VARCHAR2 (100);
   vDistrictName   VARCHAR2 (100);
   vUpazilaName    VARCHAR2 (100);
   vUnionName      VARCHAR2 (100);
BEGIN
   EMOB.COMPANY_COLLECTION_NEW.USER_VALIDITY@utility_to_agent (
      pSessionId         => p_SessionId,
      pUserId            => UPPER (p_UserId),
      pLogId             => p_LogId,
      pBrowserUniqueId   => NULL,
      pUserName          => o_UserName,
      pMobileNo          => o_MobileNo,
      pEmail             => vEmail,
      pAgentId           => vAgentId,
      pAgentAcNo         => o_AgentAcNo,
      pValidityFlag      => vValidityFlag,
      pPointName         => vPointName,
      pDistrictName      => vDistrictName,
      pUpazilaName       => vUpazilaName,
      pUnionName         => vUnionName,
      pErrorMessage      => o_ErrorMessage);


   IF vValidityFlag = 'Y'
   THEN
      ROLLBACK;
      raise_application_error (-20001, 'ABS Error - ' || o_ErrorMessage);
   ELSIF vValidityFlag = 'N'
   THEN
      IF p_Actnum IS NULL
      THEN
         ROLLBACK;
         raise_application_error (-20001, 'Agent, A/C No. Not Be Blank.');
      END IF;

      BEGIN
         EMOB.COMPANY_COLLECTION_NEW.FUND_COLLECTION@utility_to_agent (
            pPaymentType         => 'CS',
            pCustomerAccountNo   => NULL,
            pRunUser             => p_UserId,
            pCreditAcType        => p_CreditAcType,
            pCreditAcNo          => p_CreditAcNo,
            pLogId               => p_LogId,
            pAmount              => p_Amount,
            pSessionId           => p_SessionId,
            pCompanyName         => p_CompanyName,
            pDocNo               => o_DocNo,
            pDocDate             => o_DocDate,
            pErrorFlag           => o_ErrorFlag,
            pErrorMessage        => o_ErrorMessage);
      EXCEPTION
         WHEN OTHERS
         THEN
            raise_application_error (
               -20001,
               'ABS Process Calling Problem. - ' || SQLERRM);
      END;
   END IF;

   IF o_ErrorFlag = 'Y'
   THEN
      ROLLBACK;
      raise_application_error (-20001, 'ABS error - ' || o_ErrorMessage);
   END IF;

   IF o_DocNo IS NULL
   THEN
      ROLLBACK;
      raise_application_error (-20001, 'ABS DOC No. can''t Be Blank.');
   END IF;
END;
/
