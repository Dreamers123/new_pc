CREATE PROCEDURE        Dynamic_Comm_distribution_ABS (
   p_dblink              IN     VARCHAR2,
   p_oprbrancd           IN     VARCHAR2,
   p_oprtamp             IN     VARCHAR2,
   p_tot_charge_amt      IN     NUMBER,
   p_tot_crg_amt_agent   IN     NUMBER,
   p_tot_crg_amt_abs     IN     NUMBER,
   p_branch_code         IN     VARCHAR2,                         ---AI_BRANCH
   p_app_user            IN     VARCHAR2,
   p_agent_ac_no         IN     VARCHAR2,
   p_service_id          IN     VARCHAR2,
   p_AI_DOCDAT           IN     DATE,
   p_form_date           IN     DATE,
   p_to_date             IN     DATE,
   p_docnumber              OUT VARCHAR2,
   pErrorFlag               OUT VARCHAR2,
   pErrorMessage            OUT VARCHAR2)
IS
   v_row            NUMBER := 0;
   v_tnum           VARCHAR2 (50) := NULL;
   v_erritem        VARCHAR2 (50) := NULL;
   O_ERR_FLG        VARCHAR2 (5) := NULL;
   O_ERR_MSG        VARCHAR2 (4000) := NULL;
   v_crcode         VARCHAR2 (10) := NULL;
   v_drcode         VARCHAR2 (10) := NULL;
   V_ACTYPE         VARCHAR2 (20);
   V_ACTNUM         VARCHAR2 (30);
   V_ENCACTNUM      VARCHAR2 (100);
   V_DOCTYPE        VARCHAR2 (5);
   v_doctype2       VARCHAR2 (3) := NULL;
   V_oprcod         VARCHAR2 (50);
   v_errflg         VARCHAR2 (10) := NULL;
   vErrorFlag       VARCHAR2 (1) := NULL;
   vErrorMessage    VARCHAR2 (1024) := NULL;
   v_errmsg         VARCHAR2 (1024) := NULL;
   v_crgamt         NUMBER := 0;
   o_curcde         VARCHAR2 (50);
   vSLNODAY         NUMBER := 0;
   V_PARKINGGL      VARCHAR2 (30);
   V_CHRG_PAYABLE   VARCHAR2 (30);
   V_CHRG_INCOME    VARCHAR2 (30);
   v_channel        VARCHAR2 (200);
   V_VAT            VARCHAR2 (30);
   Mv_drcode        VARCHAR2 (50);
   v_GL             VARCHAR2 (2);
   V_branch         VARCHAR2 (3);

   V_BRANCD_CRG     VARCHAR2 (5);
   V_ACTYPE_CRG     VARCHAR2 (5);
   V_AC_CHRG        VARCHAR2 (10);


   vCORPORATE_COM   NUMBER := 0;
   vERA_COM         NUMBER := 0;
   vCbsDocNo        VARCHAR2 (13);
   vDocNo           VARCHAR2 (20);
   vDocDate         DATE;
BEGIN
   BEGIN           -------------DYNAMIN A/C TYPE / A/C NUM--------------------
      SELECT SUBSTR (A.SERVICE_PRO_ACC_NO, 1, 3),
             A.SERVICE_PRO_ACC_NO,
             B.ACTYPE
        INTO V_branch, V_ACTYPE, V_ACTNUM
        FROM STUTIL.SERVICE_PRO_INFO A, STLBAS.STFACMAS@STUTLTOCBS B
       WHERE     B.ACTNUM = A.SERVICE_PRO_ACC_NO
             AND B.BRANCD = SUBSTR (A.SERVICE_PRO_ACC_NO, 1, 3)
             AND B.ACSTAT NOT IN ('CLS', 'TRF')
             AND UPPER (A.SERVICE_ID) = UPPER (p_service_id);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
        
         pErrorFlag := 'E';
         pErrorMessage := 'E1- Failed to get Destination A/c Information  ';
     raise_application_error ( -20001,pErrorFlag||'Error Mes:'||pErrorMessage);
      -- GOTO ON_ERROR;
      WHEN OTHERS
      THEN
         pErrorFlag := 'E';
         pErrorMessage :=
            'E2- Failed to get Destination A/c Information. Ref :' || SQLERRM;
          raise_application_error ( -20001,pErrorFlag||'Error Mes:'||pErrorMessage);    
   -- GOTO ON_ERROR;
   END;



   BEGIN                                        ------------CHARGEGL----------
      SELECT ACTNUM, CHRINGL
        INTO V_CHRG_PAYABLE, V_CHRG_INCOME
        FROM STCHINFO
       WHERE UPPER (SERVICENO) = UPPER (p_service_id);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         raise_application_error (
            -20001,
            'Destination A/cInformation Not Found in STCHINFO');
      WHEN OTHERS
      THEN
         raise_application_error (
            -20001,
            'Error Getting Destination A/c Information-ERROR:' || SQLERRM);
   END;



   BEGIN
      ----------------------------------------DOC_TYPEASSIGN--------------------------------------
      BEGIN
         IF p_branch_code = SUBSTR (V_ACTNUM, 1, 3)
         THEN
            V_DOCTYPE := 'CS';
            V_oprcod := 'DEP';
            v_doctype2 := 'DC';
         ELSE
            V_DOCTYPE := 'IC';
            V_oprcod := 'IB1';
            v_doctype2 := 'IT';
         END IF;
      END;

      --------------------------------------TellerLimitCheck---------------------------------



      ----------------------------DOCUMENTGENERATIONPROCESS--------------------------
      BEGIN
         dpr_docnumber_generation (p_dblink     => p_dblink, ----------->PASSINGDBLINKFROMAPPLICATIONITEM
                                   p_compcd     => p_branch_code,
                                   p_modlcd     => 'ST',
                                   p_doctyp     => V_DOCTYPE,
                                   p_subtyp     => 1,
                                   p_docdat     => SYSDATE,
                                   p_loccde     => NULL,
                                   p_origmodl   => 'ST',
                                   p_docnum     => v_tnum,
                                   p_errflag    => v_errflg,
                                   p_errmsg     => v_errmsg);

         IF v_errmsg IS NULL
         THEN
            v_tnum := p_branch_code || v_tnum;
            p_docnumber := v_tnum;
         ELSE
            raise_application_error (-20001, v_errflg || '-' || v_errmsg);
            ROLLBACK;
            RETURN;
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            raise_application_error (
               -20001,
                  'Error Generating Docnumber-'
               || v_tnum
               || '.Error:'
               || SQLERRM);
            ROLLBACK;
            RETURN;
      END;

      IF (SUBSTR (v_actnum, 1, 3) <> p_oprbrancd) -----------------Getbranchglcode
      THEN
         BEGIN
            stutil.dpr_get_branch_glcode (p_dblink   => p_dblink,
                                          p_brancd   => p_oprbrancd,
                                          p_glcode   => v_crcode,
                                          p_errflg   => O_ERR_FLG,
                                          p_errmsg   => O_ERR_MSG);

            IF O_ERR_FLG IS NOT NULL
            THEN
               raise_application_error (-20001,
                                        O_ERR_FLG || '-' || O_ERR_MSG);
               ROLLBACK;
               RETURN;
            END IF;
         END;
      ELSE
         v_crcode := 'DUMMY';
      END IF;

      BEGIN -----------------------Charge for ABS Commision-------------------------
         dpr_insert_fetran (
            p_dblink     => p_dblink,
            p_brancd     => '100', -- SUBSTR (v_actnum, 1, 3),          --p_branch_code,
            p_doctyp     => v_doctype2,
            p_docnum     => v_tnum,
            p_sernum     => 1,
            p_docdat     => p_AI_DOCDAT,
            p_valdat     => p_AI_DOCDAT,
            p_oprcod     => 'WDL',
            p_actype     => 'Z99',
            p_actnum     => '10000000099',        --p_branch_code||'00000099',
            p_curcde     => 'BDT',
            p_exrate     => 1,
            p_debcre     => 'D',                                       -------
            p_dbamfc     => p_tot_crg_amt_abs,
            --------0,
            p_dbamlc     => p_tot_crg_amt_abs,
            --------0,
            p_cramfc     => 0, -------TO_NUMBER(APEX_APPLICATION.G_F09(v_row),'999G999G999G999G990D00'),
            p_cramlc     => 0, -------TO_NUMBER(APEX_APPLICATION.G_F09(v_row),'999G999G999G999G990D00'),
            p_curbal     => 0,
            p_balflg     => 'Y',
            p_chgflg     => 'N',
            p_chqser     => NULL,
            p_chqnum     => NULL,
            p_chqdat     => NULL,
            p_trbrancd   => p_oprbrancd,                                 --085
            p_tractype   => NULL,                               ---v_depactyp,
            p_tractnum   => NULL,                                ---v_depacno,
            p_trchqser   => NULL,
            p_trchqnum   => NULL,
            p_trchqdat   => NULL,
            p_clrzon     => NULL,
            p_clrday     => NULL,
            p_prtflg     => 'N',
            p_glcode     => NULL,
            p_opbrancd   => p_branch_code,                               --085
            p_remark     => 'Pragati Premium COLLECTION-CHARGE FEE',
            p_yrprfx     => NULL,
            p_chgcde     => 'N',
            p_modcde     => 'ST',
            p_supid2     => p_app_user,
            p_drcode     => V_CHRG_PAYABLE,                      --'10100-01',
            p_crcode     => v_crcode, --V_CHRG_INCOME, --'14100-01', --v_crcode,                      --'15700-01',
            p_oprstamp   => p_oprtamp,
            p_timstamp   => SYSTIMESTAMP,
            p_glflag     => 'Y',
            p_refno5     => NULL,
            p_errflg     => O_ERR_FLG,
            p_errmsg     => O_ERR_MSG);

         IF O_ERR_FLG IS NOT NULL
         THEN
            raise_application_error (-20001,
                                     O_ERR_FLG || '-' || O_ERR_MSG || '--E1');
         END IF;
      END;



      BEGIN
         stutil.dpr_get_branch_glcode (p_dblink   => p_dblink,
                                       p_brancd   => p_oprbrancd,
                                       p_glcode   => Mv_drcode,
                                       p_errflg   => O_ERR_FLG,
                                       p_errmsg   => O_ERR_MSG);

         IF O_ERR_FLG IS NOT NULL
         THEN
            raise_application_error (-20001, O_ERR_FLG || '-' || O_ERR_MSG);
            ROLLBACK;
            RETURN;
         END IF;
      END;

      BEGIN ---------------------------Charge Fee for Agent user------------------------------------
         dpr_insert_fetran (
            p_dblink     => p_dblink,
            p_brancd     => '100',
            p_doctyp     => 'IT',
            p_docnum     => v_tnum,
            p_sernum     => 2,
            p_docdat     => p_AI_DOCDAT,
            p_valdat     => p_AI_DOCDAT,
            p_oprcod     => 'WDL',
            p_actype     => 'Z99',
            p_actnum     => '10000000099',
            p_curcde     => 'BDT',
            p_exrate     => 1,
            p_debcre     => 'D',
            p_dbamfc     => p_tot_crg_amt_agent,
            p_dbamlc     => p_tot_crg_amt_agent,
            p_cramfc     => 0,
            p_cramlc     => 0,
            p_curbal     => 0,
            p_balflg     => 'Y',
            p_chgflg     => 'N',
            p_chqser     => NULL,
            p_chqnum     => NULL,
            p_chqdat     => NULL,
            p_trbrancd   => p_oprbrancd,
            p_tractype   => NULL,                               ---v_depactyp,
            p_tractnum   => NULL,                                ---v_depacno,
            p_trchqser   => NULL,
            p_trchqnum   => NULL,
            p_trchqdat   => NULL,
            p_clrzon     => NULL,
            p_clrday     => NULL,
            p_prtflg     => 'N',
            p_glcode     => NULL,
            p_opbrancd   => p_branch_code,
            p_remark     => 'Pragati Premium COLLECTION-CHARGE FEE',
            p_yrprfx     => NULL,
            p_chgcde     => 'N',
            p_modcde     => 'ST',
            p_supid2     => p_app_user,
            p_drcode     => V_CHRG_PAYABLE,                      --'10100-01',
            p_crcode     => Mv_drcode,                           --'10100-01',
            p_oprstamp   => p_oprtamp,
            p_timstamp   => SYSTIMESTAMP,
            p_glflag     => 'Y',
            p_refno5     => NULL,
            p_errflg     => O_ERR_FLG,
            p_errmsg     => O_ERR_MSG);

         IF O_ERR_FLG IS NOT NULL
         THEN
            raise_application_error (-20001,
                                     O_ERR_FLG || '-' || O_ERR_MSG || 'E2');
         END IF;
      END;

      ---raise_application_error (-20001,'TEST');

      BEGIN
         BEGIN
         
          --raise_application_error (-20001, p_app_user||'--'||p_branch_code||'--'||p_tot_crg_amt_agent||'--'||p_tot_crg_amt_abs||'--'||p_docnumber||'--'||p_agent_ac_no);
                                
            EMOB.COMPANY_COLLECTION.COMMISSION_BROADCASTING@utility_to_agent (
               pStelarUser             => p_app_user,
               pStelarLoginBranch      => p_branch_code,
               pDebitBranch            => '100',                   --V_branch,
               pTotalAgentCommAmount   => p_tot_crg_amt_agent,
               pTotalStampAmount       => 0,
               pTotalBankCommAmount    => p_tot_crg_amt_abs,
               pCbsDocNo               => p_docnumber,
               pAgentAcNo              => p_agent_ac_no,
               pCompanyName            => 'PRAGATI',
               pErrorFlag              => vErrorFlag,
               pErrorMessage           => vErrorMessage);
         EXCEPTION
            WHEN OTHERS
            THEN
               raise_application_error (
                  -20001,
                  'ABS Process Calling Problem A2. - ' || SQLERRM);
         END;

         IF vErrorFlag = 'Y'
         THEN
            raise_application_error (-20001, 'ABS' || vErrorMessage || 'A2');
         END IF;
      END;
   END;


   IF O_ERR_MSG IS NULL
   THEN
      --raise_application_error (-20001,'TEST');
      BEGIN                               -------Update STUTLINF Table--------
         UPDATE STUTLINF
            SET COMFLAG = 'Y',
                COMDOCNUM = v_tnum,
                COMDATE = SYSDATE,
                COMMMISIONBY = p_app_user
          WHERE     OPBRANCD = p_oprbrancd
                AND APPFLG = 'Y'
                AND COMFLAG = 'N'
                AND OPRSTAMP_REJ IS NULL
                AND TRUNC (TIMSTAMP_APP) BETWEEN p_form_date AND p_to_date;
      EXCEPTION
         WHEN OTHERS
         THEN
            raise_application_error (
               -20001,
               p_oprbrancd || 'Can not Update STUTLINF' || SQLERRM);
      END;
   ELSE
      raise_application_error (-20001, O_ERR_MSG);
      ROLLBACK;
      RETURN;
   END IF;
END;
/
