CREATE FUNCTION        CheckService (
   p_branch          IN VARCHAR2,
   p_usercode        IN VARCHAR2,
   p_module          IN VARCHAR2,
   p_serviceid       IN VARCHAR2,
   p_serv_category   IN VARCHAR2)
   RETURN BOOLEAN
IS
   v_cnt       NUMBER := 0;
   v_servcat   NUMBER := 0;
BEGIN

--RAISE_APPLICATION_ERROR(-20001,'p_branch-'||p_branch||'-p_usercode-'||p_usercode||'-p_module-'||p_module);
   SELECT COUNT (1)
     INTO v_cnt
     FROM syusrprev
    WHERE     UPPER (USERID) = p_usercode
          AND UPPER (MODULECODE) = UPPER (p_module)
          AND SERVISEID = NVL (p_serviceid, SERVISEID)
          AND SERVISEID IN (SELECT SID
                              FROM STUTIL.SERVICEMST
                             WHERE SCATEGORY = p_serv_category);

   IF ( (v_cnt = 0) OR (p_branch IS NULL))
   THEN
      RETURN FALSE;
   ELSE
      SELECT COUNT (1)
        INTO v_servcat
        FROM STUTIL.SERVICEMST
       WHERE SID = NVL (p_serviceid, SID) AND SCATEGORY = p_serv_category;

      IF v_servcat = 0
      THEN
         RETURN FALSE;
      ELSE
         RETURN TRUE;
      END IF;
   END IF;
END;
/
