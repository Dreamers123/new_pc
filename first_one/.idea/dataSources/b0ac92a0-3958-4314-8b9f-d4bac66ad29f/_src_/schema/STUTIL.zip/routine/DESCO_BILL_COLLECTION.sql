CREATE PROCEDURE        DESCO_BILL_COLLECTION (
   p_dblink            IN     VARCHAR2,
   p_oprbrancd         IN     VARCHAR2,
   p_oprtamp           IN     VARCHAR2,
   p_tot_amount        IN     NUMBER,
   p_vat_amount        IN     NUMBER,
   p_security_amount   IN     NUMBER,
   p_material_amount   IN     NUMBER,
   p_stamp_amount      IN     NUMBER,
   p_branch_code       IN     VARCHAR2,
   p_app_user          IN     VARCHAR2,
   p_AI_DOCDAT         IN     DATE,
   p_service_id        IN     VARCHAR2,
   p_docnumber            OUT VARCHAR2,
   pErrorFlag             OUT VARCHAR2,
   pErrorMessage          OUT VARCHAR2)
IS
   oprstamp       VARCHAR2 (6);
   Mv_drcode      VARCHAR2 (20);
   v_tnum         VARCHAR2 (50) := NULL;
   v_erritem      VARCHAR2 (50) := NULL;
   O_ERR_FLG      VARCHAR2 (5) := NULL;
   O_ERR_MSG      VARCHAR2 (4000) := NULL;
   V_ACTYPE       VARCHAR2 (20);
   V_ACTNUM       VARCHAR2 (30);
   V_DOCTYPE      VARCHAR2 (5);
   V_oprcod       VARCHAR2 (50);
   v_errflg       VARCHAR2 (10) := NULL;
   V_VAT          VARCHAR2 (20) := 0;
   V_VATBRAN      VARCHAR2 (5);
   v_errmsg       VARCHAR2 (5000) := NULL;
   v_lmtamt       NUMBER := 0;
   o_curcde       VARCHAR2 (50);
   v_vat_crg      NUMBER := 0;
   V_AC_CHRG      VARCHAR2 (20) := 0;
   V_BRANCD_CRG   VARCHAR2 (5);
   V_ACTYPE_CRG   VARCHAR2 (5) := 0;
   v_Com_crg      NUMBER := 0;
   v_drcode       VARCHAR2 (10) := NULL;
   v_crcode       VARCHAR2 (10) := NULL;
   v_doctype2     VARCHAR2 (3) := NULL;

   --vr_brancd  varchar2(5);
   -- vr_cur     varchar2(10);
   tr_brancd      VARCHAR2 (5);

   vt_actype      VARCHAR2 (3);
   vt_actnum      VARCHAR2 (15);
   -- v_curbal     NUMBER(16,3) := 0;
   vt_brancd      VARCHAR2 (3);
   vt_cur         VARCHAR2 (3);
   tv_brancd      VARCHAR2 (5);
   vt_doctyp      VARCHAR2 (10);
   vt_oprcod      VARCHAR2 (10);


   vr_actype      VARCHAR2 (3);
   vr_actnum      VARCHAR2 (15);
   vr_brancd      VARCHAR2 (3);
   vr_cur         VARCHAR2 (3);
   vr_glcode      VARCHAR2 (10);
   v_doctyp       VARCHAR2 (10);


   vm_actype      VARCHAR2 (3);
   vm_actnum      VARCHAR2 (15);
   vm_brancd      VARCHAR2 (3);
   vm_cur         VARCHAR2 (3);
   vm_doctyp      VARCHAR2 (10);

   vs_actype      VARCHAR2 (3);
   vs_actnum      VARCHAR2 (15);
   vs_brancd      VARCHAR2 (3);
   vs_cur         VARCHAR2 (3);
   vs_doctyp      VARCHAR2 (10);

   V_OPRCOD1      VARCHAR2 (10);
BEGIN
   -------------DYNAMIN A/C TYPE / A/C NUM--------------------
   BEGIN
      SELECT SUBTYPE,
             SUBSTR (paraval, 1, 3) brancd,
             paraval actnum,
             curcde
        INTO V_ACTYPE,
             vr_brancd,
             V_ACTNUM,
             vr_cur
        FROM stparamt
       WHERE TYPE = 'DCR';
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         raise_application_error (-20001,
                                  'Parameter data not found. ' || SQLERRM);
   END;

   BEGIN
      IF p_branch_code = SUBSTR (V_ACTNUM, 1, 3)
      THEN
         V_DOCTYPE := 'CS';
         V_oprcod := 'DEP';
         v_doctype2 := 'DC';
         tr_brancd := NULL;
      ELSE
         V_DOCTYPE := 'IC';
         V_oprcod := 'IB1';
         v_doctype2 := 'IT';
         tr_brancd := vr_brancd;
      END IF;
   END;

   -------------Teller Limit------------

   BEGIN
      dpr_teller_limit_check (p_dblink       => p_dblink,
                              p_brancd       => p_branch_code,
                              p_appusr       => p_app_user,       --:APP_USER,
                              p_doctyp       => V_DOCTYPE,
                              p_oprcod       => V_oprcod,
                              p_actype       => V_ACTYPE,
                              p_curcde       => 'BDT',
                              p_debcre       => 'C',
                              p_typcde       => 'TLR',
                              p_lmtamt       => v_lmtamt,
                              p_tlr_curcde   => o_curcde,
                              p_errflg       => v_errflg,
                              p_errmsg       => v_errmsg);

      IF v_errmsg IS NOT NULL
      THEN
         raise_application_error (-20003, p_branch_code || '/' || v_errmsg); ----Muhammad Abdul Qaium

         ROLLBACK;
         RETURN;
      END IF;
   END;

   ---------end teller--------
   IF v_errmsg IS NULL
   THEN
      -------------DOCUMENT GENERATION PROCESS-------------
      BEGIN
         dpr_docnumber_generation (p_dblink     => p_dblink, -----------> PASSING DBLINK FROM APPLICATION ITEM
                                   p_compcd     => p_branch_code,
                                   p_modlcd     => 'ST',
                                   p_doctyp     => V_DOCTYPE,
                                   p_subtyp     => 1,
                                   p_docdat     => SYSDATE,
                                   p_loccde     => NULL,
                                   p_origmodl   => 'ST',
                                   p_docnum     => v_tnum,
                                   p_errflag    => v_errflg,
                                   p_errmsg     => v_errmsg);

         IF v_errmsg IS NULL
         THEN
            v_tnum := p_branch_code || v_tnum;
         ELSE
            raise_application_error (-20001,
                                     v_errflg || '- ' || v_errmsg || '!!!');
            ROLLBACK;
            RETURN;
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            raise_application_error (
               -20001,
                  'Error Generating Docnumber - '
               || v_tnum
               || '. Error : '
               || SQLERRM);
            ROLLBACK;
            RETURN;
      END;

      -------------------------END DOC PROCESS---------------------
      BEGIN
         dpr_complete_transaction (
            p_dblink        => p_dblink,
            p_brancd        => p_branch_code,               --:AI_BRANCH_CODE,
            p_tran_type     => 'REG',
            p_acbrancd      => SUBSTR (V_ACTNUM, 1, 3),         ---BRANCH CODE
            p_oprcod        => V_oprcod,
            p_modday        => p_AI_DOCDAT,                      --:AI_DOCDAT,
            p_valdat        => p_AI_DOCDAT,                      --:AI_DOCDAT,
            p_actype        => V_ACTYPE,                              --ACTYPE
            p_actnum        => V_ACTNUM,                         ---ACT NUMBER
            p_chqsrl        => NULL,
            p_chqnum        => NULL,
            p_chqdat        => NULL,
            p_loccur        => 'BDT',
            p_doctyp        => V_DOCTYPE,                           --DOC TYPE
            p_modcde        => 'ST',
            p_trbrancd      => p_branch_code,  --:AI_BRANCH_CODE,            -
            p_tractype      => NULL,
            p_tractnum      => NULL,
            p_trchqser      => NULL,
            p_trchqnum      => NULL,
            p_trchqdat      => NULL,
            p_appusr        => p_oprtamp,
            p_action        => 'STALLTRN',
            p_appflg        => 'Y',
            p_supid2        => p_app_user,                        --:APP_USER,
            p_amount        => p_tot_amount,
            p_tinnum        => NULL,
            p_appque        => 'N',
            p_serlno        => 1,
            p_docnum        => v_tnum,
            p_acvalid_req   => 'Y',
            p_clrzon        => NULL,
            p_clrday        => NULL,
            p_glcode        => NULL,
            p_yrprfx        => NULL,
            p_chgcde        => 'N',
            p_typcde        => 'TLR',
            p_glflag        => 'Y',
            p_remarks       => p_service_id || ' ' || 'Bill Collection.',
            p_erritem       => v_erritem,
            p_errflg        => O_ERR_FLG,
            p_errmsg        => O_ERR_MSG);

         p_docnumber := v_tnum;

         -- raise_application_error (-20001, 'p_brancd' || ' - ' || p_branch_code||'a/c' ||V_ACTNUM||'a/c TYPE'
         -- ||V_ACTYPE||'OPR---'||V_oprcod||'DOCTYPE--'||V_DOCTYPE||'APPUSER--'||p_oprtamp||'AMOUNT--'||p_tot_amount);
         -- raise_application_error (-20001,  p_branch_code||'--'||SUBSTR(V_ACTNUM,1, 3)) ;
         IF o_err_flg IS NOT NULL
         THEN
            raise_application_error (-20001,
                                     o_err_flg || '-' || o_err_msg || '!!!');
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            raise_application_error (
               -20001,
               'ERROR: "dpr_complete_transaction -" ' || SQLERRM);
            ROLLBACK;
            RETURN;
      END;

      --VAT INSERT INTO CBS
      IF p_vat_amount > 0
      THEN
         BEGIN
            SELECT SUBTYPE,
                   SUBSTR (paraval, 1, 3) brancd,
                   paraval actnum,
                   curcde
              INTO vt_actype,
                   vt_brancd,
                   vt_actnum,
                   vt_cur
              FROM stparamt
             WHERE TYPE = 'DCV';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               raise_application_error (
                  -20001,
                  'Vat GL not found in STCHINFO table.');
         END;

         IF p_branch_code = vt_brancd
         THEN
            vt_doctyp := 'CS';
            vt_oprcod := 'DEP';
            tv_brancd := NULL;
         ELSE
            vt_doctyp := 'IC';
            vt_oprcod := 'IB1';
            tv_brancd := vt_brancd;
         END IF;

         BEGIN
            dpr_teller_limit_check (p_dblink       => p_dblink,
                                    p_brancd       => p_branch_code,
                                    p_appusr       => p_app_user, --:APP_USER,
                                    p_doctyp       => vt_doctyp,
                                    p_oprcod       => vt_oprcod,
                                    p_actype       => vt_actype,
                                    p_curcde       => 'BDT',
                                    p_debcre       => 'C',
                                    p_typcde       => 'TLR',
                                    p_lmtamt       => v_lmtamt,
                                    p_tlr_curcde   => o_curcde,
                                    p_errflg       => v_errflg,
                                    p_errmsg       => v_errmsg);

            IF v_errmsg IS NOT NULL
            THEN
               raise_application_error (-20003,
                                        p_branch_code || '/' || v_errmsg);
               ROLLBACK;
               RETURN;
            END IF;
         END;

         --  raise_application_error (-20003, vt_actnum || '/' || v_errmsg);
         BEGIN
            dpr_complete_transaction (
               p_dblink        => p_dblink,
               p_brancd        => p_branch_code,            --:AI_BRANCH_CODE,
               p_tran_type     => 'REG',
               p_acbrancd      => vt_brancd,                    ---BRANCH CODE
               p_oprcod        => V_oprcod,
               p_modday        => p_AI_DOCDAT,                   --:AI_DOCDAT,
               p_valdat        => p_AI_DOCDAT,                   --:AI_DOCDAT,
               p_actype        => vt_actype,                          --ACTYPE
               p_actnum        => vt_actnum,                       --AC NUMBER
               p_chqsrl        => NULL,
               p_chqnum        => NULL,
               p_chqdat        => NULL,
               p_loccur        => 'BDT',
               p_doctyp        => vt_doctyp,                        --DOC TYPE
               p_modcde        => 'ST',
               p_trbrancd      => p_branch_code,            --:AI_BRANCH_CODE,
               p_tractype      => NULL,
               p_tractnum      => NULL,
               p_trchqser      => NULL,
               p_trchqnum      => NULL,
               p_trchqdat      => NULL,
               p_appusr        => p_oprtamp,
               p_action        => 'STALLTRN',
               p_appflg        => 'Y',
               p_supid2        => p_app_user,
               p_amount        => p_vat_amount,                   --Vat Amount
               p_tinnum        => NULL,
               p_appque        => 'N',
               p_serlno        => 3,
               p_docnum        => v_tnum,
               p_acvalid_req   => 'Y',
               p_clrzon        => NULL,
               p_clrday        => NULL,
               p_glcode        => NULL,
               p_yrprfx        => NULL,
               p_chgcde        => 'N',
               p_typcde        => 'TLR',
               p_glflag        => 'Y',
               p_remarks       =>    'Vat For '
                                  || p_service_id
                                  || ' '
                                  || 'Bill Collection.',
               p_erritem       => v_erritem,
               p_errflg        => O_ERR_FLG,
               p_errmsg        => O_ERR_MSG);


            IF o_err_flg IS NOT NULL
            THEN
               raise_application_error (
                  -20001,
                  o_err_flg || '-' || o_err_msg || '!!!');
            END IF;
         EXCEPTION
            WHEN OTHERS
            THEN
               raise_application_error (
                  -20001,
                  'ERROR: "dpr_complete_transaction for vat -" ' || SQLERRM);
               ROLLBACK;
               RETURN;
         END;
      END IF;

      --FPR_INSERT_STFETRAN_SECURITY

      IF p_security_amount > 0
      THEN
         BEGIN
            SELECT SUBTYPE,
                   SUBSTR (paraval, 1, 3) brancd,
                   paraval actnum,
                   curcde
              INTO vr_actype,
                   vr_brancd,
                   vr_actnum,
                   vr_cur
              FROM stparamt
             WHERE TYPE = 'DSD';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               raise_application_error (-20001,
                                        'Security Parameter data not found.');
         END;

         IF p_branch_code = vr_brancd
         THEN
            v_doctyp := 'CS';
            v_oprcod := 'DEP';
            tr_brancd := NULL;
         ELSE
            v_doctyp := 'IC';
            v_oprcod := 'IB1';
            tr_brancd := vr_brancd;
         END IF;

         BEGIN
            dpr_complete_transaction (
               p_dblink        => p_dblink,
               p_brancd        => p_branch_code,            --:AI_BRANCH_CODE,
               p_tran_type     => 'REG',
               p_acbrancd      => vr_brancd,                 ---AC BRANCH CODE
               p_oprcod        => V_oprcod,
               p_modday        => p_AI_DOCDAT,                   --:AI_DOCDAT,
               p_valdat        => p_AI_DOCDAT,                   --:AI_DOCDAT,
               p_actype        => vr_actype,                          --ACTYPE
               p_actnum        => vr_actnum,                     ---ACT NUMBER
               p_chqsrl        => NULL,
               p_chqnum        => NULL,
               p_chqdat        => NULL,
               p_loccur        => 'BDT',
               p_doctyp        => v_doctyp,                         --DOC TYPE
               p_modcde        => 'ST',
               p_trbrancd      => p_branch_code,            --:AI_BRANCH_CODE,
               p_tractype      => NULL,
               p_tractnum      => NULL,
               p_trchqser      => NULL,
               p_trchqnum      => NULL,
               p_trchqdat      => NULL,
               p_appusr        => p_oprtamp,
               p_action        => 'STALLTRN',
               p_appflg        => 'Y',
               p_supid2        => p_app_user,
               p_amount        => p_security_amount,         --Security amount
               p_tinnum        => NULL,
               p_appque        => 'N',
               p_serlno        => 5,
               p_docnum        => v_tnum,
               p_acvalid_req   => 'Y',
               p_clrzon        => NULL,
               p_clrday        => NULL,
               p_glcode        => NULL,
               p_yrprfx        => NULL,
               p_chgcde        => 'N',
               p_typcde        => 'TLR',
               p_glflag        => 'Y',
               p_remarks       =>    'Security For '
                                  || p_service_id
                                  || ' '
                                  || 'Bill Collection.',
               p_erritem       => v_erritem,
               p_errflg        => O_ERR_FLG,
               p_errmsg        => O_ERR_MSG);


            IF o_err_flg IS NOT NULL
            THEN
               raise_application_error (
                  -20001,
                  o_err_flg || '-' || o_err_msg || '!!!');
            END IF;
         EXCEPTION
            WHEN OTHERS
            THEN
               raise_application_error (
                  -20001,
                     'ERROR: "dpr_complete_transaction for Security -" '
                  || SQLERRM);
               ROLLBACK;
               RETURN;
         END;
      END IF;

      --FPR_INSERT_STFETRAN_MATERIAL* (Procedure Body)

      IF p_material_amount > 0
      THEN
         BEGIN
            SELECT SUBTYPE,
                   SUBSTR (paraval, 1, 3) brancd,
                   paraval actnum,
                   curcde
              INTO vm_actype,
                   vm_brancd,
                   vm_actnum,
                   vm_cur
              FROM stparamt
             WHERE TYPE = 'DMS';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               raise_application_error (-20001, 'Parameter data not found.');
         END;


         IF p_branch_code = vm_brancd
         THEN
            vm_doctyp := 'CS';
            v_oprcod := 'DEP';
            tr_brancd := NULL;
         ELSE
            vm_doctyp := 'IC';
            v_oprcod := 'IB1';
            tr_brancd := vm_brancd;
         END IF;


         BEGIN
            dpr_complete_transaction (
               p_dblink        => p_dblink,
               p_brancd        => p_branch_code,            --:AI_BRANCH_CODE,
               p_tran_type     => 'REG',
               p_acbrancd      => vm_brancd, --SUBSTR (V_ACTNUM, 1, 3),         ---BRANCH CODE
               p_oprcod        => V_oprcod,
               p_modday        => p_AI_DOCDAT,                   --:AI_DOCDAT,
               p_valdat        => p_AI_DOCDAT,                   --:AI_DOCDAT,
               p_actype        => vm_actype,                          --ACTYPE
               p_actnum        => vm_actnum,                     ---ACT NUMBER
               p_chqsrl        => NULL,
               p_chqnum        => NULL,
               p_chqdat        => NULL,
               p_loccur        => 'BDT',
               p_doctyp        => vm_doctyp,                        --DOC TYPE
               p_modcde        => 'ST',
               p_trbrancd      => p_branch_code, --:AI_BRANCH_CODE,            -
               p_tractype      => NULL,
               p_tractnum      => NULL,
               p_trchqser      => NULL,
               p_trchqnum      => NULL,
               p_trchqdat      => NULL,
               p_appusr        => p_oprtamp,
               p_action        => 'STALLTRN',
               p_appflg        => 'Y',
               p_supid2        => p_app_user,
               p_amount        => p_material_amount,         --Matarial amount
               p_tinnum        => NULL,
               p_appque        => 'N',
               p_serlno        => 7,
               p_docnum        => v_tnum,
               p_acvalid_req   => 'Y',
               p_clrzon        => NULL,
               p_clrday        => NULL,
               p_glcode        => NULL,
               p_yrprfx        => NULL,
               p_chgcde        => 'N',
               p_typcde        => 'TLR',
               p_glflag        => 'Y',
               p_remarks       =>    'Material For '
                                  || p_service_id
                                  || ' '
                                  || 'Bill Collection.',
               p_erritem       => v_erritem,
               p_errflg        => O_ERR_FLG,
               p_errmsg        => O_ERR_MSG);


            IF o_err_flg IS NOT NULL
            THEN
               raise_application_error (
                  -20001,
                  o_err_flg || '-' || o_err_msg || '!!!');
            END IF;
         EXCEPTION
            WHEN OTHERS
            THEN
               raise_application_error (
                  -20001,
                     'ERROR: "dpr_complete_transaction for MATERIAL -" '
                  || SQLERRM);
               ROLLBACK;
               RETURN;
         END;
      END IF;

      --fpr_insert_stfetran_stamp
     IF p_stamp_amount > 0
      THEN
         BEGIN
            SELECT SUBTYPE,
                   SUBSTR (paraval, 1, 3) brancd,
                   paraval actnum,
                   curcde
              INTO vs_actype,
                   vs_brancd,
                   vs_actnum,
                   vs_cur
              FROM stparamt
             WHERE TYPE = 'DCR';
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               raise_application_error (-20001,
                                        'Stamp Parameter data not found.');
         END;


         IF p_branch_code = vs_brancd
         THEN
            vs_doctyp := 'CS';
            v_oprcod := 'WDL';
            --tr_brancd := NULL;
            V_OPRCOD1 := 'DEP';
         ELSE
            vs_doctyp := 'IC';
            v_oprcod := 'IB3';
            tr_brancd := vs_brancd;
            V_OPRCOD1 := 'IB1';
         END IF;

         BEGIN
            dpr_insert_fetran (p_dblink     => p_dblink,
                               p_brancd     => p_branch_code,
                               p_doctyp     => vs_doctyp,
                               p_docnum     => v_tnum,
                               p_sernum     => 10,
                               p_docdat     => p_AI_DOCDAT,
                               p_valdat     => p_AI_DOCDAT,
                               p_oprcod     => V_OPRCOD1,
                               p_actype     => 'Z99',             
                               p_actnum     => p_branch_code || '00000099', 
                               p_curcde     => 'BDT',
                               p_exrate     => 1,
                               p_debcre     => 'C',
                               p_dbamfc     => 0,
                               p_dbamlc     => 0,
                               p_cramfc     => p_stamp_amount,
                               p_cramlc     => p_stamp_amount,
                               p_curbal     => 0,
                               p_balflg     => 'Y',
                               p_chgflg     => 'N',
                               p_chqser     => NULL,
                               p_chqnum     => NULL,
                               p_chqdat     => NULL,
                               p_trbrancd   => p_branch_code,
                               p_tractype   => NULL,
                               p_tractnum   => NULL,
                               p_trchqser   => NULL,
                               p_trchqnum   => NULL,
                               p_trchqdat   => NULL,
                               p_clrzon     => NULL,
                               p_clrday     => NULL,
                               p_prtflg     => 'N',
                               p_glcode     => NULL,
                               p_opbrancd   => p_branch_code,
                               p_remark     => 'DESCO STAMP Charge',
                               p_yrprfx     => NULL,
                               p_chgcde     => 'N',
                               p_modcde     => 'ST',
                               p_supid2     => p_app_user,
                               p_drcode     => '10100-01', --v_drcode,  -- *******************
                               p_crcode     => '15700-01', --v_crcode, -- ********************
                               p_oprstamp   => p_app_user,
                               p_timstamp   => SYSTIMESTAMP,
                               p_glflag     => 'Y',
                               p_refno5     => NULL,
                               p_errflg     => O_ERR_FLG,
                               p_errmsg     => O_ERR_MSG);


            IF o_err_flg IS NOT NULL
            THEN
               raise_application_error (
                  -20001,
                  o_err_flg || '-' || o_err_msg || '!!!');
            END IF;
         EXCEPTION
            WHEN OTHERS
            THEN
               raise_application_error (
                  -20001,
                  'ERROR: "dpr_complete_transaction for Stamp -" ' || SQLERRM);
               ROLLBACK;
               RETURN;
         END;
      END IF; 
   --------IF other charge is available then  Condition--------
   END IF;
END;
/
