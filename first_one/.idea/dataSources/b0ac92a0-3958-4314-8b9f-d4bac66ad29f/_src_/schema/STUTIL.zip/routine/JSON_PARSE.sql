CREATE PROCEDURE JSON_PARSE( POLICY_NUMBER OUT  VARCHAR2,
                                        NAME_OF_POLICYHOLDER OUT VARCHAR2)
IS
l_json_text VARCHAR2(32767);
BEGIN
 l_json_text := '{ 
      "POLICY_NUMBER":"040100281-1",
      "NAME_OF_POLICYHOLDER":"MR.MD.SAMIM AHMED",
      "DUE_DATE":"27-DEC-16",
      "PRM_INSTALLMENT":"1521",
      "N_DUE":"3",
      "TOT_INST":"4563",
      "LATE_FEE":"420",
      "SUSPENSE":"0",
      "TOTAL_DUES":"4983",
      "STATUS":"DGH Requerd",
      "ORDERID":"plil00006217",
      "NO_OF_SUB":"1"
   }';

 APEX_JSON.parse(l_json_text);
 POLICY_NUMBER :=  APEX_JSON.get_varchar2(p_path => 'POLICY_NUMBER');
 NAME_OF_POLICYHOLDER := APEX_JSON.get_number(p_path => 'NAME_OF_POLICYHOLDER');
 DBMS_OUTPUT.PUT_LINE(POLICY_NUMBER);
 
 IF l_json_text IS NULL THEN
    RAISE_APPLICATION_ERROR(-20001,'API could not get JSON data');
 END IF;
END JSON_PARSE;
/
