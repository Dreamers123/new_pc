CREATE FUNCTION        charge_calculate (p_primum IN NUMBER,
                                             p_charg_per  IN NUMBER,
                                             p_vat_per IN NUMBER)
   RETURN NUMBER
IS

   temp         NUMBER;
   charge_out   NUMBER;
BEGIN


 --  P = 100000 / (1 +.02 + .02 * .15) = 97751.71 
   
   temp := p_primum / (1 + p_charg_per + p_charg_per * p_vat_per);
   charge_out := temp * p_charg_per;

   RETURN ROUND (charge_out, 2);

   
END;
/
