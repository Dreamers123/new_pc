CREATE PROCEDURE        AKASH_POST_METHOD (
   BEXCOMID      IN     VARCHAR2,
   MOBILE_NUMBER IN     VARCHAR2,
   AMOUNT        IN     VARCHAR2 )
 IS
 v_reqid         VARCHAR2 (20);
 L_TEXT   VARCHAR2 (1000);
 PAYMENT_ID VARCHAR2 (50);
 APP_USER      VARCHAR2(20);
 BEGIN
 L_TEXT  := '{
    "data": {
        "posted_on": "2019-12-08T08:15:24",
        "number": "68808",
        "payment_amount": 100,
        "issued_on": "2019-12-08T08:15:23",
        "life_cycle_state": "POSTED",
        "reference_number": "68810",
        "payment_method": {
            "alternative_code": "AB",
            "name": "Agent Banking",
            "description": null,
            "id": "2356A1CBCFDC44F3B7943206C9510DC1"
        }
    },
    "status": {
        "code": "OK",
        "description": "",
        "message": ""
    }
}';
SELECT NVL (MAX (REQUESTID), 0) + 1
     INTO v_reqid
     FROM IN_OUT_JSON;
APEX_JSON.PARSE (L_TEXT);
--V_REQID:=APEX_JSON.get_varchar2 (p_path => 'data.number');
PAYMENT_ID:=APEX_JSON.get_varchar2(p_path=>'data.payment_method.id');
INSERT INTO IN_OUT_JSON  (REQUESTID,
                          REQUEST_NAME,request,PAYMENT_ID,IN_TIME,OPRSTAMP,json_response
                         )
                         VALUES (v_reqid,
                       'AKASH PAYMENT','https://pr2.crm.com/crmapi/rest/v2/payments/create',
                PAYMENT_ID,SYSDATE,app_user,L_TEXT
               );
 
END AKASH_POST_METHOD;
/
