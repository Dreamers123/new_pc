CREATE procedure        BURO_JSON_RC(l_json_text in clob,
                                                 P_APP_USER IN VARCHAR)
as 
l_count PLS_INTEGER;
begin
    APEX_JSON.PARSE(l_json_text);
    --DBMS_OUTPUT.put_line('----------------------------------------');
    --DBMS_OUTPUT.put_line('Branch  Code  : ' || APEX_JSON.get_varchar2(p_path => 'BranchCode'));
    --DBMS_OUTPUT.put_line('Transaction Start Date  : ' || APEX_JSON.get_date(p_path => 'TransStartDate',p_format => 'YYYY-MM-DD'));
    --DBMS_OUTPUT.put_line('Transaction End Date  : ' || APEX_JSON.get_date(p_path => 'TransEndDate',p_format => 'YYYY-MM-DD'));

    l_count := APEX_JSON.get_count(p_path => 'transactionList');

    --apex_json.open_array('transactionList');
    
    DELETE STBUROPC_RC WHERE OPRSTAMP = P_APP_USER ;
    FOR i IN 1 .. l_count LOOP
        
        --DBMS_OUTPUT.put_line('Transaction Number : ' || l_array.stringify());
        insert into STBUROPC_RC(TRANID,OPBRANCD,OPRSTAMP,TRANSTARTDAT,TRANENDDAT)
                    values( APEX_JSON.get_varchar2(p_path => 'transactionList[%d]', p0 => i),
                         APEX_JSON.get_varchar2(p_path => 'BranchCode'),P_APP_USER,
                         APEX_JSON.get_date(p_path => 'TransStartDate',p_format => 'YYYY-MM-DD'),
                          APEX_JSON.get_date(p_path => 'TransEndDate',p_format => 'YYYY-MM-DD'));
        --DBMS_OUTPUT.put_line('Transaction Number : ' || APEX_JSON.get_varchar2(p_path => 'transactionList[%d]', p0 => i));
        --dbms_output.put_line(apex_json.get_members(p_path=>'.',p_values=>j)(4));

    END LOOP; 
end;
/
