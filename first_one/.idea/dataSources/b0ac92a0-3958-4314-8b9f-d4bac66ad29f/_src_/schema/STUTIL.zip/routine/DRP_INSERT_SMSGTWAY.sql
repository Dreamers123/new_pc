CREATE PROCEDURE        drp_insert_smsgtway
IS
   v_catagory     VARCHAR2 (5);
   vreferenceno   VARCHAR2 (110);
   vstatus        VARCHAR2 (5);
   vmessage       VARCHAR2 (1024);
BEGIN
   FOR i IN (SELECT TRANUM,
                    BRANCD,
                    CUSNAME,
                    MESSGE,
                    MOBNUM,
                    AMOUNT,
                    REMARK,
                    CATAGORY,
                    OPRSTAMP,
                    TIMSTAMP
               FROM STUTIL.STSMSPUS
              WHERE ROWNUM <= 100)
   LOOP
      ---------------------------------------insert into smsdb server----------------------------
      BEGIN
         dpr_message_receive (pmobileno         => i.mobnum,
                              pmessagecontent   => i.messge,
                              pcategoryid       => i.catagory,
                              paccountno        => NULL,
                              pcustomerno       => NULL,
                              pamount           => i.amount,
                              prefno            => i.tranum,
                              pinitiatorid      => 6,
                              preferenceno      => vreferenceno,
                              pstatus           => vstatus,
                              pmessage          => vmessage);
      END;


      DELETE FROM stutil.stsmspus
            WHERE tranum = i.tranum;

      IF vstatus = 'E'
      THEN
         -----------------insert into stsmspus_er--------------------
         BEGIN
            INSERT INTO stutil.stsmspus_er (TRANUM,
                                            BRANCD,
                                            CUSNAME,
                                            MESSGE,
                                            MOBNUM,
                                            AMOUNT,
                                            REMARK,
                                            CATAGORY,
                                            OPRSTAMP,
                                            TIMSTAMP,
                                            ERRORMGS)
                 VALUES (i.TRANUM,
                         i.BRANCD,
                         i.CUSNAME,
                         i.MESSGE,
                         i.MOBNUM,
                         i.AMOUNT,
                         i.REMARK,
                         i.CATAGORY,
                         i.OPRSTAMP,
                         i.TIMSTAMP,
                         vmessage);
         EXCEPTION
            WHEN OTHERS
            THEN
               RAISE_APPLICATION_ERROR (
                  -20001,
                  'Can''t insert data into stsmspus_er - ' || vmessage);
         END;

         COMMIT;
      END IF;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
---   dbms_output.put_line(sqlerrm) ;
END;
/
