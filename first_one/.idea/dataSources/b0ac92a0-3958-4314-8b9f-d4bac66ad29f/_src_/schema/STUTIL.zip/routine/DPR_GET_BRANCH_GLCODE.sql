CREATE PROCEDURE        dpr_get_branch_glcode (
   p_dblink   IN     VARCHAR2,
   p_brancd   IN     VARCHAR2,
   p_glcode      OUT VARCHAR2,
   p_errflg        OUT VARCHAR2,
   p_errmsg        OUT VARCHAR2)
IS
   v_sql   VARCHAR2 (4000) := NULL;
BEGIN
   v_sql := 'SELECT glcode
              FROM stlbas.stbaninf@'|| p_dblink||'
             WHERE grpcde IN (''001'', ''002'') AND brancd = :brancd';
   EXECUTE IMMEDIATE v_sql INTO p_glcode USING p_brancd;
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
        p_errflg := 'E';
        p_errmsg := 'Invalid branch code...';
   WHEN TOO_MANY_ROWS
   THEN
        p_errflg := 'E';
        p_errmsg := 'Too many codes found in branch master for this branch...';
   WHEN OTHERS
   THEN
      p_errflg := 'E';
      p_errmsg := 'Exception Error : ' || SQLERRM;
END;
/
