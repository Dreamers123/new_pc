CREATE PROCEDURE        DESCO_WON_BANK_TRN_APPROVAL(
   p_dblink        IN     VARCHAR2,
   p_opr_brancd    IN     VARCHAR2,
   p_oprstamp      IN     VARCHAR2,
   p_amount        IN     NUMBER,
   -- p_tot_charge_amount   IN     NUMBER, update
   p_branch_code   IN     VARCHAR2,
   p_app_user      IN     VARCHAR2,
   p_AI_DOCDAT     IN     DATE,
   p_service_id    IN     VARCHAR2,
   P_TRAN_ID       IN     VARCHAR2,
   -- p_ai_user_type        IN     VARCHAR2,
   -- p_AI_GROUPCODE        IN     VARCHAR2,
   p_docnumber        OUT VARCHAR2,
   pErrorFlag         OUT VARCHAR2,
   pErrorMessage      OUT VARCHAR2)
IS
   oprstamp       VARCHAR2 (6);
   Mv_drcode      VARCHAR2 (20);
   v_tnum         VARCHAR2 (50) := NULL;
   v_erritem      VARCHAR2 (50) := NULL;
   O_ERR_FLG      VARCHAR2 (5) := NULL;
   O_ERR_MSG      VARCHAR2 (4000) := NULL;
   V_ACTYPE       VARCHAR2 (20);
   V_ACTNUM       VARCHAR2 (30);
   V_DOCTYPE      VARCHAR2 (5);
   V_oprcod       VARCHAR2 (50);
   v_errflg       VARCHAR2 (10) := NULL;
   V_VAT          VARCHAR2 (20) := 0;
   V_VATBRAN      VARCHAR2 (5);
   v_errmsg       VARCHAR2 (5000) := NULL;
   v_lmtamt       NUMBER := 0;
   o_curcde       VARCHAR2 (50);
   v_vat_crg      NUMBER ;
   V_AC_CHRG      VARCHAR2 (20) := 0;
   V_BRANCD_CRG   VARCHAR2 (5);
   V_ACTYPE_CRG   VARCHAR2 (5) := 0;
   v_stamp_crg      NUMBER := 0;
   v_drcode       VARCHAR2 (10) := NULL;
   v_crcode       VARCHAR2 (10) := NULL;
   v_drcode1      VARCHAR2 (10) := NULL;
   v_crcode1      VARCHAR2 (10) := NULL;
   v_doctype2     VARCHAR2 (3) := NULL;
   v_amount       NUMBER := 0;
   v_total_com    NUMBER := 0;
   v_service_id   VARCHAR2 (50) := 0;
   v_opr_brancd   VARCHAR2 (3);
   v_oprstamp     VARCHAR2 (500) := NULL;

   --P_TRAN_ID     VARCHAR2(20);
   V_CHQ_BRANCD   VARCHAR2 (10);
   V_CHQ_ACTYPE   VARCHAR2 (10);
   V_CHQ_ACNUM    VARCHAR2 (20);
   V_CHQ_NUM      VARCHAR2 (15);
   V_CHQ_SER      VARCHAR2 (10);
   V_CHQ_DATE     DATE;
   V_WDL          VARCHAR2 (5) := 'WDL';
   V_DEP          VARCHAR2 (5) := 'DEP';

   v_output       VARCHAR2 (100);
   v_err_msg      VARCHAR2 (500);
   CHQ_DOCNUM     VARCHAR2 (20);
   
   p_security_amount  NUMBER ;
   p_material_amount  NUMBER ;
   
   cr_brancd    varchar2(5);
   v_doctyp     varchar2(5);
   V_OPRCOD1    varchar2(5);
BEGIN
   /******************************************************************************
      NAME:       DESCO BILL COLLECTION WON BANK TRANSFER APPROVAL
      PURPOSE:    TRANSFER TRANSACTION APPROVAL
      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        08/18/2019      QAIUM       1. Created this Procedure.

      NOTES:

      Automatically available Auto Replace Keywords:
         Object Name:     DESCO BILL COLLECTION WON BANK TRANSFER APPROVAL
         Sysdate:         08/18/2019
         Date and Time:   08/18/2019
         Username:        Qaium
   ******************************************************************************/

   BEGIN
      -------------DYNAMIN A/C TYPE / A/C NUM--------------------
      SELECT A.SERVICE_PRO_ACC_NO, B.ACTYPE
        INTO V_ACTNUM, V_ACTYPE
        FROM STUTIL.SERVICE_PRO_INFO A, STLBAS.STFACMAS@STUTLTOCBS B
       WHERE     B.ACTNUM = A.SERVICE_PRO_ACC_NO
             AND B.BRANCD = SUBSTR (A.SERVICE_PRO_ACC_NO, 1, 3)
             AND B.ACSTAT NOT IN ('CLS', 'TRF')
             AND UPPER (A.SERVICE_ID) = UPPER (p_service_id);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         pErrorFlag := 'E';
         pErrorMessage := 'E1- Failed to get Mother A/c Information  ';
         GOTO ON_ERROR;
      WHEN OTHERS
      THEN
         pErrorFlag := 'E';
         pErrorMessage :=
            'E2- Failed to get Mother A/c Information. Ref :' || SQLERRM;
         GOTO ON_ERROR;
   END;

   BEGIN
      SELECT SUBSTR (A.CHQ_ACNUM, 1, 3) BRAN,
             B.ACTYPE,
             A.CHQ_ACNUM,
             A.CHQ_NUM,
             A.CHQ_SER,
             A.CHQ_DATE,
             A.COLUMNC0
        INTO V_CHQ_BRANCD,
             V_CHQ_ACTYPE,
             V_CHQ_ACNUM,
             V_CHQ_NUM,
             V_CHQ_SER,
             V_CHQ_DATE,
             CHQ_DOCNUM
        FROM STUTIL.STUTLINF A, STLBAS.STFACMAS@STUTLTOCBS B
       WHERE     A.TRNID = P_TRAN_ID
             AND UPPER (A.SERVICE_ID) = UPPER (p_service_id)
             AND B.ACTNUM = A.CHQ_ACNUM
             AND B.BRANCD = SUBSTR (A.CHQ_ACNUM, 1, 3)
             AND B.ACSTAT NOT IN ('CLS', 'TRF');
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         pErrorFlag := 'E';
         pErrorMessage := 'E3- Failed to get User A/c Information  ';
         GOTO ON_ERROR;
      WHEN OTHERS
      THEN
         pErrorFlag := 'E';
         pErrorMessage :=
            'E4- Failed to get User A/c Information. Ref :' || SQLERRM;
         GOTO ON_ERROR;
   END;

   BEGIN
      SELECT SERVICE_ID,
             OPBRANCD,
             T_TOTALBILL,
             CASE WHEN TOTAL_AMT > 399 THEN 10 ELSE 0 END charg
        INTO v_service_id,
             v_opr_brancd,
             v_amount,
             v_stamp_crg
        FROM STUTIL.STUTLINF
       WHERE TRNID = P_TRAN_ID AND UPPER (SERVICE_ID) = UPPER (p_service_id);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         raise_application_error (-20001, 'No Data Found in STUTLINF');
      WHEN TOO_MANY_ROWS
      THEN
         raise_application_error (-20001,
                                  'More Than One Record Found in STUTLINF');
      WHEN OTHERS
      THEN
         raise_application_error (-20001,
                                  'Error for Finding Data From STUTLINF');
   END;

   IF v_errmsg IS NULL
   THEN
      -------------DOCUMENT GENERATION PROCESS-------------

      IF     p_branch_code = SUBSTR (V_CHQ_ACNUM, 1, 3)
         AND p_branch_code = SUBSTR (V_ACTNUM, 1, 3)
         AND SUBSTR (V_CHQ_ACNUM, 1, 3) = SUBSTR (V_ACTNUM, 1, 3)
      THEN
         V_DOCTYPE := 'DC';
      ELSE
         V_DOCTYPE := 'IT';
      END IF;

      BEGIN
         STUTIL.dpr_teller_limit_check (p_dblink       => p_dblink,
                                        p_brancd       => p_branch_code,
                                        p_appusr       => p_app_user,
                                        p_doctyp       => V_DOCTYPE,
                                        p_oprcod       => V_WDL,
                                        p_actype       => V_CHQ_ACTYPE,
                                        p_curcde       => 'BDT',
                                        p_debcre       => 'D',
                                        p_typcde       => 'TLR',
                                        p_lmtamt       => v_lmtamt,
                                        p_tlr_curcde   => o_curcde,
                                        p_errflg       => v_errflg,
                                        p_errmsg       => v_errmsg);

         IF v_errmsg IS NOT NULL
         THEN
            ROLLBACK;
            raise_application_error (-20003,
                                     p_branch_code || '/' || v_errmsg);
         END IF;
      END;

      BEGIN
         STUTIL.dpr_teller_limit_check (p_dblink       => p_dblink,
                                        p_brancd       => p_branch_code,
                                        p_appusr       => p_app_user,
                                        p_doctyp       => V_DOCTYPE,
                                        p_oprcod       => V_DEP,
                                        p_actype       => V_ACTYPE,
                                        p_curcde       => 'BDT',
                                        p_debcre       => 'C',
                                        p_typcde       => 'TLR',
                                        p_lmtamt       => v_lmtamt,
                                        p_tlr_curcde   => o_curcde,
                                        p_errflg       => v_errflg,
                                        p_errmsg       => v_errmsg);

         IF v_errmsg IS NOT NULL
         THEN
            ROLLBACK;
            raise_application_error (-20003,
                                     p_branch_code || '/' || v_errmsg);
         END IF;
      END;

      BEGIN
         STLBAS.dpk_common.amount_block_remove@stutltocbs (
            p_branch    => SUBSTR (V_CHQ_ACNUM, 1, 3),
            p_actype    => V_CHQ_ACTYPE,
            p_actnum    => V_CHQ_ACNUM,
            p_modday    => p_AI_DOCDAT,
            p_docnum    => CHQ_DOCNUM,
            p_reason    => 'OTH',
            p_blkamt    => v_amount,
            p_userid    => p_oprstamp,
            p_supid     => p_app_user,
            p_err_msg   => v_err_msg);

         IF v_err_msg IS NOT NULL
         THEN
            ROLLBACK;
            raise_application_error (
               -20001,
                  'Block Amount Problem '
               || v_err_msg
               || 'Doc_No-'
               || CHQ_DOCNUM);
         END IF;
      END;

      BEGIN
         IF     p_branch_code = SUBSTR (V_CHQ_ACNUM, 1, 3) ------------------DC
            AND p_branch_code = SUBSTR (V_ACTNUM, 1, 3)
            AND SUBSTR (V_CHQ_ACNUM, 1, 3) = SUBSTR (V_ACTNUM, 1, 3)
         THEN
            BEGIN
               STUTIL.dpr_docnumber_generation (
                  p_dblink     => p_dblink, -----------> PASSING DBLINK FROM APPLICATION ITEM
                  p_compcd     => SUBSTR (p_branch_code, 1, 3),
                  p_modlcd     => 'ST',
                  p_doctyp     => V_DOCTYPE,
                  p_subtyp     => 1,
                  p_docdat     => SYSDATE,
                  p_loccde     => NULL,
                  p_origmodl   => 'ST',
                  p_docnum     => v_tnum,
                  p_errflag    => v_errflg,
                  p_errmsg     => v_errmsg);

               IF v_errmsg IS NULL
               THEN
                  v_tnum := SUBSTR (p_branch_code, 1, 3) || v_tnum;

                  p_docnumber := v_tnum;
               ELSE
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                     v_errflg || '- ' || v_errmsg || '1st');

                  ROLLBACK;

                  RETURN;
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                        'Error Generating Docnumber - '
                     || v_tnum
                     || '. Error : '
                     || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;

            BEGIN
               STUTIL.dpr_complete_transaction (
                  p_dblink        => p_dblink,
                  p_brancd        => p_branch_code,
                  p_tran_type     => 'REG',
                  p_acbrancd      => SUBSTR (V_CHQ_ACNUM, 1, 3),
                  p_oprcod        => V_WDL,
                  p_modday        => p_AI_DOCDAT,
                  p_valdat        => p_AI_DOCDAT,
                  p_actype        => V_CHQ_ACTYPE,
                  p_actnum        => V_CHQ_ACNUM,
                  p_chqsrl        => V_CHQ_SER,
                  p_chqnum        => V_CHQ_NUM,
                  p_chqdat        => V_CHQ_DATE,
                  p_loccur        => 'BDT',
                  p_doctyp        => V_DOCTYPE,
                  p_modcde        => 'ST',
                  p_trbrancd      => SUBSTR (V_ACTNUM, 1, 3),
                  p_tractype      => V_ACTYPE,
                  p_tractnum      => V_ACTNUM,
                  p_trchqser      => NULL,
                  p_trchqnum      => NULL,
                  p_trchqdat      => NULL,
                  p_appusr        => p_oprstamp,
                  p_action        => 'STALLTRN',
                  p_appflg        => 'N',
                  p_supid2        => p_app_user,
                  p_amount        => v_amount,
                  p_tinnum        => NULL,
                  p_appque        => 'N',
                  p_serlno        => 1,
                  p_docnum        => v_tnum,
                  p_acvalid_req   => 'Y',
                  p_clrzon        => NULL,
                  p_clrday        => NULL,
                  p_glcode        => NULL,
                  p_yrprfx        => NULL,
                  p_chgcde        => 'Y',
                  p_typcde        => 'TLR',
                  p_glflag        => 'Y',
                  p_remarks       => p_service_id || ' ' || 'Bill Collection.',
                  p_erritem       => v_erritem,
                  p_errflg        => O_ERR_FLG,
                  p_errmsg        => O_ERR_MSG);

               IF o_err_flg IS NOT NULL
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                        o_err_flg
                     || '-'
                     || o_err_msg
                     || 'CBS Transaction Not Complete...!');
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                     'ERROR: "dpr_complete_transaction -" ' || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;


            BEGIN
               STUTIL.dpr_complete_transaction (
                  p_dblink        => p_dblink,
                  p_brancd        => p_branch_code,
                  p_tran_type     => 'REG',
                  p_acbrancd      => SUBSTR (V_ACTNUM, 1, 3),
                  p_oprcod        => V_DEP,
                  p_modday        => p_AI_DOCDAT,
                  p_valdat        => p_AI_DOCDAT,
                  p_actype        => V_ACTYPE,
                  p_actnum        => V_ACTNUM,
                  p_chqsrl        => NULL,
                  p_chqnum        => NULL,
                  p_chqdat        => NULL,
                  p_loccur        => 'BDT',
                  p_doctyp        => V_DOCTYPE,
                  p_modcde        => 'ST',
                  p_trbrancd      => SUBSTR (V_CHQ_ACNUM, 1, 3),
                  p_tractype      => V_CHQ_ACTYPE,
                  p_tractnum      => V_CHQ_ACNUM,
                  p_trchqser      => V_CHQ_SER,
                  p_trchqnum      => V_CHQ_NUM,
                  p_trchqdat      => V_CHQ_DATE,
                  p_appusr        => p_oprstamp,
                  p_action        => 'STALLTRN',
                  p_appflg        => 'Y',
                  p_supid2        => p_app_user,
                  p_amount        => v_amount,
                  p_tinnum        => NULL,
                  p_appque        => 'N',
                  p_serlno        => 2,
                  p_docnum        => v_tnum,
                  p_acvalid_req   => 'Y',
                  p_clrzon        => NULL,
                  p_clrday        => NULL,
                  p_glcode        => NULL,
                  p_yrprfx        => NULL,
                  p_chgcde        => 'Y',
                  p_typcde        => 'TLR',
                  p_glflag        => 'Y',
                  p_remarks       => p_service_id || ' ' || 'Bill Collection.',
                  p_erritem       => v_erritem,
                  p_errflg        => O_ERR_FLG,
                  p_errmsg        => O_ERR_MSG);


               IF o_err_flg IS NOT NULL
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                        o_err_flg
                     || '-'
                     || o_err_msg
                     || 'CBS Transaction Not Complete...!');
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                     'ERROR: "dpr_complete_transaction -" ' || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;
         /*   BEGIN
               UPDATE STUTIL.STUTLINF
                  SET DOCNUM = v_tnum,
                      APPFLG = 'Y',
                      OPRSTAMP_APP = p_oprstamp,
                      TIMSTAMP_APP = SYSDATE
                WHERE TRNID = P_TRAN_ID
                AND   SERVICE_ID=p_service_id ;

               IF SQL%NOTFOUND
               THEN
                  raise_application_error (
                     -20001,
                     'Transection Flag is Not Updated !!');
                  ROLLBACK;
                  RETURN;
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  raise_application_error (
                     -20001,
                     'STUTLINF Update Failed! ERROR: ' || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;  */



         ELSIF --    p_branch_code <> SUBSTR (V_ACTNUM, 1, 3)  -------------------------------------------- IT
               (   p_branch_code = SUBSTR (V_CHQ_ACNUM, 1, 3)
                OR p_branch_code = SUBSTR (V_ACTNUM, 1, 3))
         THEN
            BEGIN
               STUTIL.dpr_docnumber_generation (
                  p_dblink     => p_dblink, -----------> PASSING DBLINK FROM APPLICATION ITEM
                  p_compcd     => SUBSTR (p_branch_code, 1, 3),
                  p_modlcd     => 'ST',
                  p_doctyp     => V_DOCTYPE,
                  p_subtyp     => 1,
                  p_docdat     => SYSDATE,
                  p_loccde     => NULL,
                  p_origmodl   => 'ST',
                  p_docnum     => v_tnum,
                  p_errflag    => v_errflg,
                  p_errmsg     => v_errmsg);

               IF v_errmsg IS NULL
               THEN
                  v_tnum := SUBSTR (p_branch_code, 1, 3) || v_tnum;

                  p_docnumber := v_tnum;
               ELSE
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                     v_errflg || '- ' || v_errmsg || '2nd');
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                        'Error Generating Docnumber - '
                     || v_tnum
                     || '. Error : '
                     || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;


            BEGIN
               STUTIL.dpr_complete_transaction (
                  p_dblink        => p_dblink,
                  p_brancd        => p_branch_code,         --:AI_BRANCH_CODE,
                  p_tran_type     => 'REG',
                  p_acbrancd      => SUBSTR (V_CHQ_ACNUM, 1, 3), ---BRANCH CODE
                  p_oprcod        => V_WDL,
                  p_modday        => p_AI_DOCDAT,                --:AI_DOCDAT,
                  p_valdat        => p_AI_DOCDAT,                --:AI_DOCDAT,
                  p_actype        => V_CHQ_ACTYPE,                    --ACTYPE
                  p_actnum        => V_CHQ_ACNUM,                ---ACT NUMBER
                  p_chqsrl        => V_CHQ_SER,
                  p_chqnum        => V_CHQ_NUM,
                  p_chqdat        => V_CHQ_DATE,
                  p_loccur        => 'BDT',
                  p_doctyp        => V_DOCTYPE,                     --DOC TYPE
                  p_modcde        => 'ST',
                  p_trbrancd      => SUBSTR (V_ACTNUM, 1, 3),   --:AI_BRANCH_CODE,            -
                  p_tractype      => V_ACTYPE,
                  p_tractnum      => V_ACTNUM,
                  p_trchqser      => NULL,
                  p_trchqnum      => NULL,
                  p_trchqdat      => NULL,
                  p_appusr        => p_oprstamp,
                  p_action        => 'STALLTRN',
                  p_appflg        => 'N',
                  p_supid2        => p_app_user,                  --:APP_USER,
                  p_amount        => v_amount,
                  p_tinnum        => NULL,
                  p_appque        => 'N',
                  p_serlno        => 1,
                  p_docnum        => v_tnum,
                  p_acvalid_req   => 'Y',
                  p_clrzon        => NULL,
                  p_clrday        => NULL,
                  p_glcode        => NULL,
                  p_yrprfx        => NULL,
                  p_chgcde        => 'Y',
                  p_typcde        => 'TLR',
                  p_glflag        => 'Y',
                  p_remarks       => p_service_id || ' ' || 'Bill Collection.',
                  p_erritem       => v_erritem,
                  p_errflg        => O_ERR_FLG,
                  p_errmsg        => O_ERR_MSG);

               IF o_err_flg IS NOT NULL
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                        o_err_flg
                     || '-'
                     || o_err_msg
                     || 'CBS Transaction Not Complete...!');
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                     'ERROR: "dpr_complete_transaction -" ' || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;

            BEGIN
               STUTIL.dpr_complete_transaction (
                  p_dblink        => p_dblink,
                  p_brancd        => p_branch_code,
                  p_tran_type     => 'REG',
                  p_acbrancd      => SUBSTR (V_ACTNUM, 1, 3),
                  p_oprcod        => V_DEP,
                  p_modday        => p_AI_DOCDAT,
                  p_valdat        => p_AI_DOCDAT,
                  p_actype        => V_ACTYPE,
                  p_actnum        => V_ACTNUM,
                  p_chqsrl        => NULL,
                  p_chqnum        => NULL,
                  p_chqdat        => NULL,
                  p_loccur        => 'BDT',
                  p_doctyp        => V_DOCTYPE,
                  p_modcde        => 'ST',
                  p_trbrancd      => SUBSTR (V_CHQ_ACNUM, 1, 3), --p_branch_code,  --:AI_BRANCH_CODE,
                  p_tractype      => V_CHQ_ACTYPE,
                  p_tractnum      => V_CHQ_ACNUM,
                  p_trchqser      => V_CHQ_SER,
                  p_trchqnum      => V_CHQ_NUM,
                  p_trchqdat      => V_CHQ_DATE,
                  p_appusr        => p_oprstamp,
                  p_action        => 'STALLTRN',
                  p_appflg        => 'Y',
                  p_supid2        => p_app_user,                  --:APP_USER,
                  p_amount        => v_amount,
                  p_tinnum        => NULL,
                  p_appque        => 'N',
                  p_serlno        => 2,
                  p_docnum        => v_tnum,
                  p_acvalid_req   => 'Y',
                  p_clrzon        => NULL,
                  p_clrday        => NULL,
                  p_glcode        => NULL,
                  p_yrprfx        => NULL,
                  p_chgcde        => 'Y',
                  p_typcde        => 'TLR',
                  p_glflag        => 'Y',
                  p_remarks       => p_service_id || ' ' || 'Bill Collection.',
                  p_erritem       => v_erritem,
                  p_errflg        => O_ERR_FLG,
                  p_errmsg        => O_ERR_MSG);


               IF o_err_flg IS NOT NULL
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                        o_err_flg
                     || '-'
                     || o_err_msg
                     || 'CBS Transaction Not Complete...!');
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                     'ERROR: "dpr_complete_transaction -" ' || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;
         /*   BEGIN
               UPDATE STUTIL.STUTLINF
                  SET DOCNUM = v_tnum,
                      APPFLG = 'Y',
                      OPRSTAMP_APP = p_oprstamp,
                      TIMSTAMP_APP = SYSDATE
                WHERE TRNID = P_TRAN_ID
                AND   SERVICE_ID=p_service_id ;

               IF SQL%NOTFOUND
               THEN
                  raise_application_error (
                     -20001,
                     'Transection Flag is Not Updated !!');
                  ROLLBACK;
                  RETURN;
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  raise_application_error (
                     -20001,
                     'STUTLINF Update Failed! ERROR: ' || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END; */



         ELSIF     p_branch_code <> SUBSTR (V_CHQ_ACNUM, 1, 3) ------------------------------ IT Triangular
               AND p_branch_code <> SUBSTR (V_ACTNUM, 1, 3)
         THEN
            BEGIN
               -- raise_application_error(-20001,p_dblink||'---'||p_branch_code||V_DOCTYPE);
               STUTIL.dpr_docnumber_generation (
                  p_dblink     => p_dblink, -----------> PASSING DBLINK FROM APPLICATION ITEM
                  p_compcd     => SUBSTR (p_branch_code, 1, 3),
                  p_modlcd     => 'ST',
                  p_doctyp     => V_DOCTYPE,
                  p_subtyp     => 1,
                  p_docdat     => SYSDATE,
                  p_loccde     => NULL,
                  p_origmodl   => 'ST',
                  p_docnum     => v_tnum,
                  p_errflag    => v_errflg,
                  p_errmsg     => v_errmsg);

               IF v_errmsg IS NULL
               THEN
                  v_tnum := SUBSTR (p_branch_code, 1, 3) || v_tnum;

                  p_docnumber := v_tnum;
               ELSE
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                     v_errflg || '- ' || v_errmsg || '3rd');

                  ROLLBACK;

                  RETURN;
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                        'Error Generating Docnumber - '
                     || v_tnum
                     || '. Error : '
                     || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;



            BEGIN
               STUTIL.dpr_complete_transaction (
                  p_dblink        => p_dblink,
                  p_brancd        => p_branch_code,         --:AI_BRANCH_CODE,
                  p_tran_type     => 'REG',
                  p_acbrancd      => SUBSTR (V_CHQ_ACNUM, 1, 3), ---BRANCH CODE
                  p_oprcod        => V_WDL,
                  p_modday        => p_AI_DOCDAT,                --:AI_DOCDAT,
                  p_valdat        => p_AI_DOCDAT,                --:AI_DOCDAT,
                  p_actype        => V_CHQ_ACTYPE,                    --ACTYPE
                  p_actnum        => V_CHQ_ACNUM,                ---ACT NUMBER
                  p_chqsrl        => V_CHQ_SER,
                  p_chqnum        => V_CHQ_NUM,
                  p_chqdat        => V_CHQ_DATE,
                  p_loccur        => 'BDT',
                  p_doctyp        => V_DOCTYPE,                     --DOC TYPE
                  p_modcde        => 'ST',
                  p_trbrancd      => SUBSTR (V_ACTNUM, 1, 3), --p_branch_code,  --:AI_BRANCH_CODE,            
                  p_tractype      => V_ACTYPE,
                  p_tractnum      => V_ACTNUM,
                  p_trchqser      => NULL,
                  p_trchqnum      => NULL,
                  p_trchqdat      => NULL,
                  p_appusr        => p_oprstamp,
                  p_action        => 'STALLTRN',
                  p_appflg        => 'N',
                  p_supid2        => p_app_user,                  --:APP_USER,
                  p_amount        => v_amount,
                  p_tinnum        => NULL,
                  p_appque        => 'N',
                  p_serlno        => 1,
                  p_docnum        => v_tnum,
                  p_acvalid_req   => 'Y',
                  p_clrzon        => NULL,
                  p_clrday        => NULL,
                  p_glcode        => NULL,
                  p_yrprfx        => NULL,
                  p_chgcde        => 'Y',
                  p_typcde        => 'TLR',
                  p_glflag        => 'Y',
                  p_remarks       => p_service_id || ' ' || 'Bill Collection.',
                  p_erritem       => v_erritem,
                  p_errflg        => O_ERR_FLG,
                  p_errmsg        => O_ERR_MSG);

               IF o_err_flg IS NOT NULL
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                        o_err_flg
                     || '-'
                     || o_err_msg
                     || 'CBS Transaction Not Complete...!');
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                     'ERROR: "dpr_complete_transaction -" ' || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;


            BEGIN
               STUTIL.dpr_complete_transaction (
                  p_dblink        => p_dblink,
                  p_brancd        => p_branch_code,         --:AI_BRANCH_CODE,
                  p_tran_type     => 'REG',
                  p_acbrancd      => SUBSTR (V_ACTNUM, 1, 3),   ---BRANCH CODE
                  p_oprcod        => V_DEP,
                  p_modday        => p_AI_DOCDAT,                --:AI_DOCDAT,
                  p_valdat        => p_AI_DOCDAT,                --:AI_DOCDAT,
                  p_actype        => V_ACTYPE,                        --ACTYPE
                  p_actnum        => V_ACTNUM,                   ---ACT NUMBER
                  p_chqsrl        => NULL,
                  p_chqnum        => NULL,
                  p_chqdat        => NULL,
                  p_loccur        => 'BDT',
                  p_doctyp        => V_DOCTYPE,                     --DOC TYPE
                  p_modcde        => 'ST',
                  p_trbrancd      => SUBSTR (V_CHQ_ACNUM, 1, 3), --p_branch_code,  --:AI_BRANCH_CODE,            -
                  p_tractype      => V_CHQ_ACTYPE,
                  p_tractnum      => V_CHQ_ACNUM,
                  p_trchqser      => V_CHQ_SER,
                  p_trchqnum      => V_CHQ_NUM,
                  p_trchqdat      => V_CHQ_DATE,
                  p_appusr        => p_oprstamp,
                  p_action        => 'STALLTRN',
                  p_appflg        => 'Y',
                  p_supid2        => p_app_user,                  --:APP_USER,
                  p_amount        => v_amount,
                  p_tinnum        => NULL,
                  p_appque        => 'N',
                  p_serlno        => 2,
                  p_docnum        => v_tnum,
                  p_acvalid_req   => 'Y',
                  p_clrzon        => NULL,
                  p_clrday        => NULL,
                  p_glcode        => NULL,
                  p_yrprfx        => NULL,
                  p_chgcde        => 'Y',
                  p_typcde        => 'TLR',
                  p_glflag        => 'Y',
                  p_remarks       => p_service_id || ' ' || 'Bill Collection.',
                  p_erritem       => v_erritem,
                  p_errflg        => O_ERR_FLG,
                  p_errmsg        => O_ERR_MSG);


               IF o_err_flg IS NOT NULL
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                        o_err_flg
                     || '-'
                     || o_err_msg
                     || 'CBS Transaction Not Complete...!');
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                     'ERROR: "dpr_complete_transaction -" ' || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;
         END IF;
      END;

      BEGIN
         stutil.dpr_getacglcode (p_dblink    => p_dblink,
                                 p_brancd    => SUBSTR (V_ACTNUM, 1, 3),
                                 p_actype    => V_ACTYPE,
                                 p_docdate   => p_AI_DOCDAT,     --:AI_DOCDAT,
                                 p_glcode    => v_drcode,
                                 p_errflg    => O_ERR_FLG,
                                 p_errmsg    => O_ERR_MSG);

         IF O_ERR_FLG IS NOT NULL
         THEN
            ROLLBACK;
            raise_application_error (-20001, O_ERR_FLG || ' - ' || O_ERR_MSG);

            ROLLBACK;
            RETURN;
         END IF;
      END;

      IF (SUBSTR (V_ACTNUM, 1, 3) <> v_opr_brancd)
      THEN
         BEGIN
            v_doctype2 := 'IT';
            stutil.dpr_get_branch_glcode (p_dblink   => p_dblink,
                                          p_brancd   => v_opr_brancd,
                                          p_glcode   => v_crcode,
                                          p_errflg   => O_ERR_FLG,
                                          p_errmsg   => O_ERR_MSG);

            IF O_ERR_FLG IS NOT NULL
            THEN
               ROLLBACK;
               raise_application_error (
                  -20001,
                  O_ERR_FLG || ' - ' || O_ERR_MSG || 'E11');
               ROLLBACK;
               RETURN;
            END IF;
         END;
      ELSE
         v_crcode := 'DUMMY';
         v_doctype2 := 'DC';
      END IF;
      
               IF (SUBSTR (V_ACTNUM, 1, 3) <> v_opr_brancd)
         THEN
            BEGIN
               v_doctype2 := 'IT';
               STUTIL.dpr_get_branch_glcode (
                  p_dblink   => p_dblink,
                  p_brancd   => SUBSTR (v_actnum, 1, 3),
                  p_glcode   => v_drcode,
                  p_errflg   => O_ERR_FLG,
                  p_errmsg   => O_ERR_MSG);

               IF O_ERR_FLG IS NOT NULL
               THEN
                  ROLLBACK;
                  raise_application_error (
                     -20001,
                        'dpr_get_branch_glcode -'
                     || O_ERR_FLG
                     || '-'
                     || O_ERR_MSG);
                  ROLLBACK;
                  RETURN;
               END IF;
            END;
         ELSE
            v_drcode := 'DUMMY';
            v_doctype2 := 'DC';
         END IF;

      IF v_stamp_crg IS NOT NULL
      THEN                                           -- IF CHARGE IS AVAILABLE
         BEGIN
            STUTIL.dpr_insert_fetran (
               p_dblink     => p_dblink,
               p_brancd     => SUBSTR (V_ACTNUM, 1, 3),
               p_doctyp     => v_doctype2,
               p_docnum     => v_tnum,
               p_sernum     => 3,
               p_docdat     => p_AI_DOCDAT,
               p_valdat     => p_AI_DOCDAT,
               p_oprcod     => 'WDL',
               p_actype     => V_ACTYPE,
               p_actnum     => V_ACTNUM,
               p_curcde     => 'BDT',
               p_exrate     => 1,
               p_debcre     => 'D',
               p_dbamfc     => v_stamp_crg,
               p_dbamlc     => v_stamp_crg,
               p_cramfc     => 0,
               p_cramlc     => 0,
               p_curbal     => 0,
               p_balflg     => 'Y',
               p_chgflg     => 'N',
               p_chqser     => NULL,
               p_chqnum     => NULL,
               p_chqdat     => NULL,
               p_trbrancd   => v_opr_brancd,
               p_tractype   => NULL,
               p_tractnum   => NULL,
               p_trchqser   => NULL,
               p_trchqnum   => NULL,
               p_trchqdat   => NULL,
               p_clrzon     => NULL,
               p_clrday     => NULL,
               p_prtflg     => 'N',
               p_glcode     => NULL,
               p_opbrancd   => p_branch_code,
               p_remark     =>    p_service_id
                               || ' '
                               || 'BILL COLLECTION-STEMP CHARGE FEE.',
               p_yrprfx     => NULL,
               p_chgcde     => 'N',
               p_modcde     => 'ST',
               p_supid2     => p_app_user,                        --:APP_USER,
               p_drcode     => v_drcode,                         --'10100-01',
               p_crcode     => v_crcode,                         --'15700-01',
               p_oprstamp   => p_oprstamp,                     --v_opr_brancd,
               p_timstamp   => SYSTIMESTAMP,
               p_glflag     => 'Y',
               p_refno5     => NULL,
               p_errflg     => O_ERR_FLG,
               p_errmsg     => O_ERR_MSG);

            IF O_ERR_FLG IS NOT NULL
            THEN
               ROLLBACK;
               raise_application_error (
                  -20001,
                  O_ERR_FLG || '-' || O_ERR_MSG || 'E2');
            END IF;
         EXCEPTION
            WHEN OTHERS
            THEN
               ROLLBACK;
               raise_application_error (
                  -20001,
                  'ERROR: "dpr_insert_fetran1 -" ' || SQLERRM);
               ROLLBACK;
               RETURN;
         END;
         
     SELECT SUBSTR (paraval, 1, 3) brancd
     INTO cr_brancd
     FROM stparamt	
     WHERE TYPE = 'DCR';   
         
      IF v_opr_brancd = cr_brancd
      THEN
         v_doctyp := 'CS';
         v_oprcod := 'WDL';
      -- tr_brancd := NULL;
         V_OPRCOD1 := 'DEP' ;
      ELSE
         v_doctyp := 'IC';
         v_oprcod := 'IB3';
      -- tr_brancd := cr_brancd;
         V_OPRCOD1 := 'IB1' ;
      END IF;
      
         BEGIN ---------------------------ChargeFee------------------------------------
            STUTIL.dpr_insert_fetran (
               p_dblink     => p_dblink,
               p_brancd     => v_opr_brancd,
               p_doctyp     => v_doctyp ,--v_doctype2,
               p_docnum     => v_tnum,
               p_sernum     => 4,
               p_docdat     => p_AI_DOCDAT,                      --:AI_DOCDAT,
               p_valdat     => p_AI_DOCDAT,                      --:AI_DOCDAT,
               p_oprcod     => V_OPRCOD1 , --'DEP',
               p_actype     => 'Z99',
               p_actnum     => v_opr_brancd || '00000099',
               p_curcde     => 'BDT',
               p_exrate     => 1,
               p_debcre     => 'C',
               p_dbamfc     => 0,
               p_dbamlc     => 0,
               p_cramfc     => v_stamp_crg,
               p_cramlc     => v_stamp_crg,
               p_curbal     => 0,
               p_balflg     => 'Y',
               p_chgflg     => 'N',
               p_chqser     => NULL,
               p_chqnum     => NULL,
               p_chqdat     => NULL,
               p_trbrancd   =>  cr_brancd , --SUBSTR (v_actnum, 1, 3),
               p_tractype   => NULL,                            ---v_depactyp,
               p_tractnum   => NULL,                             ---v_depacno,
               p_trchqser   => NULL,
               p_trchqnum   => NULL,
               p_trchqdat   => NULL,
               p_clrzon     => NULL,
               p_clrday     => NULL,
               p_prtflg     => 'N',
               p_glcode     => NULL,
               p_opbrancd   => p_branch_code,               --:AI_BRANCH_CODE,
               p_remark     =>    p_service_id
                               || ' '
                               || 'BILL COLLECTION-CHARGE FEE.',
               p_yrprfx     => NULL,
               p_chgcde     => 'N',
               p_modcde     => 'ST',
               p_supid2     => p_app_user,
               p_drcode     => '10100-01', -- v_drcode,                           
               p_crcode     => '15700-01', --V_AC_CHRG,                             
               p_oprstamp   => p_oprstamp,
               p_timstamp   => SYSTIMESTAMP,
               p_glflag     => 'Y',
               p_refno5     => NULL,
               p_errflg     => O_ERR_FLG,
               p_errmsg     => O_ERR_MSG);


            IF O_ERR_FLG IS NOT NULL
            THEN
               ROLLBACK;
               raise_application_error (
                  -20001,
                  O_ERR_FLG || '-' || O_ERR_MSG || 'E5');
            END IF;
         END;
      END IF;
      
      
      IF v_vat_crg IS NOT NULL THEN  -- IF VAT IS AVAILABLE
      
         BEGIN      
               STUTIL.dpr_insert_fetran (
                  p_dblink     => p_dblink,
                  p_brancd     => SUBSTR (v_actnum, 1, 3),
                  p_doctyp     => 'IT',
                  p_docnum     => v_tnum,
                  p_sernum     => 5,
                  p_docdat     => p_AI_DOCDAT,
                  p_valdat     => p_AI_DOCDAT,
                  p_oprcod     => 'WDL',
                  p_actype     => v_actype,
                  p_actnum     => V_ACTNUM,
                  p_curcde     => 'BDT',
                  p_exrate     => 1,
                  p_debcre     => 'D',
                  p_dbamfc     => v_vat_crg,
                  p_dbamlc     => v_vat_crg,
                  p_cramfc     => 0,
                  p_cramlc     => 0,
                  p_curbal     => 0,
                  p_balflg     => 'Y',
                  p_chgflg     => 'N',
                  p_chqser     => NULL,
                  p_chqnum     => NULL,
                  p_chqdat     => NULL,
                  p_trbrancd   => v_opr_brancd,
                  p_tractype   => NULL,
                  p_tractnum   => NULL,
                  p_trchqser   => NULL,
                  p_trchqnum   => NULL,
                  p_trchqdat   => NULL,
                  p_clrzon     => NULL,
                  p_clrday     => NULL,
                  p_prtflg     => 'N',
                  p_glcode     => NULL,
                  p_opbrancd   => p_branch_code,
                  p_remark     =>    p_service_id
                                  || ' '
                                  || 'BILL COLLECTION-VAT FEE.',
                  p_yrprfx     => NULL,
                  p_chgcde     => 'N',
                  p_modcde     => 'ST',
                  p_supid2     => p_app_user,
                  p_drcode     => v_drcode,
                  p_crcode     => '14100-01',
                  p_oprstamp   => p_oprstamp,
                  p_timstamp   => SYSTIMESTAMP,
                  p_glflag     => 'Y',
                  p_refno5     => NULL,
                  p_errflg     => O_ERR_FLG,
                  p_errmsg     => O_ERR_MSG);

               IF O_ERR_FLG IS NOT NULL
               THEN
                  raise_application_error (
                     -20001,
                     O_ERR_FLG || '-' || O_ERR_MSG || 'E3');
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  raise_application_error (
                     -20001,
                     'ERROR: "dpr_insert_fetran2 -" ' || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;
            
            IF O_ERR_FLG IS NULL THEN
            
            BEGIN                                     
               STUTIL.dpr_insert_fetran (
                  p_dblink     => p_dblink,
                  p_brancd     => V_VATBRAN,
                  p_doctyp     => 'IT',
                  p_docnum     => v_tnum,
                  p_sernum     => 6,
                  p_docdat     => p_AI_DOCDAT,
                  p_valdat     => p_AI_DOCDAT,
                  p_oprcod     => 'DEP',
                  p_actype     => 'Z99',
                  p_actnum     => V_VATBRAN || '00000099',
                  p_curcde     => 'BDT',
                  p_exrate     => 1,
                  p_debcre     => 'C',
                  p_dbamfc     => 0,
                  p_dbamlc     => 0,
                  p_cramfc     => v_vat_crg,
                  p_cramlc     => v_vat_crg,
                  p_curbal     => 0,
                  p_balflg     => 'Y',
                  p_chgflg     => 'N',
                  p_chqser     => NULL,
                  p_chqnum     => NULL,
                  p_chqdat     => NULL,
                  p_trbrancd   => v_opr_brancd,
                  p_tractype   => NULL,
                  p_tractnum   => NULL,
                  p_trchqser   => NULL,
                  p_trchqnum   => NULL,
                  p_trchqdat   => NULL,
                  p_clrzon     => NULL,
                  p_clrday     => NULL,
                  p_prtflg     => 'N',
                  p_glcode     => NULL,
                  p_opbrancd   => p_branch_code,
                  p_remark     =>    p_service_id
                                  || ' '
                                  || 'BILL COLLECTION-VAT FEE.',
                  p_yrprfx     => NULL,
                  p_chgcde     => 'N',
                  p_modcde     => 'ST',
                  p_supid2     => p_app_user,
                  p_drcode     => v_drcode,
                  p_crcode     => V_VAT, --VAT GL
                  p_oprstamp   => p_oprstamp,
                  p_timstamp   => SYSTIMESTAMP,
                  p_glflag     => 'Y',
                  p_refno5     => NULL,
                  p_errflg     => O_ERR_FLG,
                  p_errmsg     => O_ERR_MSG);

               IF O_ERR_FLG IS NOT NULL
               THEN
                  raise_application_error (
                     -20001,
                     O_ERR_FLG || '-' || O_ERR_MSG || 'E6');
               END IF;
            EXCEPTION
               WHEN OTHERS
               THEN
                  raise_application_error (
                     -20001,
                     'ERROR: "dpr_insert_fetran4 -" ' || SQLERRM);
                  ROLLBACK;
                  RETURN;
            END;
            END IF ;     
      END IF;
       IF p_security_amount IS NOT NULL
      THEN                                           -- IF SECURITY AMOUNT IS AVAILABLE
         BEGIN
            STUTIL.dpr_insert_fetran (
               p_dblink     => p_dblink,
               p_brancd     => SUBSTR (V_ACTNUM, 1, 3),
               p_doctyp     => v_doctype2,
               p_docnum     => v_tnum,
               p_sernum     => 3,
               p_docdat     => p_AI_DOCDAT,
               p_valdat     => p_AI_DOCDAT,
               p_oprcod     => 'WDL',
               p_actype     => V_ACTYPE,
               p_actnum     => V_ACTNUM,
               p_curcde     => 'BDT',
               p_exrate     => 1,
               p_debcre     => 'D',
               p_dbamfc     => p_security_amount,
               p_dbamlc     => p_security_amount,
               p_cramfc     => 0,
               p_cramlc     => 0,
               p_curbal     => 0,
               p_balflg     => 'Y',
               p_chgflg     => 'N',
               p_chqser     => NULL,
               p_chqnum     => NULL,
               p_chqdat     => NULL,
               p_trbrancd   => v_opr_brancd,
               p_tractype   => NULL,
               p_tractnum   => NULL,
               p_trchqser   => NULL,
               p_trchqnum   => NULL,
               p_trchqdat   => NULL,
               p_clrzon     => NULL,
               p_clrday     => NULL,
               p_prtflg     => 'N',
               p_glcode     => NULL,
               p_opbrancd   => p_branch_code,
               p_remark     =>    p_service_id
                               || ' '
                               || 'BILL COLLECTION-CHARGE FEE.',
               p_yrprfx     => NULL,
               p_chgcde     => 'N',
               p_modcde     => 'ST',
               p_supid2     => p_app_user,                        --:APP_USER,
               p_drcode     => v_drcode,                         --'10100-01',
               p_crcode     => v_crcode,                         --'15700-01',
               p_oprstamp   => p_oprstamp,                     --v_opr_brancd,
               p_timstamp   => SYSTIMESTAMP,
               p_glflag     => 'Y',
               p_refno5     => NULL,
               p_errflg     => O_ERR_FLG,
               p_errmsg     => O_ERR_MSG);

            IF O_ERR_FLG IS NOT NULL
            THEN
               ROLLBACK;
               raise_application_error (
                  -20001,
                  O_ERR_FLG || '-' || O_ERR_MSG || 'E2');
            END IF;
         EXCEPTION
            WHEN OTHERS
            THEN
               ROLLBACK;
               raise_application_error (
                  -20001,
                  'ERROR: "dpr_insert_fetran1 -" ' || SQLERRM);
               ROLLBACK;
               RETURN;
         END;



         BEGIN ---------------------------ChargeFee------------------------------------
            STUTIL.dpr_insert_fetran (
               p_dblink     => p_dblink,
               p_brancd     => v_opr_brancd,
               p_doctyp     => v_doctype2,
               p_docnum     => v_tnum,
               p_sernum     => 4,
               p_docdat     => p_AI_DOCDAT,                      --:AI_DOCDAT,
               p_valdat     => p_AI_DOCDAT,                      --:AI_DOCDAT,
               p_oprcod     => 'DEP',
               p_actype     => 'Z99',
               p_actnum     => v_opr_brancd || '00000099',
               p_curcde     => 'BDT',
               p_exrate     => 1,
               p_debcre     => 'C',
               p_dbamfc     => 0,
               p_dbamlc     => 0,
               p_cramfc     => p_security_amount,
               p_cramlc     => p_security_amount,
               p_curbal     => 0,
               p_balflg     => 'Y',
               p_chgflg     => 'N',
               p_chqser     => NULL,
               p_chqnum     => NULL,
               p_chqdat     => NULL,
               p_trbrancd   => SUBSTR (v_actnum, 1, 3),
               p_tractype   => NULL,                            ---v_depactyp,
               p_tractnum   => NULL,                             ---v_depacno,
               p_trchqser   => NULL,
               p_trchqnum   => NULL,
               p_trchqdat   => NULL,
               p_clrzon     => NULL,
               p_clrday     => NULL,
               p_prtflg     => 'N',
               p_glcode     => NULL,
               p_opbrancd   => p_branch_code,               --:AI_BRANCH_CODE,
               p_remark     =>    p_service_id
                               || ' '
                               || 'BILL COLLECTION-CHARGE FEE.',
               p_yrprfx     => NULL,
               p_chgcde     => 'N',
               p_modcde     => 'ST',
               p_supid2     => p_app_user,
               p_drcode     => v_drcode,                           --Mv_drcode
               p_crcode     => '15700-01', --V_AC_CHRG,                              --cgargeGL
               p_oprstamp   => p_oprstamp,
               p_timstamp   => SYSTIMESTAMP,
               p_glflag     => 'Y',
               p_refno5     => NULL,
               p_errflg     => O_ERR_FLG,
               p_errmsg     => O_ERR_MSG);

            IF O_ERR_FLG IS NOT NULL
            THEN
               ROLLBACK;
               raise_application_error (
                  -20001,
                  O_ERR_FLG || '-' || O_ERR_MSG || 'E5');
            END IF;
         END;
      END IF;
      
IF p_material_amount IS NOT NULL  --IF p_material_amount IS AVAILABLE
      THEN                                           
         BEGIN
            STUTIL.dpr_insert_fetran (
               p_dblink     => p_dblink,
               p_brancd     => SUBSTR (V_ACTNUM, 1, 3),
               p_doctyp     => v_doctype2,
               p_docnum     => v_tnum,
               p_sernum     => 3,
               p_docdat     => p_AI_DOCDAT,
               p_valdat     => p_AI_DOCDAT,
               p_oprcod     => 'WDL',
               p_actype     => V_ACTYPE,
               p_actnum     => V_ACTNUM,
               p_curcde     => 'BDT',
               p_exrate     => 1,
               p_debcre     => 'D',
               p_dbamfc     => p_material_amount,
               p_dbamlc     => p_material_amount,
               p_cramfc     => 0,
               p_cramlc     => 0,
               p_curbal     => 0,
               p_balflg     => 'Y',
               p_chgflg     => 'N',
               p_chqser     => NULL,
               p_chqnum     => NULL,
               p_chqdat     => NULL,
               p_trbrancd   => v_opr_brancd,
               p_tractype   => NULL,
               p_tractnum   => NULL,
               p_trchqser   => NULL,
               p_trchqnum   => NULL,
               p_trchqdat   => NULL,
               p_clrzon     => NULL,
               p_clrday     => NULL,
               p_prtflg     => 'N',
               p_glcode     => NULL,
               p_opbrancd   => p_branch_code,
               p_remark     =>    p_service_id
                               || ' '
                               || 'BILL COLLECTION-CHARGE FEE.',
               p_yrprfx     => NULL,
               p_chgcde     => 'N',
               p_modcde     => 'ST',
               p_supid2     => p_app_user,                        --:APP_USER,
               p_drcode     => v_drcode,                         --'10100-01',
               p_crcode     => v_crcode,                         --'15700-01',
               p_oprstamp   => p_oprstamp,                     --v_opr_brancd,
               p_timstamp   => SYSTIMESTAMP,
               p_glflag     => 'Y',
               p_refno5     => NULL,
               p_errflg     => O_ERR_FLG,
               p_errmsg     => O_ERR_MSG);

            IF O_ERR_FLG IS NOT NULL
            THEN
               ROLLBACK;
               raise_application_error (
                  -20001,
                  O_ERR_FLG || '-' || O_ERR_MSG || 'E2');
            END IF;
         EXCEPTION
            WHEN OTHERS
            THEN
               ROLLBACK;
               raise_application_error (
                  -20001,
                  'ERROR: "dpr_insert_fetran1 -" ' || SQLERRM);
               ROLLBACK;
               RETURN;
         END;



         BEGIN ---------------------------ChargeFee------------------------------------
            STUTIL.dpr_insert_fetran (
               p_dblink     => p_dblink,
               p_brancd     => v_opr_brancd,
               p_doctyp     => v_doctype2,
               p_docnum     => v_tnum,
               p_sernum     => 4,
               p_docdat     => p_AI_DOCDAT,                      --:AI_DOCDAT,
               p_valdat     => p_AI_DOCDAT,                      --:AI_DOCDAT,
               p_oprcod     => 'DEP',
               p_actype     => 'Z99',
               p_actnum     => v_opr_brancd || '00000099',
               p_curcde     => 'BDT',
               p_exrate     => 1,
               p_debcre     => 'C',
               p_dbamfc     => 0,
               p_dbamlc     => 0,
               p_cramfc     => p_material_amount,
               p_cramlc     => p_material_amount,
               p_curbal     => 0,
               p_balflg     => 'Y',
               p_chgflg     => 'N',
               p_chqser     => NULL,
               p_chqnum     => NULL,
               p_chqdat     => NULL,
               p_trbrancd   => SUBSTR (v_actnum, 1, 3),
               p_tractype   => NULL,                            ---v_depactyp,
               p_tractnum   => NULL,                             ---v_depacno,
               p_trchqser   => NULL,
               p_trchqnum   => NULL,
               p_trchqdat   => NULL,
               p_clrzon     => NULL,
               p_clrday     => NULL,
               p_prtflg     => 'N',
               p_glcode     => NULL,
               p_opbrancd   => p_branch_code,               --:AI_BRANCH_CODE,
               p_remark     =>    p_service_id
                               || ' '
                               || 'BILL COLLECTION-CHARGE FEE.',
               p_yrprfx     => NULL,
               p_chgcde     => 'N',
               p_modcde     => 'ST',
               p_supid2     => p_app_user,
               p_drcode     => v_drcode,                           --Mv_drcode
               p_crcode     => '15700-01', --V_AC_CHRG,                              --cgargeGL
               p_oprstamp   => p_oprstamp,
               p_timstamp   => SYSTIMESTAMP,
               p_glflag     => 'Y',
               p_refno5     => NULL,
               p_errflg     => O_ERR_FLG,
               p_errmsg     => O_ERR_MSG);

            IF O_ERR_FLG IS NOT NULL
            THEN
               ROLLBACK;
               raise_application_error (
                  -20001,
                  O_ERR_FLG || '-' || O_ERR_MSG || 'E5');
            END IF;
         END;
      END IF;

      IF O_ERR_FLG IS NULL AND O_ERR_MSG IS NULL
      THEN
         BEGIN
            UPDATE STUTIL.STUTLINF
               SET DOCNUM = v_tnum,
                   APPFLG = 'Y',
                   OPRSTAMP_APP = p_oprstamp,
                   TIMSTAMP_APP = SYSDATE
             WHERE TRNID = P_TRAN_ID AND SERVICE_ID = p_service_id;

            IF SQL%NOTFOUND
            THEN
               ROLLBACK;
               raise_application_error (-20001,
                                        'Transection Flag is Not Updated !!');
               ROLLBACK;
               RETURN;
            END IF;
         EXCEPTION
            WHEN OTHERS
            THEN
               ROLLBACK;
               raise_application_error (
                  -20001,
                  'STUTLINF Update Failed! ERROR: ' || SQLERRM);
               ROLLBACK;
               RETURN;
         END;
      END IF;
   END IF;

   GOTO ON_SUCCESS;

  <<ON_ERROR>>
   ROLLBACK;

  <<ON_SUCCESS>>
   NULL;
END;
/
