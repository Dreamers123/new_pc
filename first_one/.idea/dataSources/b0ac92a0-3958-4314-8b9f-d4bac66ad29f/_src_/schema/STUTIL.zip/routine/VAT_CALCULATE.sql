CREATE FUNCTION vat_calculate (p_primum IN NUMBER,
                                          p_charg_per  IN NUMBER,
                                          p_vat_per IN NUMBER)
   RETURN NUMBER
IS
   
   temp      NUMBER;
   vat_out   NUMBER;
BEGIN


   temp := p_primum / (1 + p_charg_per + p_charg_per * p_vat_per);
   vat_out := temp * p_charg_per * p_vat_per;

   RETURN ROUND (vat_out,2);

END;
/
