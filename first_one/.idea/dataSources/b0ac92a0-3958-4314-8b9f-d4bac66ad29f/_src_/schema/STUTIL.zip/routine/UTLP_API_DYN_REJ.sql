CREATE PROCEDURE UTLP_API_DYN_REJ (p_service_id   IN     VARCHAR2,
                                              p_tran         IN     VARCHAR2,
                                              p_stat            OUT VARCHAR2,
                                              p_sub             OUT NUMBER)
IS
   v_receipt         VARCHAR2 (100);
   v_stat            VARCHAR2 (100);
   v_sub             NUMBER;
   v_p_paymentId     NUMBER;
   v_p_routingNo     VARCHAR2 (200);
   v_o_id            VARCHAR2 (200);
   v_o_bank          VARCHAR2 (200);
   v_o_batchNo       VARCHAR2 (200);
   v_o_amount        NUMBER;
   v_o_surcharge     NUMBER;
   v_o_total         NUMBER;
   v_o_voucherDate   VARCHAR2 (200);
   v_o_particulars   VARCHAR2 (200);
   v_o_errflg        VARCHAR2 (200);
   v_o_errmsg        VARCHAR2 (200);
BEGIN
   IF UPPER (p_service_id) = UPPER ('PRAGATI')
   THEN
      BEGIN
         SELECT OUT_ID
           INTO v_receipt
           FROM stutlinf
          WHERE     UPPER (SERVICE_ID) = UPPER ('PRAGATI')
                AND TRNID = p_tran
                AND APPFLG = 'P';
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            raise_application_error (-20002, 'No Data Found');
      END;

      --raise_application_error(-20003,'receipt'|| v_receipt);
      pragati_reject_json (receipt   => v_receipt,
                           status    => v_stat,
                           no_sub    => v_sub);

      IF v_sub <> 2
      THEN
         RAISE_APPLICATION_ERROR (
            -20002,
            'E- Status Code- ' || v_sub || ' Status-' || v_stat);
      ELSE
         UPDATE STUTLINF
            SET APPFLG = 'R', -- BILLSTATUS='D',
                              --BLKID = v_o_id ,
                              TIMSTAMP_APP = SYSDATE
          WHERE     UPPER (SERVICE_ID) = UPPER (p_service_id)
                AND TRNID = p_tran
                AND APPFLG = 'P';
      END IF;
   ELSIF p_service_id = 'TITAS_NON_M'
   THEN
      /** select OUT_ID,OUT_ROUTING into v_p_paymentId,v_p_routingNo
      from STUTLINF
      where TRNID = APEX_APPLICATION.G_f30 (VAR) AND  UPPER (SERVICE_ID) = UPPER (:P159_SERVICE_ID);
      **/

      BEGIN
         SELECT OUT_ID, OUT_ROUTING
           INTO v_p_paymentId, v_p_routingNo
           FROM STUTLINF
          WHERE TRNID = p_tran AND UPPER (SERVICE_ID) = UPPER (p_service_id);
      EXCEPTION                                           ---  Added_17Apr2019
         WHEN OTHERS
         THEN
            RAISE_APPLICATION_ERROR (-20001, '10. ' || SQLERRM);
      END;

      IF v_p_paymentId IS NULL
      THEN                                                ---  Added_17Apr2019
         RAISE_APPLICATION_ERROR (-20001, 'Payment Id Can not be null');
      END IF;

      IF v_p_routingNo IS NULL
      THEN                                                ---  Added_17Apr2019
         RAISE_APPLICATION_ERROR (-20001, 'Rounting No. Can not be null');
      END IF;

      BEGIN
         /*STUTIL.dpr_nonmetered_delete_payment (
          p_paymentId     =>    v_p_paymentId,
          p_routingNo     =>  v_p_routingNo ,
          o_id            =>  v_o_id,
          o_bank           => v_o_bank,
          o_batchNo        => v_o_batchNo,
          o_amount         => v_o_amount,
          o_surcharge      => v_o_surcharge,
          o_total          => v_o_total,
          o_voucherDate    => v_o_voucherDate,
          o_particulars    => v_o_particulars,
          o_errflg         => v_o_errflg,
          o_errmsg         => v_o_errmsg) ;
         if v_o_errflg = 'E' then          ---  Added_17Apr2019
         RAISE_APPLICATION_ERROR(-20001, '1 ' || v_o_errflg ||' , '||v_o_errmsg);
         end if;*/
         NULL;
      END;

      IF    v_o_id IS NOT NULL
         OR v_o_bank IS NOT NULL
         OR v_o_batchNo IS NOT NULL
      THEN
         UPDATE STUTLINF
            SET APPFLG = 'R', -- BILLSTATUS='D',
                              BLKID = v_o_id, TIMSTAMP_APP = SYSDATE
          WHERE     UPPER (SERVICE_ID) = UPPER (p_service_id)
                AND TRNID = p_tran
                AND APPFLG = 'P';
      ELSE
         RAISE_APPLICATION_ERROR (-20001,
                                  'Reject Not Complete !!! ' || v_o_errmsg);
      END IF;
   ELSIF p_service_id = 'TITAS_METERED'
   THEN
      DECLARE
         v_p_invoiceNo      VARCHAR2 (100);
         v_p_customerCode   VARCHAR2 (100);
         v_p_operator       VARCHAR2 (100);
         v_p_reason         VARCHAR2 (100);
      BEGIN
         BEGIN
            SELECT OUT_ID,
                   COLUMNC2,
                   CUSTID,
                   OPRSTAMP,
                   'Wrong Input'
              INTO v_p_paymentId,
                   v_p_invoiceNo,
                   v_p_customerCode,
                   v_p_operator,
                   v_p_reason
              FROM STUTLINF
             WHERE     TRNID = p_tran
                   AND UPPER (SERVICE_ID) = UPPER (p_service_id);
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               RAISE_APPLICATION_ERROR (-20001,
                                        'No Data Found For Rejection !!!');
         END;
      /*dpr_Metered_Cancel_payment (
       p_paymentId      =>     v_p_paymentId,
       p_invoiceNo      =>     v_p_invoiceNo,
       p_customerCode   =>     v_p_customerCode,
       p_operator       =>     v_p_operator,
       p_reason         =>     v_p_reason,
       p_message        =>     v_p_message ,
       o_errflg            => v_o_errflg,
       o_errmsg            => v_o_errmsg) ;

       if v_o_errmsg is null and v_p_message='200' then

        UPDATE STUTLINF
                   SET APPFLG = 'R',
                       OUT_ROUTING=v_p_message,
                       BLKID= v_o_id ,
                       TIMSTAMP_APP = SYSDATE

                 WHERE     UPPER (SERVICE_ID) = UPPER (p_service_id)
                       AND TRNID = p_tran
                       AND APPFLG = 'P' ;
                  APEX_APPLICATION.g_print_success_message :=
                   '<spanstyle="color:white">transaction Successfully Rejected '||v_p_message||'</span>';
           else
            RAISE_APPLICATION_ERROR(-20001,'Reject Not Complete !!! '||v_o_errmsg||'Message-'||v_p_message);
        end if; */


      END;
      
      
      elsif p_service_id = 'TITAS_NON_M_DEMAND_NOTE' then
   declare
   v_p_paymentId               varchar2(100);
   v_p_routingNo               VARCHAR2(100);
   v_o_id                      VARCHAR2(100);
   v_o_bank                    VARCHAR2(100);
   v_o_amount                  NUMBER ;
   v_o_voucherDate             VARCHAR2(100);
   v_o_bankTransactionId       VARCHAR2(100);
   v_o_batchNo                 VARCHAR2(100);
   v_o_errflg                  VARCHAR2(100);
   v_o_errmsg                 VARCHAR2(100);
 
begin
select OUT_ID,OUT_ROUTING into v_p_paymentId,v_p_routingNo 
  from STUTLINF 
  where TRNID = p_tran 
  AND  UPPER (SERVICE_ID) = UPPER (p_service_id);
 
/*STUTIL.dpr_nonmtd_dmand_delete_pmt (
   p_paymentId           =>    v_p_paymentId,
   p_routingNo           =>     v_p_routingNo,
   o_id                     =>  v_o_id,
   o_bank                   =>  v_o_bank,
   o_amount                 =>  v_o_amount,
   o_voucherDate            =>  v_o_voucherDate,
   o_bankTransactionId      =>  v_o_bankTransactionId,
   o_batchNo                =>  v_o_batchNo,
   o_errflg                 =>  v_o_errflg,
   o_errmsg                 =>  v_o_errmsg) ;*/
   
   if v_o_id is not null then       
     UPDATE STUTLINF
               SET APPFLG = 'R',
                  -- BILLSTATUS='D',
                   BLKID = v_o_id ,
                   TIMSTAMP_APP = SYSDATE
                
             WHERE     UPPER (SERVICE_ID) = UPPER (p_service_id)
                   AND TRNID = p_tran
                   AND APPFLG = 'P' ;
       else
       RAISE_APPLICATION_ERROR(-20001,'Reject Not Complete !!! '||v_o_errmsg);
       end if;
       
       end ;
   END IF;
END UTLP_API_DYN_REJ;
/
