CREATE PROCEDURE        dpr_insert_kgdclog (
   logType        IN VARCHAR2 DEFAULT 'GET',
   cuscod         IN VARCHAR2,
   custype        IN VARCHAR2,
   mobile_no      IN VARCHAR2,
   stamp_amt      IN VARCHAR2,
   in_post_data   IN CLOB DEFAULT NULL,
   in_json_data   IN CLOB)
IS
   v_cusname     stutil.stkgdclb_log.cusname%TYPE;
   v_totalbil    stutil.stkgdclb_log.totalbil%TYPE;
   v_surcharge   stutil.stkgdclb_log.surcharge%TYPE;

   PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
   IF logType = 'GET'
   THEN
      BEGIN
         apex_json.parse (in_json_data);

         v_cusname :=
            CASE
               WHEN UPPER (custype) <> 'NM'
               THEN
                  apex_json.get_varchar2 (p_path => 'content."Customer Name"')
               ELSE
                  apex_json.get_varchar2 (p_path => 'content.NAME')
            END;
         v_totalbil :=
            CASE
               WHEN UPPER (custype) <> 'NM'
               THEN
                  apex_json.get_varchar2 (p_path => 'content."Total Bill Amount"')
               ELSE
                  apex_json.get_varchar2 (
                     p_path => 'content."Current Total(Surch Incl.)"')
            END;
         v_surcharge :=
            CASE
               WHEN UPPER (custype) <> 'NM'
               THEN
                  apex_json.get_varchar2 (p_path => 'content.Surcharge')
               ELSE
                  apex_json.get_varchar2 (p_path => 'content."Surcharge Amount"')
            END;

         INSERT INTO stutil.stkgdclb_log (custid,
                                              cusname,
                                              custype,
                                              mobileno,
                                              totalbil,
                                              stampamt,
                                              docdat,
                                              isgovt,
                                              bill_month,
                                              bill_year,
                                              gas_bill,
                                              meter_charge,
                                              surcharge,
                                              webservice_get_url,
                                              webservice_post_url,
                                              api_response_pst,
                                              oprbranch,
                                              oprstamp,
                                              api_response)
              VALUES (
                        cuscod,
                        v_cusname,
                        custype,
                        mobile_no,
                        v_totalbil,
                        stamp_amt,
                        v ('AI_DOCDAT'),
                        NVL (apex_json.get_varchar2 (p_path => 'content."Is Govt."'),
                             'NO'),
                        apex_json.get_varchar2 (p_path => 'content."Bill Month"'),
                        apex_json.get_varchar2 (p_path => 'content."Bill Year"'),
                        apex_json.get_varchar2 (p_path => 'content."Gas Bill"'),
                        apex_json.get_varchar2 (p_path => 'content."Meter Charge"'),
                        v_surcharge,
                        v ('AI_WEBSERVICE_API_GET'),
                        v ('AI_WEBSERVICE_API_POST'),
                        apex_json.get_varchar2 (p_path => 'Message'),
                        v ('AI_BRANCH_CODE'),
                        v ('APP_USER'),
                        in_json_data);

         COMMIT;
      EXCEPTION
         WHEN OTHERS
         THEN
            INSERT INTO stutil.stkgdclb_log (custid,
                                                 cusname,
                                                 custype,
                                                 mobileno,
                                                 totalbil,
                                                 stampamt,
                                                 docdat,
                                                 isgovt,
                                                 bill_month,
                                                 bill_year,
                                                 gas_bill,
                                                 meter_charge,
                                                 surcharge,
                                                 webservice_get_url,
                                                 webservice_post_url,
                                                 api_response_pst,
                                                 oprbranch,
                                                 oprstamp,
                                                 api_response)
                 VALUES (cuscod,
                         v_cusname,
                         custype,
                         mobile_no,
                         v_totalbil,
                         stamp_amt,
                         v ('AI_DOCDAT'),
                         NULL, -- NVL (apex_json.get_varchar2 (p_path => '"Is Govt."'), 'NO'),
                         NULL, --apex_json.get_varchar2 (p_path => '"Bill Month"'),
                         NULL, --apex_json.get_varchar2 (p_path => '"Bill Year"'),
                         NULL, -- apex_json.get_varchar2 (p_path => '"Gas Bill"'),
                         NULL, -- apex_json.get_varchar2 (p_path => '"Meter Charge"'),
                         v_surcharge,
                         v ('AI_WEBSERVICE_API_GET'),
                         v ('AI_WEBSERVICE_API_POST'),
                         NULL, -- apex_json.get_varchar2 (p_path => 'Message'),
                         v ('AI_BRANCH_CODE'),
                         v ('APP_USER'),
                         in_json_data);

            COMMIT;
      END;
   END IF;                                                      ------ GET LOG

   IF logType = 'PST'
   THEN
      BEGIN
         UPDATE stutil.stkgdclb_log
            SET webservice_post_url = v ('AI_WEBSERVICE_API_POST'),
                api_response_pst = in_json_data,
                post_data = in_post_data
          WHERE custid = cuscod
            AND timstamp = (SELECT MAX(TIMSTAMP) from stutil.stkgdclb_log
                          WHERE custid = cuscod);
      IF SQL%NOTFOUND THEN
         NULL;
      END IF;                    
      END;
   END IF;
END;
/
