CREATE FUNCTION get_column_name
  (p_var varchar2)

   RETURN varchar2

IS 

var varchar2(3000);

BEGIN
/*   
for i in (select COLUMNNM from STUTLPAR where SERVICE_ID=p_var )
             
loop
var := var||','||i.COLUMNNM;

var:=ltrim(var,',');

END LOOP ;
*/
RETURN 'STUTLPAR.SERVICE_ID';

END  get_column_name;
/
