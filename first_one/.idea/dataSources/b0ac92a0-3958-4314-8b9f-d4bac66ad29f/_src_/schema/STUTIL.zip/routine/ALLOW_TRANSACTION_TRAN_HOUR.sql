CREATE PROCEDURE        ALLOW_TRANSACTION_TRAN_HOUR (
   pAllowTransaction   OUT VARCHAR2,
   pErrorFlag          OUT VARCHAR2,
   pErrorMessage       OUT VARCHAR2)
AS
   vCurrentHr       VARCHAR2 (2);
   vCurrentMinute   VARCHAR2 (2);
   vCurrentAm       VARCHAR2 (2);
   vTranStatHr      VARCHAR2 (2);
   vTranStatMin     VARCHAR2 (2);
   vTranStatAM      VARCHAR2 (2);
   vTranEndHr       VARCHAR2 (2);
   vTranEndMin      VARCHAR2 (2);
   vTranEndPM       VARCHAR2 (2);
   vTranStatTime    NUMBER;
   vTranEndTime     NUMBER;
   vCurrentTime     NUMBER;
   vMyException     EXCEPTION;
BEGIN
   pErrorFlag := 'N';
   pAllowTransaction := 'Y';

   BEGIN
      SELECT DECODE (TO_CHAR (SYSDATE, 'HH'), 12, 0, TO_CHAR (SYSDATE, 'HH')),
             TO_CHAR (SYSDATE, 'MI'),
             TO_CHAR (SYSDATE, 'AM')
        INTO vCurrentHr, vCurrentMinute, vCurrentAm
        FROM DUAL;
   EXCEPTION
      WHEN OTHERS
      THEN
         pErrorMessage :=
            'Current DB system Time Finding Problem. - ' || SQLERRM;
         RAISE vMyException;
   END;


   IF UPPER (vCurrentAm) = 'AM'
   THEN
      vCurrentTime :=
         TO_NUMBER (vCurrentHr) * 3600 + TO_NUMBER (vCurrentMinute) * 60;
   ELSIF UPPER (vCurrentAm) = 'PM'
   THEN
      vCurrentTime :=
         TO_NUMBER (vCurrentHr + 12) * 3600 + TO_NUMBER (vCurrentMinute) * 60;
   END IF;

   BEGIN
      SELECT TranStatHr,
             TranStatMin,
             TranStatAM,
             TranEndHr,
             TranEndMin,
             TranEndPM
        INTO vTranStatHr,
             vTranStatMin,
             vTranStatAM,
             vTranEndHr,
             vTranEndMin,
             vTranEndPM
        FROM (SELECT SUBSTR (START_TIME, 1, 2) TranStatHr,
                     SUBSTR (START_TIME, 4, 2) TranStatMin,
                     SUBSTR (START_TIME, 7, 2) TranStatAM,
                     SUBSTR (END_TIME, 1, 2) TranEndHr,
                     SUBSTR (END_TIME, 4, 2) TranEndMin,
                     SUBSTR (END_TIME, 7, 2) TranEndPM,
                     EFFECTIVE_DATE,
                     NVL (
                        LEAD (EFFECTIVE_DATE - 1)
                           OVER (ORDER BY EFFECTIVE_DATE),
                        TRUNC (SYSDATE) + 10)
                        EXPIRE_DATE
                FROM stutil.GLOBAL_TRAN_HOUR
               WHERE NVL (ACTIVE_FLAG, 'N') = 'Y')
       WHERE SYSDATE BETWEEN EFFECTIVE_DATE AND EXPIRE_DATE;
   EXCEPTION
      WHEN OTHERS
      THEN
         pErrorMessage := 'System Global Time Finding Problem. - ' || SQLERRM;
         RAISE vMyException;
   END;

   IF UPPER (vTranStatAM) = 'AM'
   THEN
      BEGIN
         SELECT   TO_NUMBER (vTranStatHr) * 3600
                + TO_NUMBER (vTranStatMin) * 60
           INTO vTranStatTime
           FROM DUAL;
      EXCEPTION
         WHEN OTHERS
         THEN
            pErrorMessage :=
               'System Global Start Time Setting Problem. - ' || SQLERRM;
            RAISE vMyException;
      END;
   ELSIF UPPER (vTranStatAM) = 'PM'
   THEN
      BEGIN
         vTranStatTime :=
              TO_NUMBER (vTranStatHr + 12) * 3600
            + TO_NUMBER (vTranStatMin) * 60;
      EXCEPTION
         WHEN OTHERS
         THEN
            pErrorMessage :=
               'System Global Start Time Setting Problem. - ' || SQLERRM;
            RAISE vMyException;
      END;
   ELSE
      pErrorMessage := 'System Global Start Time Setting Problem.';
      RAISE vMyException;
   END IF;



   IF UPPER (vTranEndPM) = 'AM'
   THEN
      BEGIN
         SELECT TO_NUMBER (vTranEndHr) * 3600 + TO_NUMBER (vTranEndMin) * 60
           INTO vTranEndTime
           FROM DUAL;
      EXCEPTION
         WHEN OTHERS
         THEN
            pErrorMessage :=
               'System Global End Time Setting Problem. - ' || SQLERRM;
            RAISE vMyException;
      END;
   ELSIF UPPER (vTranEndPM) = 'PM'
   THEN
      BEGIN
         SELECT   TO_NUMBER (vTranEndHr + 12) * 3600
                + TO_NUMBER (vTranEndMin) * 60
           INTO vTranEndTime
           FROM DUAL;
      EXCEPTION
         WHEN OTHERS
         THEN
            pErrorMessage :=
               'System Global End Time Setting Problem. - ' || SQLERRM;
            RAISE vMyException;
      END;
   ELSE
      pErrorMessage := 'System Global End Time Setting Problem.';
      RAISE vMyException;
   END IF;


   IF vCurrentTime >= vTranStatTime AND vCurrentTime <= vTranEndTime
   THEN
      pAllowTransaction := 'Y';
   ELSE
      pAllowTransaction := 'N';
   END IF;
EXCEPTION
   WHEN vMyException
   THEN
      pErrorFlag := 'Y';
END;
/
