CREATE PROCEDURE        dpr_insert_fetran (
   p_dblink     IN     VARCHAR2,
   p_brancd     IN     VARCHAR2,
   p_doctyp     IN     VARCHAR2,
   p_docnum     IN     VARCHAR2,
   p_sernum     IN     NUMBER,
   p_docdat     IN     DATE,
   p_valdat     IN     DATE,
   p_oprcod     IN     VARCHAR2,
   p_actype     IN     VARCHAR2,
   p_actnum     IN     VARCHAR2,
   p_curcde     IN     VARCHAR2,
   p_exrate     IN     VARCHAR2,
   p_debcre     IN     VARCHAR2,
   p_dbamfc     IN     NUMBER,
   p_dbamlc     IN     NUMBER,
   p_cramfc     IN     NUMBER,
   p_cramlc     IN     NUMBER,
   p_curbal     IN     NUMBER,
   p_balflg     IN     VARCHAR2,
   p_chgflg     IN     VARCHAR2,
   p_chqser     IN     VARCHAR2,
   p_chqnum     IN     VARCHAR2,
   p_chqdat     IN     DATE,
   p_trbrancd   IN     VARCHAR2,
   p_tractype   IN     VARCHAR2,
   p_tractnum   IN     VARCHAR2,
   p_trchqser   IN     VARCHAR2,
   p_trchqnum   IN     VARCHAR2,
   p_trchqdat   IN     DATE,
   p_clrzon     IN     NUMBER,
   p_clrday     IN     NUMBER,
   p_prtflg     IN     VARCHAR2,
   p_glcode     IN     VARCHAR2,
   p_opbrancd   IN     VARCHAR2,
   p_remark     IN     VARCHAR2,
   p_yrprfx     IN     VARCHAR2,
   p_chgcde     IN     VARCHAR2,
   p_modcde     IN     VARCHAR2,
   p_supid2     IN     VARCHAR2,
   p_drcode     IN     VARCHAR2,
   p_crcode     IN     VARCHAR2,
   p_oprstamp   IN     VARCHAR2,
   p_timstamp   IN     DATE,
   p_glflag     IN     VARCHAR2,
   p_refno5     IN     VARCHAR2,
   p_errflg          OUT VARCHAR2,
   p_errmsg          OUT VARCHAR2)
IS
   v_sql   VARCHAR2 (4000) := NULL;
BEGIN
   v_sql :=
         'BEGIN dpk_all_tran.dpr_insert_fetran@'
      || p_dblink
      || '(i_brancd     =>    :v_brancd      ,

                                i_doctyp     =>    :v_doctyp,

                                i_docnum     =>    :v_docnum,

                                i_sernum     =>    :v_sernum,

                                i_docdat     =>    :v_docdat,

                                i_valdat     =>    :v_valdat,

                                i_oprcod     =>    :v_oprcod,

                                i_actype     =>    :v_actype,

                                i_actnum     =>    :v_actnum,

                                i_curcde     =>    :v_curcde,

                                i_exrate     =>    :v_exrate,

                                i_debcre     =>    :v_debcre,

                                i_dbamfc     =>    :v_dbamfc,

                                i_dbamlc     =>    :v_dbamlc,

                                i_cramfc     =>    :v_cramfc,

                                i_cramlc     =>    :v_cramlc,

                                i_curbal     =>    :v_curbal,

                                i_balflg     =>    :v_balflg,

                                i_chgflg     =>    :v_chgflg,

                                i_chqser     =>    :v_chqser,

                                i_chqnum     =>    :v_chqnum,

                                i_chqdat     =>    :v_chqdat,

                                i_trbrancd   =>    :v_trbrancd,

                                i_tractype   =>    :v_tractype,

                                i_tractnum   =>    :v_tractnum,

                                i_trchqser   =>    :v_trchqser,

                                i_trchqnum   =>    :v_trchqnum,

                                i_trchqdat   =>    :v_trchqdat,

                                i_clrzon     =>    :v_clrzon,

                                i_clrday     =>    :v_clrday,

                                i_prtflg     =>    :v_prtflg,

                                i_glcode     =>    :v_glcode,

                                i_opbrancd   =>    :v_opbrancd,

                                i_remark     =>    :v_remark,

                                i_yrprfx     =>    :v_yrprfx,

                                i_chgcde     =>    :v_chgcde,

                                i_modcde     =>    :v_modcde,

                                i_supid2     =>    :v_supid2,

                                i_drcode     =>    :v_drcode,

                                i_crcode     =>    :v_crcode,

                                i_oprstamp   =>    :v_oprstamp,

                                i_timstamp   =>    :v_timstamp,

                                i_glflag     =>    :v_glflag,

                                i_refno5     =>    :v_refno5,

                                errflg          => :v_errflg,

                                errmsg          => :v_errmsg);

         END;';



   EXECUTE IMMEDIATE v_sql
      USING IN p_brancd,
            IN p_doctyp,
            IN p_docnum,
            IN p_sernum,
            IN p_docdat,
            IN p_valdat,
            IN p_oprcod,
            IN p_actype,
            IN p_actnum,
            IN p_curcde,
            IN p_exrate,
            IN p_debcre,
            IN p_dbamfc,
            IN p_dbamlc,
            IN p_cramfc,
            IN p_cramlc,
            IN p_curbal,
            IN p_balflg,
            IN p_chgflg,
            IN p_chqser,
            IN p_chqnum,
            IN p_chqdat,
            IN p_trbrancd,
            IN p_tractype,
            IN p_tractnum,
            IN p_trchqser,
            IN p_trchqnum,
            IN p_trchqdat,
            IN p_clrzon,
            IN p_clrday,
            IN p_prtflg,
            IN p_glcode,
            IN p_opbrancd,
            IN p_remark,
            IN p_yrprfx,
            IN p_chgcde,
            IN p_modcde,
            IN p_supid2,
            IN p_drcode,
            IN p_crcode,
            IN p_oprstamp,
            IN p_timstamp,
            IN p_glflag,
            IN p_refno5,
            OUT p_errflg,
            OUT p_errmsg;
EXCEPTION
   WHEN OTHERS
   THEN
      p_errflg := 'E';

      p_errmsg := 'Exception Error : ' || SQLERRM;
END;
/
