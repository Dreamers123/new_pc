CREATE PROCEDURE        job_procedure (IN_ID NUMBER)
IS
   v_sl   NUMBER := 0;
BEGIN
   SELECT NVL (MAX (SL), 0) + 1 INTO v_sl FROM JOB_TEST;

   INSERT INTO JOB_TEST (SL)
        VALUES (v_sl);

   COMMIT;
END;
/
