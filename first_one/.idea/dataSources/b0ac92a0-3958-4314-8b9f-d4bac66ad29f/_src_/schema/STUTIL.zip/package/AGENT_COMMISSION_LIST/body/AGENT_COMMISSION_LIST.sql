CREATE PACKAGE BODY        AGENT_COMMISSION_LIST
IS
   PROCEDURE AGENT_COMPANY_COMM (
      pBranchCode           VARCHAR2,
      pCommRT           OUT AGENT_COMMISSION_LIST.AGENT_COMM_OBJ,
      pAgentAcNo            VARCHAR2,
      pCompanyName          VARCHAR2,
      pCollectionUser       VARCHAR2 DEFAULT NULL)     --PRAGATI/METLIFE/KGDCL
   IS
   /*   CURSOR cListMetLife
      IS
           SELECT AGENTACNO agent_ac_no,
                  SUM (PAIDAMT) tran_amt,
                  SUM (CHARGAMT) total_comm,
                    (SELECT AMT
                       FROM STUTIL.STPARAMT
                      WHERE TYPE = 'MET' AND SUBTYPE = 'ACG')
                  * COUNT (1)
                     agent_comm,
                  SUM (NVL (STAMPAMT, 0)) stamp
             FROM STUTIL.STLMDBEX
            WHERE     OPBRANCD = pBranchCode
                  AND COMFLAG = 'N'
                  AND PAYSTAT = 'P'
                  AND AGENTACNO =
                         DECODE (pAgentAcNo, '0', AGENTACNO, pAgentAcNo)
                  AND pCompanyName = 'METLIFE'
         GROUP BY AGENTACNO;

      CURSOR cListPragati
      IS
           SELECT AGENTACNO agent_ac_no,
                  SUM (TOTAL_AMT) tran_amt,
                  SUM (CHRG_AMT) total_comm,
                  ROUND (SUM ( (CHRG_AMT * 80) / 100), 2) agent_comm,
                  ROUND (SUM ( (CHRG_AMT * 20) / 100), 2) bank_comm, --Must Need
                  SUM (CASE WHEN TOTAL_AMT > 400 THEN 10 ELSE
                  0 END) stamp 
             FROM STUTIL.STUTLINF
            WHERE     OPBRANCD = pBranchCode
                  AND APPFLG = 'N'
                  AND AGENTACNO = DECODE (pAgentAcNo, '0', AGENTACNO, pAgentAcNo)
                  AND pCompanyName = 'PRAGATI'
         GROUP BY AGENTACNO;

      CURSOR cListKgdcl
      IS
           SELECT AGENT_ACNO agent_ac_no,
                  SUM (TOTALBIL) tran_amt,
                  0 total_comm,                   --SUM (CHARGAMT) total_comm,
                --  (SELECT AMT
                 --    FROM STUTIL.STPARAMT
                --    WHERE TYPE = 'KWS' AND SUBTYPE = 'PML')
            --    * COUNT (1)
                  0 agent_comm,
                  SUM (NVL (STAMPAMT, 0)) stamp
             FROM STUTIL.STKGDCLB
            WHERE     OPBRANCD = pBranchCode
                  AND TRANFLG = 'N'
                  AND AGENT_ACNO =
                         DECODE (pAgentAcNo, '0', AGENT_ACNO, pAgentAcNo)
                  AND pCompanyName = 'KGDCL'
                  AND OPRSTAMP = pCollectionUser
         GROUP BY AGENT_ACNO;
        */
        CURSOR cListBgdcl
      IS
           SELECT AGENT_ACNO agent_ac_no,
                  SUM (TOTALBIL) tran_amt,
                  0 total_comm,                   --SUM (CHARGAMT) total_comm,
                  /*(SELECT AMT
                     FROM STUTIL.STPARAMT
                    WHERE TYPE = 'KWS' AND SUBTYPE = 'PML')
                * COUNT (1)*/
                  0 agent_comm,
                  SUM (NVL (STAMPAMT, 0)) stamp
             FROM STUTIL.STBGDCLB
            WHERE     OPBRANCD = pBranchCode
                  AND TRANFLG = 'N'
                  AND AGENT_ACNO = DECODE (pAgentAcNo, '0', AGENT_ACNO, pAgentAcNo)
                  AND pCompanyName = 'BGDCL'
                  AND OPRSTAMP = pCollectionUser
         GROUP BY AGENT_ACNO;
 
      m   NUMBER := 1;
 
   BEGIN
   
       --  raise_application_error(-20001,'test1-'||pCompanyName);
    /*  IF pCompanyName = 'METLIFE'
      THEN
         BEGIN
            FOR j IN cListMetLife
            LOOP
               pCommRT (m).agent_ac_no := j.agent_ac_no;
               pCommRT (m).tran_amt := j.tran_amt;
               pCommRT (m).total_comm := j.total_comm;
               pCommRT (m).agent_comm := j.agent_comm;
               pCommRT (m).stamp := j.stamp;
               m := m + 1;
            END LOOP;
         EXCEPTION
            WHEN OTHERS
            THEN
               raise_application_error (-20001, SQLERRM);
         END;
      ELSIF pCompanyName = 'PRAGATI'
      THEN
         BEGIN
            FOR j IN cListPragati
            LOOP
               pCommRT (m).agent_ac_no := j.agent_ac_no;
               pCommRT (m).tran_amt := j.tran_amt;
               pCommRT (m).total_comm := j.total_comm;
               pCommRT (m).agent_comm := j.agent_comm;
               pCommRT (m).bank_comm := j.bank_comm;              -- Must Need
               pCommRT (m).stamp := j.stamp;
               m := m + 1;
            END LOOP;
         EXCEPTION
            WHEN OTHERS
            THEN
               raise_application_error (-20001, SQLERRM);
         END;
      ELSIF pCompanyName = 'KGDCL'
      THEN
         BEGIN
            FOR j IN cListKgdcl
            LOOP
               pCommRT (m).agent_ac_no := j.agent_ac_no;
               pCommRT (m).tran_amt := j.tran_amt;
               pCommRT (m).total_comm := j.total_comm;
               pCommRT (m).agent_comm := j.agent_comm;
               pCommRT (m).stamp := j.stamp;
               m := m + 1;
            END LOOP;
         EXCEPTION
            WHEN OTHERS
            THEN
               raise_application_error (-20001, SQLERRM);
         END; */
          IF pCompanyName = 'BGDCL'
      THEN
         BEGIN
         
            FOR j IN cListBgdcl
            LOOP
            
               pCommRT (m).agent_ac_no := j.agent_ac_no;
               pCommRT (m).tran_amt := j.tran_amt;
               pCommRT (m).total_comm := j.total_comm;
               pCommRT (m).agent_comm := j.agent_comm;
               pCommRT (m).stamp := j.stamp;
               m := m + 1;
            END LOOP;
         EXCEPTION
            WHEN OTHERS
            THEN
               raise_application_error (-20001, SQLERRM);
         END;
         
      END IF;
   END;
END AGENT_COMMISSION_LIST;
/
