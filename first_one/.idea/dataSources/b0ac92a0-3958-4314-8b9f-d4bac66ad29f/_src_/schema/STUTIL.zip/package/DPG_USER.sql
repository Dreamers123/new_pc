CREATE PACKAGE        dpg_user as

    Procedure access_log (m_userid in varchar2, m_username in varchar2, m_log_status in varchar2, m_log_fail_msg in varchar2, m_log_id out number);
    
    Function pwd_hash (p_username in varchar2, p_password in varchar2) return varchar2;

    Procedure user_logon (m_user_id in varchar2, m_pwd in varchar2, m_ret_str out varchar2);
    
    --Procedure get_new_number (m_key1 in varchar2, m_key2 in varchar2, m_ret_str out varchar2);
    
    Procedure user_activation (m_user_code in varchar2, m_ret_str out varchar2);
    
    Procedure user_rejection (m_user_code in varchar2, m_ret_str out varchar2);

End;
/
