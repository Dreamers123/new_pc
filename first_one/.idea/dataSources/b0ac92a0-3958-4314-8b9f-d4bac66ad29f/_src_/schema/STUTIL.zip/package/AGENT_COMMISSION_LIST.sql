CREATE PACKAGE        AGENT_COMMISSION_LIST
AS
   TYPE AGENT_COMM IS RECORD
   (
      agent_ac_no   VARCHAR2 (13),
      tran_amt      NUMBER,
      total_comm    NUMBER,
      agent_comm    NUMBER,
      stamp         NUMBER,
      bank_comm     NUMBER
   );



   TYPE AGENT_COMM_OBJ IS TABLE OF AGENT_COMM
      INDEX BY BINARY_INTEGER;



   PROCEDURE AGENT_COMPANY_COMM (
      pBranchCode           VARCHAR2,
      pCommRT           OUT AGENT_COMMISSION_LIST.AGENT_COMM_OBJ,
      pAgentAcNo            VARCHAR2,
      pCompanyName          VARCHAR2,
      pCollectionUser       VARCHAR2 DEFAULT NULL);    --PRAGATI/METLIFE/KGDCL
END AGENT_COMMISSION_LIST;
/
