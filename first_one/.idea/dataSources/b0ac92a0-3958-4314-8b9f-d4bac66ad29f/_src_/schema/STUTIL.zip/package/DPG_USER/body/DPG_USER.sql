CREATE PACKAGE BODY        dpg_user
AS
   PROCEDURE access_log (m_userid         IN     VARCHAR2,
                         m_username       IN     VARCHAR2,
                         m_log_status     IN     VARCHAR2,
                         m_log_fail_msg   IN     VARCHAR2,
                         m_log_id            OUT NUMBER)
   AS
      v_remote_addr       st_user_log_web.remote_addr%TYPE;
      v_remote_user       st_user_log_web.remote_user%TYPE;
      v_http_user_agent   st_user_log_web.http_user_agent%TYPE;
      v_http_host         st_user_log_web.http_host%TYPE;
      v_http_cookie       st_user_log_web.http_cookie%TYPE;
   BEGIN
      v_remote_addr := OWA_UTIL.get_cgi_env ('REMOTE_ADDR');
      v_remote_user := OWA_UTIL.get_cgi_env ('REMOTE_USER');
      v_http_user_agent :=
         SUBSTR (OWA_UTIL.get_cgi_env ('HTTP_USER_AGENT'), 1, 100);
      v_http_host := OWA_UTIL.get_cgi_env ('HTTP_HOST');
      v_http_cookie := SUBSTR (OWA_UTIL.get_cgi_env ('HTTP_COOKIE'), 1, 500);

      SELECT NVL (MAX (log_id), 0) + 1 INTO m_log_id FROM st_user_log_web;

      INSERT INTO st_user_log_web (log_id,
                                   user_id,
                                   user_name,
                                   usid,
                                   in_time,
                                   out_time,
                                   remote_addr,
                                   http_host,
                                   remote_user,
                                   http_user_agent,
                                   http_cookie,
                                   log_status,
                                   log_fail_msg)
           VALUES (m_log_id,
                   m_userid,
                   m_username,
                   NULL,
                   SYSDATE,
                   NULL,
                   v_remote_addr,
                   v_http_host,
                   v_remote_user,
                   v_http_user_agent,
                   v_http_cookie,
                   m_log_status,
                   SUBSTR (m_log_fail_msg, 1, 500));

      COMMIT;
   EXCEPTION
      WHEN OTHERS
      THEN
         raise_application_error (-20100, 'Error in acc_log: ' || SQLERRM);
         ROLLBACK;
         RETURN;
   END;


   FUNCTION pwd_hash (p_username IN VARCHAR2, p_password IN VARCHAR2)
      RETURN VARCHAR2
   IS
   --l_password varchar2(4000);
   --l_salt varchar2(4000) := '3T9T4QN423QCTMF0T9B3PNX6IW04WI';
   BEGIN
      -- This function should be wrapped, as the hash algorhythm is exposed here.
      -- You can change the value of l_salt or the method of which to call the
      -- DBMS_OBFUSCATOIN toolkit, but you much reset all of your passwords
      -- if you choose to do this.

      /*l_password := utl_raw.cast_to_raw(dbms_obfuscation_toolkit.md5
        (input_string => p_password || substr(l_salt,10,13) || p_username ||
          substr(l_salt, 4,10)));

      --return l_password;*/

      RETURN '';                       --custom_hash (p_username, p_password);
   END;

   PROCEDURE user_logon (m_user_id   IN     VARCHAR2,
                         m_pwd       IN     VARCHAR2,
                         m_ret_str      OUT VARCHAR2)
   IS
      m_user_code                  VARCHAR2 (20);
      m_userid                     VARCHAR2 (20);
      m_password                   VARCHAR2 (200);
      m_user_name                  VARCHAR2 (200);
      m_status                     VARCHAR2 (20);
      m_usertype                   VARCHAR2 (20);
      v_grupcode                   VARCHAR2 (20);
      m_last_login_dt              DATE;
      m_last_password_changed_on   DATE;
      v_logon_allow_days           NUMBER := 3000;

      m_log_id                     NUMBER;

      m_change_pass                VARCHAR2 (1);

      v_authtype                   syusrmas.authtype%TYPE;

      vencryptval                  VARCHAR2 (500);
      v_divncode                   VARCHAR2 (10);

      v_rep_path                   VARCHAR2 (400); /*added by Anwar Pervez as on 17/01/2017 for dynamic report path*/
      v_rpt_url                    VARCHAR2 (400);

      v_branchcde                  VARCHAR2 (200);
      v_bbcode                     VARCHAR2 (20);
      v_brancd                     VARCHAR2 (10);                           --
      v_dblink                     authtype.dblink%TYPE;

      v_auth                       VARCHAR2 (1) := 'F';
   BEGIN
      apex_authentication.send_login_username_cookie (
         p_username => LOWER (m_user_id));

      APEX_UTIL.set_session_state ('AI_DATE_FORMAT', 'DD-Mon-RR');

      BEGIN
         IF INSTR (m_user_id, '@') > 0
         THEN
            SELECT usercode,
                   usercode,
                   userpawd,
                   username,
                   valdflag,
                   usertype,
                   grupcode,
                   lastlogn,
                   paswdate,
                   chpass_nl,
                   NVL (authtype, 'eCL'),
                   divncode
              INTO m_user_code,
                   m_userid,
                   m_password,
                   m_user_name,
                   m_status,
                   m_usertype,
                   v_grupcode,
                   m_last_login_dt,
                   m_last_password_changed_on,
                   m_change_pass,
                   v_authtype,
                   v_divncode
              FROM syusrmas
             WHERE LOWER (emailid1) = LOWER (m_user_id);
         ELSIF     (   SUBSTR (m_user_id, 1, 1) BETWEEN '0' AND '9'
                    OR SUBSTR (m_user_id, 1, 1) = '+')
               AND LENGTH (m_user_id) > 6
         THEN
            SELECT usercode,
                   usercode,
                   userpawd,
                   username,
                   valdflag,
                   usertype,
                   grupcode,
                   lastlogn,
                   paswdate,
                   chpass_nl,
                   NVL (authtype, 'eCL'),
                   divncode
              INTO m_user_code,
                   m_userid,
                   m_password,
                   m_user_name,
                   m_status,
                   m_usertype,
                   v_grupcode,
                   m_last_login_dt,
                   m_last_password_changed_on,
                   m_change_pass,
                   v_authtype,
                   v_divncode
              FROM syusrmas
             WHERE telnumbr = m_user_id;
         ELSE
            SELECT usercode,
                   usercode,
                   userpawd,
                   username,
                   valdflag,
                   usertype,
                   grupcode,
                   lastlogn,
                   paswdate,
                   chpass_nl,
                   NVL (authtype, 'eCL'),
                   divncode
              INTO m_user_code,
                   m_userid,
                   m_password,
                   m_user_name,
                   m_status,
                   m_usertype,
                   v_grupcode,
                   m_last_login_dt,
                   m_last_password_changed_on,
                   m_change_pass,
                   v_authtype,
                   v_divncode
              FROM syusrmas
             WHERE usercode = m_user_id;
         END IF;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            m_ret_str := '0Error: User ID ' || m_user_id || ' not found';
            access_log (m_user_id,
                        m_user_name,
                        '0',
                        m_ret_str,
                        m_log_id);
            RETURN;
      END;

      --------------------------------------------------------------------------

      ---------- Get DBLINK INFORMATION FROM SERVICEMST TABLE-------------------
      ---------------> Added by FAHIM 16/02/2017
      BEGIN
         SELECT LOWER (dblink), module_code ----> Replacing Module Name to Module code
           INTO v_dblink, v_authtype
           FROM authtype
          WHERE UPPER (module_name) = UPPER (v_authtype);
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            v_dblink := NULL;
         WHEN OTHERS
         THEN
            v_dblink := NULL;
      END;


      --------------------------------------------------------------------------

      IF v_authtype = 'LOCAL'
      THEN
         proc_create_password (UPPER (m_user_code), m_pwd, vencryptval);

         IF m_password <> vencryptval
         THEN
            m_ret_str := '0Invalid Password, Logon Denied';
            access_log (m_user_id,
                        m_user_name,
                        '0',
                        m_ret_str,
                        m_log_id);
            RETURN;
         END IF;


         IF NVL (m_status, ' ') <> 'A'
         THEN
            m_ret_str :=
                  '0Login Denied..! User Status is '
               || CASE
                     WHEN m_status = 'E' THEN 'Expired.'
                     WHEN m_status = 'T' THEN 'Terminated.'
                     WHEN m_status = 'S' THEN 'Suspended.'
                     WHEN m_status = 'I' THEN 'Inactive.'
                     WHEN m_status = 'D' THEN 'Deleted.'
                     ELSE 'Unknown'
                  END
               || CHR (10)|| 'Please Contact your Administrator';

            access_log (m_user_id,
                        m_user_name,
                        '0',
                        m_ret_str,
                        m_log_id);
            RETURN;
         END IF;

         IF SYSDATE - m_last_login_dt > v_logon_allow_days
         THEN
            m_ret_str :=
                  '0User did not logged in for last '
               || v_logon_allow_days
               || ' days, Logon Denied.'
               || CHR (10)
               || CHR (13)
               || 'User Last Logged on: '
               || TO_CHAR (m_last_login_dt, v ('AI_DATE_FORMAT'))
               || CHR (10)
               || CHR (13)
               || 'Contact Administrator';
            access_log (m_user_id,
                        m_user_name,
                        '0',
                        m_ret_str,
                        m_log_id);
            RETURN;
         END IF;
      ELSIF v_authtype = 'iSTELAR'
      THEN
         EXECUTE IMMEDIATE
               'Select stlbas.DPK_iStelar_security.apex_custom_auth@'
            || v_dblink
            || '('''
            || UPPER (m_user_code)
            || ''', '''
            || m_pwd
            || ''')
           from dual'
            INTO v_auth;

         IF v_auth <> 'S'
         THEN
            m_ret_str := '0Invalid Password, Logon Denied';
            access_log (m_user_id,
                        m_user_name,
                        '0',
                        m_ret_str,
                        m_log_id);
            RETURN;
         END IF;
      ELSIF v_authtype = 'HIKMAH'
      THEN
         EXECUTE IMMEDIATE
               'Select islbas.DPK_iStelar_security.apex_custom_auth@'
            || v_dblink
            || '('''
            || UPPER (m_user_code)
            || ''', '''
            || m_pwd
            || ''')
           from dual'
            INTO v_auth;

         IF v_auth <> 'S'
         THEN
            m_ret_str := '0Invalid Password, Logon Denied';
            access_log (m_user_id,
                        m_user_name,
                        '0',
                        m_ret_str,
                        m_log_id);
            RETURN;
         END IF;
      END IF;

      --------------------------------------------------------------------------

      access_log (m_user_id,
                  m_user_name,
                  '1',
                  NULL,
                  m_log_id);

      m_ret_str :=
            '1:'
         || m_user_code
         || ':'
         || m_userid
         || ':'
         || m_user_name
         || ':'
         || m_usertype
         || ':'
         || ':'
         || m_log_id;


      /*added by Anwar Pervez as on 17/01/2017 for dynamic report path

      BEGIN
        SELECT RPT_URL, RPT_PATH
        INTO v_rpt_url, v_rep_path
        FROM REPORT_STANDARD
        WHERE RPT_KEY = '01';
      END;
      */

      -- Parameter Settings
      BEGIN
         APEX_UTIL.set_session_state ('AI_USERNAME', m_user_name);

         APEX_UTIL.set_session_state ('AI_PWD_CH_REQUIRED', m_change_pass);

         APEX_UTIL.set_session_state ('AI_DIVNCODE', v_divncode);

         APEX_UTIL.set_session_state ('AI_REP_URL', v_rpt_url);

         APEX_UTIL.set_session_state ('AI_REP_PATH', v_rep_path);

         APEX_UTIL.set_session_state ('AI_USER_TYPE', m_usertype);
         
         APEX_UTIL.set_session_state ('AI_GROUPCODE', v_grupcode);


         BEGIN
            SELECT brancd || '-' || UPPER (brnnam), bbcode, brancd
              INTO v_branchcde, v_bbcode, v_brancd
              FROM bbankcode
             WHERE brancd = v_divncode;

            APEX_UTIL.set_session_state ('FX_BBCODE', v_bbcode);
            APEX_UTIL.set_session_state ('AI_BRANCH_CODE', v_brancd);
         EXCEPTION                  ---------------> Added by FAHIM 16/03/2017
            WHEN NO_DATA_FOUND
            THEN
               m_ret_str := '0Error: No Data Found in BBANKCODE....!';
               access_log (m_user_id,
                           m_user_name,
                           '0',
                           m_ret_str,
                           m_log_id);
               RETURN;
            WHEN TOO_MANY_ROWS      ---------------> Added by FAHIM 16/03/2017
            THEN
               m_ret_str := '0Error: Multiple Records Found in BBANKCODE....!';
               access_log (m_user_id,
                           m_user_name,
                           '0',
                           m_ret_str,
                           m_log_id);
               RETURN;
            WHEN OTHERS             ---------------> Added by FAHIM 16/03/2017
            THEN
               m_ret_str := '0Error:' || SQLERRM;
               access_log (m_user_id,
                           m_user_name,
                           '0',
                           m_ret_str,
                           m_log_id);
               RETURN;
         END;
      END;

      apex_authentication.login (p_username   => m_user_code,
                                 p_password   => m_pwd);

      RETURN;
   EXCEPTION
      WHEN OTHERS
      THEN
         m_ret_str := '0Error:' || SQLERRM;
         access_log (m_user_id,
                     m_user_name,
                     '0',
                     m_ret_str,
                     m_log_id);
   END;


   PROCEDURE user_activation (m_user_code   IN     VARCHAR2,
                              m_ret_str        OUT VARCHAR2)
   IS
   BEGIN
      UPDATE syusrmas
         SET valdflag = 'A',
             chpass_nl = 'Y',
             activeby = v ('APP_USER'),
             statdate = SYSDATE
       WHERE usercode = m_user_code;
   END;

   PROCEDURE user_rejection (m_user_code IN VARCHAR2, m_ret_str OUT VARCHAR2)
   IS
   BEGIN
      NULL;
   END;
END;
/
