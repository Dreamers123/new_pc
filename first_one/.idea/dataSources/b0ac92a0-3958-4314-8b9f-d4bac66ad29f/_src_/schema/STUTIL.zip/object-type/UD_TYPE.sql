CREATE TYPE        ud_type AS OBJECT
(
   col1 VARCHAR2 (13),
   col2 VARCHAR2 (13)
);
/
