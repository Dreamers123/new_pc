CREATE TYPE        "userd_type" AS OBJECT
(
   col1 VARCHAR2 (13),
   col1 VARCHAR2 (13)
);
/
