CREATE TYPE        "AGENT_COMM" AS OBJECT
(
   agent_ac_no VARCHAR2 (13),
   tran_amt NUMBER,
   total_comm NUMBER,
   agent_comm NUMBER,
   stamp NUMBER,
   bank_comm NUMBER
);
/
